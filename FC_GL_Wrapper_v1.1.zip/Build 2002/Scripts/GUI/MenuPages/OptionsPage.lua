-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------

OptionsPage={
};

function OptionsPage:GetName()
	return "OptionsPage"
end

function OptionsPage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then

		if (Sender==OptionsPage.BtnPlayerSettings) then
			local Page=GUI.GetControlPage("PlayerSettingsPage");
			if (Page) then
				Page.Activate();
			end
		elseif (Sender==OptionsPage.BtnControlSettings) then
			local Page=GUI.GetControlPage("ControlSettingsPage");
			if (Page) then
				Page.Activate();
			end
		elseif (Sender==OptionsPage.BtnVideoSettings) then
			local Page=GUI.GetControlPage("VideoSettingsPage");
			if (Page) then
				Page.Activate();
			end
		elseif (Sender==OptionsPage.BtnSoundSettings) then
			local Page=GUI.GetControlPage("SoundSettingsPage");
			if (Page) then
				Page.Activate();
			end
		end

--		elseif (Sender==MultiPlayerPage.BtnCreateServer) then
--			local Page=GUI.GetControlPage("CreateServerPage");
--			if (Page) then
--				Page.Activate();
--			end

		if (Sender==OptionsPage.BtnMainPage) then -- back-button
			local Page=GUI.GetControlPage("MainPage");
			if (Page) then
				Page.Activate();
			end
		end

	end
end

function OptionsPage:OnInit()
	OptionsPage.pMouseCursor=System.LoadImage("textures/GUI/mousecursor.tga");
	self.SetCursor(OptionsPage.pMouseCursor);
	
	OptionsPage.BtnPlayerSettings=self.CreateButton(300, 184, 200, 20, 0, Language.PlayerSettings);
	OptionsPage.BtnPlayerSettings.SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnPlayerSettings);
	
	OptionsPage.BtnControlSettings=self.CreateButton(300, 224, 200, 20, 0, Language.ControlSettings);
	OptionsPage.BtnControlSettings.SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnControlSettings);
--	OptionsPage.BtnControlSettings.Enable( nil );	-- fix 10: Control Settings enabled
	
	OptionsPage.BtnVideoSettings=self.CreateButton(300, 264, 200, 20, 0, Language.VideoSettings);
	OptionsPage.BtnVideoSettings.SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnVideoSettings);
	
	OptionsPage.BtnSoundSettings=self.CreateButton(300, 304, 200, 20, 0, Language.SoundSettings);
	OptionsPage.BtnSoundSettings.SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnSoundSettings);
	
	OptionsPage.BtnMainPage=self.CreateButton(10, 570, 100, 20, 0, Language.Back);
	OptionsPage.BtnMainPage.SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnMainPage);
end

-------------------------------------------------------------------------
function OptionsPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function OptionsPage:OnDraw()
end

-------------------------------------------------------------------------
function OptionsPage:OnShutdown()
	--System.UnloadImage(OptionsPage.pMouseCursor);
end

