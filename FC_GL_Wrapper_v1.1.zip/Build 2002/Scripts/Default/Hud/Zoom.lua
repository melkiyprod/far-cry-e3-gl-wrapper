--------------------------------------------------------------------
-- X-Isle Script File
-- Description: Defines the zooming-functionality
-- Created by Lennert Schneider
--------------------------------------------------------------------

Zoom = {
	IsActive = 0,
	Zoomable = 1,
--	DrawStats = 1,
--	MinZoom = 45 * 3.1415962 / 180,
--	MaxZoom = 8 * 3.1415962 / 180,
	NoZoom = 90 * 3.1415962 / 180,
	CurrZoomStep = 1,
	MaxZoomSteps = 1,
	ZoomSteps={ NoZoom },

	Sway = 0.0,
	MinSway = 1.0,
	MaxSway = 5.0,
	SwayInc = 1,
	StanceSwayModyfier = 1.0,
	AddZoom = 0.0,
}

-------------------------------------------------------
-- FOV setting (MelkiyProd, Far Cry E3 GL wrapper package v87)
--   cl_fov      = field of view as on a 4:3 screen, 60..130 (90 = the original game)
--   cl_fov_wide = 1: wider view on wide screens - the height of the picture stays as on 4:3 and the screen
--                 width is added at the sides (16:10 -> 108, 16:9 -> 120); 0 = the number as it is (original)
-- The engine makes the vertical angle = fov * height / width, so without this a wide screen cuts the top and
-- bottom off. Scopes and binoculars keep their magnification (they divide this base value).
if(cl_fov==nil)then Game.CreateVariable("cl_fov","90"); end
if(cl_fov_wide==nil)then Game.CreateVariable("cl_fov_wide","1"); end
-- the GL wrapper writes fc_gl_fov.lua at every start from fc_gl.ini [graphics] fov / fov_wide
-- (fov = auto / e3 / 60..130 / game); loaded here at game start
Script.LoadScript("fc_gl_fov.lua");
function Zoom:BaseFov()
	local f=tonumber(cl_fov);
	if(f==nil)then f=90 end
	if(f<60)then f=60 end
	if(f>130)then f=130 end
	if(tonumber(cl_fov_wide)~=0)then
		local w=tonumber(r_Width);
		local h=tonumber(r_Height);
		if(w and h and h>0)then
			local k=(w/h)/(4/3);
			if(k>1)then f=f*k end
		end
	end
	if(f>170)then f=170 end
	Zoom.NoZoom=f*3.1415962/180;
	return Zoom.NoZoom;
end
-- called every frame from Zoom:OnUpdate while no zoom is on: applies the base field of view when it changes
-- (console, resolution) or when the engine has set its own default of 90 again (level load, new player)
function Zoom:IdleUpdate()
	local f=Zoom.BaseFov(Zoom);
	local key=tostring(cl_fov).."/"..tostring(cl_fov_wide).."/"..tostring(r_Width).."/"..tostring(r_Height);
	local me=System.GetMyPlayer();
	local cur=nil;
	if(System.GetCameraFov)then cur=System.GetCameraFov(); end
	local stock=(cur~=nil) and (abs(cur-1.5707981)<0.001) and (abs(f-cur)>0.001);
	if((key~=Zoom.fov_key) or (Zoom.fov_player~=me) or stock)then
		if(stock and (key==Zoom.fov_key) and (Zoom.fov_player==me))then
			System.LogToConsole("FOV: the engine set its 90 again - back to "..tostring(f*180/3.1415962));
		end
		Zoom.fov_key=key;
		Zoom.fov_player=me;
		System.SetCameraFov(f);
	end
end

-------------------------------------------------------
function Zoom:OnInit()
	Game.CreateVariable("h_zoom_speed");
	h_zoom_speed = 250 * 3.1415962 / 180;
end

-------------------------------------------------------
function Zoom:OnUpdate()
	Zoom.BaseFov(Zoom);
	if ( Zoom.IsActive == 0 ) then
		Zoom.IdleUpdate(Zoom);
	end
	if ( Zoom.IsActive ~= 0 ) then
		local MyPlayerStats = System.GetMyPlayer().cnt;
		MyPlayerStats.SetSwayAmp(Zoom.MinSway * Zoom.StanceSwayModyfier);

		if ( Zoom.ZoomOverlayFunc ) then
			Zoom.ZoomOverlayFunc( Zoom.CurrZoomStep );
		end

		

		ZoomTmp = (self.AddZoom / 50);
		if (ZoomTmp < 0) then
			ZoomTmp = 0;
		end

		System.SetCameraFov(Zoom.NoZoom / Zoom.ZoomSteps[Zoom.CurrZoomStep] - ZoomTmp);
	end
		
--		local ZoomFactor;
--		if ( Zoom.CurrZoom <= 0 ) then
--			ZoomFactor = 0;
--		else
--			ZoomFactor = ( Zoom.CurrZoomStep / ( Zoom.MaxZoomSteps - 1 ) ) * ( ( Zoom.NoZoom / Zoom.MaxZoom ) - ( Zoom.NoZoom / Zoom.MinZoom ) ) + ( Zoom.NoZoom / Zoom.MinZoom );
--		end
--
--		if ( Zoom.DrawStats ~= 0 ) then
--			-- Draw zoomfactor
--			Game.SetHUDFont("Digital", "Digital");
--			local ZoomFactor;
--			if ( Zoom.CurrZoom <= 0 ) then
--				ZoomFactor = 0;
--			else
--				ZoomFactor = ( Zoom.CurrZoomStep / ( Zoom.MaxZoomSteps - 1 ) ) * ( ( Zoom.NoZoom / Zoom.MaxZoom ) - ( Zoom.NoZoom / Zoom.MinZoom ) ) + ( Zoom.NoZoom / Zoom.MinZoom );
--			end
--			local s=format( "%05.2f X", ZoomFactor*2);
--			Game.WriteHudStringFixed(410, 290-24, s, 1, 0, 0, 1 , 24, 24, 0.5);
--			-- Draw distance
--			local myPlayer=System.GetMyPlayer();
--			local dist=myPlayer.cnt.GetIntersectionDistance();
--			if ( dist >= 0 ) then
--				local s=format( "%07.2f", dist*4);
--				Game.WriteHudStringFixed(410, 310, s, 1, 0, 0, 1, 24, 24, 0.5);
--			else
--				Game.WriteHudStringFixed(410, 310, "----.--", 1, 0, 0, 1, 24, 24, 0.5);
--			end
--		end

end

-------------------------------------------------------
function Zoom:OnShutdown()
	Game.RemoveVariable("h_zoom_speed");
end

-------------------------------------------------------
function Zoom:ZoomIn()
	Zoom.BaseFov(Zoom);
	if ( Zoom.Zoomable ~= 0 ) then
		Zoom.CurrZoomStep = Zoom.CurrZoomStep + 1;
		if ( Zoom.CurrZoomStep > Zoom.MaxZoomSteps ) then
			Zoom.CurrZoomStep = Zoom.MaxZoomSteps;
		end
		System.SetCameraFov( Zoom.NoZoom / Zoom.ZoomSteps[Zoom.CurrZoomStep]);
	end
end

-------------------------------------------------------
function Zoom:ZoomOut()
	Zoom.BaseFov(Zoom);
	if ( Zoom.Zoomable ~= 0 ) then
		Zoom.CurrZoomStep = Zoom.CurrZoomStep - 1;
		if ( Zoom.CurrZoomStep < 1 ) then
			Zoom.CurrZoomStep = 1;
		end
		System.SetCameraFov( Zoom.NoZoom / (Zoom.ZoomSteps[Zoom.CurrZoomStep]) );
	end
end

-------------------------------------------------------
function Zoom:Activate( bActivate, KeyMapName, Swaying, ZoomOverlayFunc )
	Zoom.BaseFov(Zoom);
	if ( Zoom.IsActive == bActivate ) then
		return
	end
	Zoom.IsActive = bActivate;
	if ( Zoom.IsActive == nil ) then
		Zoom.IsActive = 0;
	end
	if ( Zoom.IsActive ~= 0 ) then
		if ( not Swaying ) then
			Swaying = 0;
		end
		Zoom.Sway = Swaying;
		Zoom.MinSway = Swaying;

		if ( KeyMapName == nil ) then		-- no keymap specified => use default zoom map
			KeyMapName = "zoom";
		end
		Input.SetMouseSensitivityScale( 0.3 );
		Zoom.ZoomOverlayFunc = ZoomOverlayFunc;
		local player = System.GetMyPlayer();

		if ( Swaying ) then
			player.cnt.SetSwayAmp( Swaying );
			player.cnt.SetSwayFreq( 0.6 );
		end
		local stats = player.cnt;
		stats.zoom = 1;
--		Zoom.CurrZoom = ( Zoom.MaxZoom - Zoom.MinZoom ) / ( Zoom.MaxZoomSteps - 1 ) * Zoom.CurrZoomStep + Zoom.MinZoom;


	--	System.Log("--> CurStep "..Zoom.CurrZoomStep.." NoZoom "..Zoom.NoZoom);

		System.SetCameraFov( Zoom.NoZoom / Zoom.ZoomSteps[Zoom.CurrZoomStep] );
		Input.SetActionMap( KeyMapName );
	else
		Input.SetMouseSensitivityScale( 1.0 );
		local player = System.GetMyPlayer();
		player.cnt.SetSwayAmp( 0 );
		local stats = player.cnt;
		stats.zoom = 0;
		System.SetCameraFov( Zoom.NoZoom );
--		Zoom.CurrZoom = Zoom.NoZoom;
		Input.SetActionMap( "default" );
	end
end