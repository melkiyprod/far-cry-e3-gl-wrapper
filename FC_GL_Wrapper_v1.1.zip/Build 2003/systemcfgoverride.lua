-- ===== MAX QUALITY (MelkiyProd GL wrapper 1.1) =====
-- Put this file next to systemcfg.lua as systemcfgoverride.lua: the engine reads it AFTER systemcfg.lua
-- and never overwrites it (systemcfg.lua is rewritten by the game on exit).
-- Do not put menu settings here (r_Width, r_Height, r_Fullscreen, volume) - the menu could no longer change them.
-- Each line can be removed on its own. Engine defaults in [brackets] (read from the DLLs, ? = not certain).

-- Texture filtering
r_Texture_Anisotropic_Level = "16"      -- [1?] anisotropic filtering: floor/road textures stay sharp at grazing angles. Driver clamps to its maximum. Cheap

-- Texture size / colour depth
r_TexResolution = "0"                   -- [1] texture size: 0 = full, 1 = half, 2 = quarter. The engine default in this build is 1: every texture of 64 px and more is halved (blurry hands, weapons, walls). Crytek's own E3 override had 0. Full size needs about 4x texture memory: watch RAM in the FPS box. Can be changed in the console, textures reload at once
r_TexBumpResolution = "0"               -- [1] the same for bump / normal maps (Crytek's E3 override: 0)
r_TexSkyResolution = "0"                -- [1] the same for the sky (Crytek's E3 override: 0)
r_TexQuality = "0"                      -- [0] colour depth of textures the engine converts itself (not the DDS files): 0 = 8 bits per channel, 1 = 4/5 bits (16-bit, banding), 2 = DXT compressed
r_TexSkyQuality = "0"                   -- [0] the same for the sky: 0 = RGB8, 1 = RGB5 (16-bit - colour steps in the sky), 2 = DXT1

-- Anti-aliasing
GL_FSAA = "0"                           -- [0] the game's own multisample anti-aliasing. Off: on VMware/Mesa it removes the character shadows (stencil shadows vanish); also try 0 if the game fails to start / black screen. The wrapper's MSAA (GRAPHICS menu) works without it
GL_FSAA_samples = "4"                   -- [4] samples per pixel for GL_FSAA: 2 = faster, 4 = smoother, more = driver dependent
GL_TextureFilter = "GL_LINEAR_MIPMAP_LINEAR"   -- texture filtering of the OpenGL renderer: trilinear (smooth change between mipmap levels - no visible bands on the ground in the distance). GL_LINEAR_MIPMAP_NEAREST = bilinear, a little faster

-- Glare / bloom
r_Glare = "0"                           -- [0] bloom: bright areas glow and bleed into the image. Off: overexposed picture, glossy "jelly" highlights, big FPS cost
r_GlareSize = "128"                     -- [128] resolution of the bloom buffer (only used when r_Glare = 1)

-- Water
r_WaterReflections = "1"                -- [1] mirror image of the island/sky on the water (extra scene pass). Keep 1: with 0 this build shows a red placeholder texture (missing water_lm)
r_WaterRefractions = "0"                -- [0] seabed/fish/coral seen through the water, distorted by waves (extra scene pass, costs FPS). Also in the wrapper's GRAPHICS menu (REFRACTIONS)
r_EnvTexResolution = "3"                -- [3] resolution level of the screen/reflection textures (higher = sharper reflections)
r_EnvCMResolution = "3"                 -- [2] resolution level of the cube maps used for environment reflections on metal, glass, weapons
e_terrain_caustics = "1"                -- [0] caustics: moving light patterns on the seabed under water. Needs e_terrain_single_pass = "1" (with 0 the terrain shows streaks/flicker)

-- Refraction effects - use texture shaders, emulated by the wrapper
r_SelfRefract = "1"                     -- [0] refraction on objects themselves: glass, bottles, transparent surfaces bend what is behind them
r_ScreenRefract = "0"                   -- [0] NOT a quality option: the game scripts use it as a mode switch for the screen-distortion overlay - 1 = binocular lenses (Hud/Binoculars.lua), 2 = sniper scope (Hud/WeaponScope.lua), 0 = off. Keep 0 here: with 1 the binocular lens distortion is drawn over the screen from the level start. The scopes still get their distortion, the scripts switch it on themselves

-- Terrain / detail
e_terrain_texture_mipmaps = "1"         -- [0] mipmaps for the big terrain texture: less shimmering/noise on distant ground
r_ShaderTerrainSpecular = "1"           -- [0] specular highlights (wet/shiny look) on terrain
r_DetailTextures = "1"                  -- [1?] detail textures on objects: extra fine grain up close so surfaces are not blurry
r_DetailNumLayers = "2"                 -- [1?] how many detail-texture layers are blended (more = richer surface, a bit slower)
r_DetailDistance = "32"                 -- [4] distance up to which detail textures are drawn (fine grain on rock/metal/ground). Costs only GPU fill - almost free. Does not count toward the render object limit
e_detail_texture = "1"                  -- [1] detail textures on the terrain (sand, grass, rock grain under your feet)
e_terrain_single_pass = "1"             -- [0?] terrain drawn in one pass (base + detail texture together). Fixes white/black streaks on distant terrain seen through the sniper scope
e_detail_objects = "1"                  -- [1] small detail vegetation: grass and plants scattered on the terrain

-- Objects / vegetation / level-of-detail distances
-- The engine draws at most 2048 render objects per frame; above that the ground turns see-through and bushes go dark. The wrapper can unlock 8192 at once (GRAPHICS menu OBJECT LIMIT, fc_gl.ini [graphics] obj_limit). Check OBJ ... MAX in the FPS box (fc_gl.ini osd_fps_obj=1)
e_lod_ratio = "1"                       -- [1] how far objects keep their detailed models: higher = big trees, palms, rocks, crates detailed further away, costs FPS. The wrapper sets 2 at the start (fc_gl.ini [graphics] lod_ratio, GRAPHICS menu LOD RATIO); lod_ratio=game leaves this value
e_sprite_min_distance = "8"             -- [8] distance where trees/bushes switch from 3D model to a flat sprite (higher = later, more objects). The wrapper sets 32 at the start (fc_gl.ini [graphics] sprite_distance, GRAPHICS menu SPRITE DIST); sprite_distance=game leaves this value
r_VegetationSpritesAlphaBlend = "0"     -- [0] 1 = soft fade between tree model and sprite, but in the fade zone both are half transparent: palms at middle distance look covered by a layer of water / fog - keep 0

-- Lights / effects
e_max_entity_lights = "8"               -- [4] how many dynamic lights may light one object at once (8 = OpenGL limit)
e_dynamic_light = "1"                   -- [1] dynamic lights: flashlight, muzzle flashes, explosions, moving lamps
r_Coronas = "1"                         -- [1?] coronas: glowing halos around lamps and light sources
r_Flares = "1"                          -- [1?] lens flares from the sun and bright lights
e_decals = "1"                          -- [1] decals: bullet holes, scorch marks, blood on walls and ground
e_particles = "1"                       -- [1] particle effects: smoke, fire, sparks, splashes, dust
e_bflyes = "1"                          -- [1] ambient butterflies
e_bugs = "1"                            -- [1] ambient insects (flies, fireflies)

-- Shadows
e_shadow_maps = "1"                     -- [1] shadow maps (Crytek's E3 override had 0); used with fc_gl.ini [performance] shadow_maps=1. Character shadows are stencil shadows (e_stencil_shadows, default 1) - they need GL_FSAA = "0" on VMware/Mesa

-- Kept off on purpose
e_motion_blur = "0"                     -- [0] motion blur when turning/moving fast (smears the image, costs FPS)
GL_ARB_vertex_buffer_object = "0"       -- keep 0: the E3 build streams geometry through small VBOs every frame (no speed gain), the TAB menu breaks and CryAnimation.dll crashes
r_ColorBits = "32"
