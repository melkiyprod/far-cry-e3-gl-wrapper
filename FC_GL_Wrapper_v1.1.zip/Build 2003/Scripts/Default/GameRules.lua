-------------------------------------------------------------------
-- X-Isle Script File
-- Description: Defines the rules of the default game(Single player)
-- Created by Alberto Demichelis
--------------------------------------------------------------------


GameRules = {
	InitialPlayerStats = {
		health		= 255, 
		-- was set to 150, why? - Tig
		-- Dunno, but now it is set to 300 - which is 3x that of all mercs. Cn
		-- [marco] do not mess around with this too much, we use 1 byte to save health
		-- so it can't be more than 255



		-- we do not have armor in FarCry right now
		-- [marco] we do,initially is set to 0 though
		armor		= 0,
	},
	m_nMusicId=0,
		--bodydamage is the damage factor the AI does to the player

	-- [marco] changed upon chri's and marc's request
	bodydamage = { 0.7, 0.7, 0.7, 0.15, 0.15 },    -- head, heart, body, arm, leg

	--bodydamage = { 1, 1, 1, 0.25, 0.25 },    -- head, heart, body, arm, leg
	--PRE PETAR REQUEST bodydamage = { 1.3, 0.9, 0.9, 0.40, 0.50 },    -- head, heart, body, arm, leg
		--bodydamage = { 1.0, 1.0, 0.75, 0.23, 0.43 },    -- head, heart, body, arm, leg

	--aidamage is the damage the player does to the bots
	aidamage   = { 20, 1, 1, 0.5, 0.5 },    -- head, heart, body, arm, leg
	Arm2BodyDamage = .75,
	Leg2BodyDamage = 1,
	god_mode_count=0,

	player_death_pos = { x=0, y=0, z=0, xA=0, yA=0, zA=0 },

	TimeRespawn=3,
	TimeDied=0,
}


-------------------------------------------------------
-------------------------------------------------------
function GameRules:OnInit()
	Server:AddTeam("dm");
	Game:CreateVariable("gr_RespawnAtDeathPos",1);
	--Initialize the debug tag point thingy
	DebugTagPointsMgr:Init(g_LevelName);
	_LastCheckPPos=nil;
	self.god_mode_count=0; -- must be reset when switching to game mode in editor
end

-------------------------------------------------------
-------------------------------------------------------
function GameRules:OnUpdate( DeltaTime )
end

-------------------------------------------------------
-------------------------------------------------------
function GameRules:OnShutdown()
end

-------------------------------------------------------
-------------------------------------------------------

function GameRules:OnMapChange()
    _LastCheckPPos = nil
    _LastCheckPAngles = nil
end


-------------------------------------------------------
-------------------------------------------------------
function GameRules:ApplyDamage( target, damage )

	local bGodMode = 0;
	if (god and (tonumber(god) == 1) and (target==_localplayer)) then
		bGodMode = 1;
	end
		
	target.cnt.health = target.cnt.health - damage;
	if ( target.cnt.health < 1 ) then
		
		if(bGodMode==1)then
			GameRules.god_mode_count=GameRules.god_mode_count+1;
			target.cnt.health = self.InitialPlayerStats.health;
		else
			target.cnt.health = 0;
			local angles=target:GetAngles();
			--GameRules.player_death_pos.x=target:GetPos();
			local	place = target:GetPos();
			GameRules.player_death_pos.x=place.x;
			GameRules.player_death_pos.y=place.y;
			GameRules.player_death_pos.z=place.z;
			GameRules.player_death_pos.xA=angles.x;
			--GameRules.player_death_pos.yA=angles.y;
			--no roll needed!!!!!
			GameRules.player_death_pos.yA=0;
			GameRules.player_death_pos.zA=angles.z;

			if (target==_localplayer) then
				self.TimeDied=_time;
			end

			target:GotoState( "Dead" );
		end
		--Game:ForceScoreBoard(target.id, 1);
	end
end

-------------------------------------------------------
-------------------------------------------------------
function GameRules:OnDamage( hit )
    local theTarget = hit.target;

    --System.LogToConsole("--> GameRules:OnDamage shooter == "..hit.shooter.GetID());

	--mat_head
	--mat_heart
	--mat_arm
	--mat_leg
	--mat_flesh
	--mat_armor
	--mat_helmet


	-- [marco] take armor into account
	if ((theTarget.cnt.armor) and (theTarget.cnt.armor>0)) then
		-- fix 12: armor over 100 (armor pickup bug, Armor.lua) gave a negative damage: invulnerable player, armor
		-- growing with every hit. At exactly 100 the damage AND the armor wear were 0 - invulnerable for ever.
		-- Now armor is brought back to max_armor (100), and at full armor the hit is absorbed but wears the armor by
		-- half of the damage. Below 100 everything is as in the original.
		local maxa=theTarget.cnt.max_armor or 100;
		if (maxa>100) then maxa=100; end
		if (theTarget.cnt.armor>maxa) then theTarget.cnt.armor=maxa; end
		-- the negative damage also pushed the player's health over max_health (255 - checkpoints keep health in one
		-- byte); a game that already has it is brought back here (the player only: some AI have more on purpose)
		if ((theTarget==_localplayer) and theTarget.cnt.max_health and (theTarget.cnt.health>theTarget.cnt.max_health)) then
			theTarget.cnt.health=theTarget.cnt.max_health;
		end
		if (theTarget.cnt.armor>=100) then
			theTarget.cnt.armor=theTarget.cnt.armor-(hit.damage*0.5);
			hit.damage=0;
		else
		hit.damage=hit.damage*(1.0-theTarget.cnt.armor/100);
		theTarget.cnt.armor=theTarget.cnt.armor-(hit.damage*0.5);
		end
		if (theTarget.cnt.armor<0) then
			theTarget.cnt.armor=0;
		end
	end


	if ( theTarget ) then
		if(theTarget.type == "Player" ) then
			if(hit.explosion)then
				local expl=theTarget:IsAffectedByExplosion();
				if(expl<=0)then return end
				hit.damage=expl*hit.damage;
			end
			if(hit.target_material) then
				local	targetMatType = hit.target_material.type;
				local dmgf =0;
				local	dmgTable=GameRules.bodydamage;
				if(theTarget.ai)then
					dmgTable=GameRules.aidamage;
				end
				--System.LogToConsole("onDamage mat: "..targetMatType);

				-- proceed protection gear
				if(targetMatType=="helmet")then
					if(theTarget.hasHelmet == 0) then
						hit.target_material = Game:GetMaterialBySurfaceID(Game:GetMaterialIDByName("mat_head"));
						targetMatType = hit.target_material.type;
					else
						BasicPlayer.HelmetHitProceed(theTarget, hit.dir, hit.damage);
						dmgf = 0.01;
					end
				elseif(targetMatType=="armor")then
					if(theTarget.Properties.bHasArmor == 0) then
						hit.target_material = Game:GetMaterialBySurfaceID(Game:GetMaterialIDByName("mat_flesh"));
						targetMatType = hit.target_material.type;
					else
						dmgf = 0.01;
					end
				end

				if(targetMatType=="head") then
					dmgf = dmgTable[1];
				elseif(targetMatType=="heart")then
					dmgf = dmgTable[2];
				elseif(targetMatType=="flesh")then
					dmgf = dmgTable[3];
				elseif(targetMatType=="arm")then
					dmgf = dmgTable[4];
					theTarget.cnt.armhealth = theTarget.cnt.armhealth - hit.damage*dmgf;
					if( theTarget.cnt.armhealth<0 ) then
						theTarget.cnt.armhealth = 0;
					end
					dmgf = dmgf * GameRules.Arm2BodyDamage;
					dmgPrc = theTarget.cnt:GetArmDamage();
					--System.LogToConsole( "Arm HIT "..dmgPrc );
					if( dmgPrc>50 ) then
						theTarget.cnt.dmgFireAccuracy = 100 - (dmgPrc-50)/2;
					end
				elseif(targetMatType=="leg")then
					dmgf = dmgTable[5];
					theTarget.cnt.leghealth = theTarget.cnt.leghealth - hit.damage*dmgf;
					if( theTarget.cnt.leghealth<0 ) then
						theTarget.cnt.leghealth = 0;
					end
					dmgf = dmgf * GameRules.Leg2BodyDamage;
				end


				--System.LogToConsole("onDamage mat: "..targetMatType.." A "..theTarget.cnt.armhealth.." L "..theTarget.cnt.leghealth.." df "..dmgf.." H "..hit.damage);
				--System:LogToConsole("--> Inflicted Damage: "..(hit.damage*dmgf).." health "..theTarget.cnt.health);

				GameRules:ApplyDamage( theTarget, hit.damage*dmgf )
			else
				if(hit.landed == 1) then
					GameRules:ApplyDamage( theTarget, hit.damage )
				else
					System:Log("OnDamage: no material assigned for body: ");
				end
			end
		end
	end


--	if ( theTarget ) then
--		if(theTarget.type == "Player" ) then

--        	local zone = theTarget.cnt.GetBoneHitZone(hit.ipart);
--        	if zone==0 then zone = 2 end;
            --System.LogToConsole("health1: "..theTarget.cnt.health.." part: "..zone);
--            local dmgf = GameRules.bodydamage[zone];
--            if theTarget.ai then
--                dmgf = GameRules.aidamage[zone];
--            end
--        	theTarget.cnt.health = theTarget.cnt.health - hit.damage*dmgf;
            --System.LogToConsole("health2: "..theTarget.cnt.health);

	--		if ( theTarget.cnt.health < 1 ) then
--				theTarget.cnt.health = 0;
--				theTarget.GotoState( "Dead" );
--				Game.ForceScoreBoard(theTarget.id, 1);
--			end
--		end
--	end
end


-------------------------------------------------------
-------------------------------------------------------
function GameRules:RespawnPlayer(server_slot,player)

	if(player.type=="Player")then
		--set the default stats
		player.cnt.max_health=self.InitialPlayerStats.health;
		player.cnt.health=self.InitialPlayerStats.health;
		player.cnt.armor=self.InitialPlayerStats.armor;
		player.cnt.alive=1;
		player:EnablePhysics(1);

		Game:ShowIngameDialog(-1, "", "", 12, "Respawning at last checkpoint",5);
	end

	--local RespawnPoint = Game.GetRandomRespawnPoint();

	--local pos = {x = RespawnPoint.x, y = RespawnPoint.y, z = RespawnPoint.z};
	--local dir = {x = RespawnPoint.xA, y = RespawnPoint.yA, z = RespawnPoint.zA};

	--player.SetPos(pos);
	--player.SetAngles(dir);
	player:SetName(server_slot:GetName());

	if (_LastCheckPPos) then
		player:SetPos(_LastCheckPPos);
		player:SetAngles(_LastCheckPAngles);
	else
		local RespawnPoint = Server:GetFirstRespawnPoint();
		player:SetPos({x = RespawnPoint.x, y = RespawnPoint.y, z = RespawnPoint.z});
		player:SetAngles({x = RespawnPoint.xA, y = RespawnPoint.yA, z = RespawnPoint.zA});
	end
end

-------------------------------------------------------
-------------------------------------------------------
function GameRules:OnClientConnect( server_slot, requested_classid )
	--create a new player entity
--	local RespawnPoint = Server:GetRandomRespawnPoint();
	local RespawnPoint = Server:GetFirstRespawnPoint();	
	local dir = {x = RespawnPoint.xA, y = RespawnPoint.yA, z = RespawnPoint.zA};
	local newPlayer=Server:SpawnEntity(requested_classid,RespawnPoint);
	newPlayer:SetAngles(dir);

	System:Log("FirstRespawnPoint player pos x="..RespawnPoint.x.." y="..RespawnPoint.y.." z="..RespawnPoint.z);
	System:Log("FirstRespawnPoint player angles x="..dir.x.." y="..dir.y.." z="..dir.z);

	--delete the old player entity
	if(server_slot:GetPlayerId()~=0)then
		Server:RemoveEntity(server_slot.GetPlayerId());
	end

	--bind the new created player to the serverslot
	server_slot:SetPlayerId(newPlayer.id);

	--inform player about current game state (TODO: put in proper state & time)
	server_slot:SetGameState(0, 0);

	--set the player at the respawn point and set the starting health and stuff
	GameRules:RespawnPlayer(server_slot,newPlayer);
	Game:ForceScoreBoard(newPlayer.id, nil);
	server_slot.first_request=nil

end

-------------------------------------------------------
-------------------------------------------------------
function GameRules:OnClientDisconnect( server_slot )
	--remove the player from the team
	--remove the entity
	if(server_slot:GetPlayerId()~=0)then
		Server:RemoveEntity(server_slot:GetPlayerId());
		server_slot:SetPlayerId(0); -- set an invalid player id
	end

end

-------------------------------------------------------
-------------------------------------------------------
function GameRules:OnClientRequestRespawn( server_slot, requested_classid )

	--System:LogToConsole("Clicked!");

	--System:LogToConsole("time=".._time-self.TimeDied);
	if (_time-self.TimeDied<self.TimeRespawn) then
		--System:LogToConsole("time=".._time-self.TimeDied);
		return 
	end

	--hack to slow down the respawn (should this be inside the if-then below?)
	if(Game:ShowSaveGameMenu())then
		--System:Log('Game:ToggleMenu()')
		Game:SendMessage("Switch");
		return
	else
		System:Log("Game:ShowSaveGameMenu() returned nil")
	end

	if(server_slot.first_request)then

		local player;
		--for now I don't respawn the entity
		--create a new player entity
		local RespawnPoint = Server:GetRandomRespawnPoint();
		if(tonumber(gr_RespawnAtDeathPos)==1)then
			if(GameRules.player_death_pos)then
				RespawnPoint=GameRules.player_death_pos;
			end
		end
		local dir = {x = RespawnPoint.xA, y = RespawnPoint.yA, z = RespawnPoint.zA};
		local newPlayer=Server:SpawnEntity(requested_classid,RespawnPoint);
		newPlayer:SetAngles(dir);

		System:Log("player pos x="..RespawnPoint.x.." y="..RespawnPoint.y.." z="..RespawnPoint.z);
		System:Log("player angles x="..dir.x.." y="..dir.y.." z="..dir.z);


		if(server_slot:GetPlayerId()~=0)then
			Server:RemoveEntity(server_slot:GetPlayerId());
		end


		GameRules:RespawnPlayer(server_slot,newPlayer);
		server_slot:SetPlayerId(newPlayer.id)
		Game:ForceScoreBoard(newPlayer.id, nil);
	else
		server_slot.first_request=1;
	end
end

-- player requests to be killed (typed in the "kill" console command)
function GameRules:OnKill(server_slot)
    local id = server_slot:GetPlayerId();

    if id ~= 0 then
        local ent = System:GetEntity(id);
        self:OnDamage({ target = ent, shooter = ent, damage = 1000, ipart = 0 });
    end
end

-------------------------------------------------------
-------------------------------------------------------
function GameRules:OnClientJoinTeamRequest(server_slot,team_name)
		if(server_slot:GetPlayerId()~=0)then

			local requested_classid=1;
			local player=System:GetEntity(server_slot:GetPlayerId());

			if(team_name~=player:GetTeam())then

				if(team_name=="spectators")then
					requested_classid=SPECTATOR_CLASS_ID;
				end

				local newEntity=Server:SpawnEntity(requested_classid);

				Server:RemoveEntity(player.id);
				server_slot:SetPlayerId(newEntity.id);
				newEntity:SetTeam(team_name);

			end
		end
end

function GameRules:OnCallVote(server_slot, command, arg1)
	System:LogToConsole("vote called: "..command.." "..arg1);
	-- TODO: clone voting system from ffa rules.
end
