Script:LoadScript("scripts/default/hud/viewlayersmgr.lua")
ClientStuff={
	temp_layers={}
}
--------------------------------------------
function ClientStuff:OnInit()
	--LAYERS--------------------------------------------------------
	self.vlayers=ViewLayersMgr:new(),
	Script:LoadScript("scripts/default/hud/zoomview.lua");
	Script:LoadScript("scripts/default/hud/nightvision.lua");
	Script:LoadScript("scripts/default/hud/binoculars.lua");
	Script:LoadScript("scripts/default/hud/heatvision.lua");
	Script:LoadScript("scripts/default/hud/weaponscope.lua");
	Script:LoadScript("scripts/default/hud/motracklayer.lua");
	Binoculars:OnInit();
	NightVision:OnInit();
	MoTrackLayer:OnInit();
	self.vlayers:AddLayer("HeatVision",HeatVision);
	self.vlayers:AddLayer("NightVision",NightVision);
	self.vlayers:AddLayer("MoTrack",MoTrackLayer);
	self.vlayers:AddLayer("Binoculars",Binoculars);
	self.vlayers:AddLayer("WeaponScope",WeaponScope);
end
--------------------------------------------
function ClientStuff:OnReset()
	self.vlayers:DeactivateAll();
	_localplayer.cnt:SwitchFlashLight(0);
	self.cut_depth = 0;			-- fix 8
	self.cut_first_person = nil;
end
--------------------------------------------
-- fix 8 (MelkiyProd, 18 Oct 2026): cut scenes with the "no AI" flag (0x20 - in M03_OPT only the bomb scenes at the
-- end: placing_explosive, explosion_from_tunnel -> explosion_side_shot) put the local player into third person:
-- while the game's cut-scene flag is set, CPlayer's update writes first_person = 0 (CryGame.dll 0x25037316) and
-- nothing gives it back afterwards - after the scene the game stayed in third person. The view is remembered at
-- the start of the first cut scene (nested scenes: explosion_from_tunnel starts explosion_side_shot) and first
-- person is given back with Game:SetThirdPerson(0) when the last one has ended. A player who was in third person
-- before the scene stays in third person.
-- This file is the same in the game fixes and in the FOV scripts (the FOV line in OnUpdate does nothing without them).
function ClientStuff:OnBeginCutScene()
	if (not self.cut_depth or self.cut_depth == 0) then
		self.cut_depth = 0;
		self.cut_first_person = nil;
		if (_localplayer and _localplayer.cnt and _localplayer.cnt.first_person) then
			self.cut_first_person = 1;
		end
	end
	self.cut_depth = self.cut_depth + 1;
	self.temp_layers.HeatVision=self.vlayers:IsActive("HeatVision");
	self.temp_layers.NightVision=self.vlayers:IsActive("NightVision");
	self.temp_layers.MoTrack=self.vlayers:IsActive("MoTrack");
	self.temp_layers.Binoculars=self.vlayers:IsActive("Binoculars");
	self.temp_layers.WeaponScope=self.vlayers:IsActive("WeaponScope");
	self.vlayers:DeactivateAll();
	_localplayer.cnt:SwitchFlashLight(0);
end
--------------------------------------------
function ClientStuff:OnEndCutScene()
	for i,val in self.temp_layers do
		self.vlayers:ActivateLayer(i);
	end
	self.cut_depth = 0;			-- fix 8: the game calls this once, when its last cut scene has ended
	if (self.cut_first_person and _localplayer and _localplayer.cnt and (not _localplayer.cnt.first_person)) then
		Game:SetThirdPerson(0);
	end
	self.cut_first_person = nil;
end
--------------------------------------------
function ClientStuff:OnUpdate()
	self.vlayers:Update();
	if(ZoomView and ZoomView.IdleUpdate)then ZoomView:IdleUpdate(); end	-- FOV setting (cl_fov, cl_fov_wide)
end
--------------------------------------------
function ClientStuff:OnShutDown()
	
end


