--------------------------------------------------------------------
-- X-Isle Script File
-- Description: Defines the NightVision
-- Created by Lennert Schneider
--------------------------------------------------------------------

-- [wrapper v47 fix] shared motion blur suspend counter: night/heat vision and
-- zoom (binoculars, scope) switch e_motion_blur off while they are active and
-- the original value comes back when the last of them is off.
-- The same helper is defined in NightVision.lua, HeatVision.lua, ZoomView.lua.
if(not MotionBlurGuard)then MotionBlurGuard={count=0}; end
function MotionBlurGuard_Suspend()
	if(MotionBlurGuard.count==0)then
		MotionBlurGuard.saved=e_motion_blur;
		e_motion_blur=0;
	end
	MotionBlurGuard.count=MotionBlurGuard.count+1;
end
function MotionBlurGuard_Resume()
	if(MotionBlurGuard.count>0)then
		MotionBlurGuard.count=MotionBlurGuard.count-1;
		if(MotionBlurGuard.count==0 and MotionBlurGuard.saved)then
			e_motion_blur=MotionBlurGuard.saved;
			MotionBlurGuard.saved=nil;
		end
	end
end

NightVision = {
	IsActive = 0,
	
	ActivateSnd=Sound:LoadSound("sounds/items/nvisionactivate.wav"),
	amplification = 100,
	
	Static = 0.43,
	
	BlindnessValue=-1,
}

-------------------------------------------------------
function NightVision:OnInit()
	--NightVision.Mask=System:LoadImage("textures/Hud/NightVisionMulMask");
	NightVision.BlindMask=System:LoadImage("textures/Hud/NightVisionBlindMask");
	self.BlindnessValue=-1;	
end

-------------------------------------------------------
function NightVision:DrawLightning()
	-- The environment can be affected by lightning, which blinds any player 
	-- using Night Vision for a brief period. 

	if (self.BlindnessValue>0) then
		System:DrawImageColor(self.BlindMask, 0, 0, 800, 600, 4, 1,1,1,self.BlindnessValue);
		self.BlindnessValue=self.BlindnessValue-_frametime;
	else
		self.BlindnessValue=-1;
	end
end

-------------------------------------------------------
function NightVision:OnLightning()
	-- here I just set the lighting value because
	-- this function is called from outside some time during
	-- the frame, but the overlay mask for blindness must
	-- be drawn at the end of the frame on top of the already
	-- existing layers, in the already existing function DrawOverlay()

	self.BlindnessValue=1;
end

-------------------------------------------------------
function NightVision:DrawOverlay( DeltaTime )
	--System:DrawRectShader("NoiseMask", 0, 0, 800, 600, 1.0, 1.0, 1.0, self.Static);

	--System:DrawImage(self.Mask, 0, 0, 800, 600, 1);
	self:DrawLightning();
end

-------------------------------------------------------
function NightVision:OnActivate()
	if(not self.OldShadow)then
		System:SetScreenShader("NightMap");		
		Sound:PlaySound( self.ActivateSnd );
		LockToggle=1;
		self.original_color=new(System:GetWorldColor());
		local temp_color=new(self.original_color);
		temp_color[1]=temp_color[1]*self.amplification;
		temp_color[2]=temp_color[2]*self.amplification;
		temp_color[3]=temp_color[3]*self.amplification;
		System:SetWorldColor( temp_color );
		System:Log("Setting color ratio to"..self.amplification);
		self.OldShadow = e_shadow_maps;
		e_shadow_maps = 0;
		-- [wrapper v47 fix] motion blur reuses a stale screen copy while the
		-- night map is active (ghost image) - off while night vision is on
		if(not self.mb_off)then MotionBlurGuard_Suspend(); self.mb_off=1; end
	end
end
-------------------------------------------------------
function NightVision:OnDeactivate()
	if(self.OldShadow)then
		System:SetScreenShader("");
		Sound:StopSound( NightVision.ActivateSnd );
		LockToggle=0;
		System:Log("Setting color ratio to 0.1")
		System:SetWorldColor( self.original_color );
		e_shadow_maps = self.OldShadow;
		self.OldShadow=nil;
		if(self.mb_off)then MotionBlurGuard_Resume(); self.mb_off=nil; end
	end
end

-----------------------------------------------------
function NightVision:OnShutdown()
end