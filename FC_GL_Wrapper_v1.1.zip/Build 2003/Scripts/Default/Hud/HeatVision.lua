-- #Script.ReloadScript("scripts/default/hud/heatvision.lua")

--------------------------------------------------------------------
-- X-Isle Script File
-- Description: Defines the HeatVision
-- Created by Lennert Schneider
--------------------------------------------------------------------

-- [wrapper v47 fix] shared motion blur suspend counter: night/heat vision and
-- zoom (binoculars, scope) switch e_motion_blur off while they are active and
-- the original value comes back when the last of them is off.
-- The same helper is defined in NightVision.lua, HeatVision.lua, ZoomView.lua.
if(not MotionBlurGuard)then MotionBlurGuard={count=0}; end
function MotionBlurGuard_Suspend()
	if(MotionBlurGuard.count==0)then
		MotionBlurGuard.saved=e_motion_blur;
		e_motion_blur=0;
	end
	MotionBlurGuard.count=MotionBlurGuard.count+1;
end
function MotionBlurGuard_Resume()
	if(MotionBlurGuard.count>0)then
		MotionBlurGuard.count=MotionBlurGuard.count-1;
		if(MotionBlurGuard.count==0 and MotionBlurGuard.saved)then
			e_motion_blur=MotionBlurGuard.saved;
			MotionBlurGuard.saved=nil;
		end
	end
end

HeatVision = {
	IsActive = 0,
}

-------------------------------------------------------
function HeatVision:OnInit()
end

-------------------------------------------------------
function HeatVision:OnActivate()
	System:EnableHeatVision(1);
	System:SetScreenShader("HeatMap");
	if(not self.OldSun)then
		self.OldSun=e_sun;
		--e_sun=0;
		self.OldShadow = e_shadow_maps;
		e_shadow_maps = 0;
		-- [wrapper v47 fix] motion blur reuses a stale screen copy while the
		-- heat map is active (frozen image) - off while heat vision is on
		if(not self.mb_off)then MotionBlurGuard_Suspend(); self.mb_off=1; end
	end
end
-------------------------------------------------------
function HeatVision:OnDeactivate()
	System:EnableHeatVision(0);
	System:SetScreenShader("");
	if(self.OldSun)then
		e_sun=self.OldSun;
		e_shadow_maps = self.OldShadow;
		self.OldSun=nil;
		self.OldShadow=nil;
		if(self.mb_off)then MotionBlurGuard_Resume(); self.mb_off=nil; end
	end
end

-------------------------------------------------------
--function HeatVision:OnUpdate( DeltaTime )
	--local bSwitch = nil;
	--if ( HeatVision.IsActive ~= 0 ) then
		--System:SetScreenShader("HeatVisionLayer");
		-- subtract energy
		--local MyPlayer=_localplayer;
		--if ( MyPlayer ) then
			--MyPlayer.ChangeEnergy( MyPlayer, DeltaTime * -1 );
			--if ( MyPlayer.Energy == 0 ) then
--				bSwitch = 1;
	--		end
--		end
	--else
		--System:SetScreenShader("");
	--end
--end
-------------------------------------------------------
-- NOTE: self is HeatVision(the global table)
--call this function with this syntax "HeatVision:Toggle()"
function HeatVision:Toggle()
	self.IsActive = 1 - self.IsActive;
	if ( self.IsActive ~= 0 ) then
		self.OldSun=e_sun;
		--e_sun=0;
		Hud.VisionMode = VisionMode_HeatVision;
		self.OldShadow = e_shadow_maps;
		e_shadow_maps = 0;
	else
		e_sun=self.OldSun;
		Hud.VisionMode = VisionMode_Normal;
		e_shadow_maps = self.OldShadow;
	end
end
-------------------------------------------------------
function HeatVision:OnShutdown()
end