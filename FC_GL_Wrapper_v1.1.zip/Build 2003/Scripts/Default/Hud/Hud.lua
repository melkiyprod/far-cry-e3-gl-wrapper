Script:LoadScript("scripts/GUI/HudCommon.lua");

Hud.objectives={};

function Hud:PushObjective(pos,text)
	-- ignore an objective that is already in the list (checkpoint reload / trigger firing twice)
	local i;
	for i=1,getn(self.objectives) do
		if(self.objectives[i] and self.objectives[i].text==text)then
			return;
		end
	end
	self.objectives[getn(self.objectives)+1]={pos=new(pos),text=text,completed=nil}
end
-----------------------------------------------------------------------------
function Hud:FlashObjectives()
	self.objectives={}
end

-- [marco] remove it based on objective name
-----------------------------------------------------------------------------
function Hud:CompleteObjective(text)
	for i,val in self.objectives do
		if(val.text==text)then
			val.completed=1;
			-- break --in editor mode, there can be more than 1 with the same name
		end
	end
end


-----------------------------------------------------------------------------
function Hud:OnInit()
	System:Log("Hud:OnInit()");
	-- concentration
--	if (s_SFXVolume) then
--		g_GlobalSFXVolume=tonumber(s_SFXVolume);
--	else
--		g_GlobalSFXVolume=0;
--	end
	Game:CreateVariable("g_RadarRange",50);
	Game:CreateVariable("g_RadarRangeOutdoor",50);
	Game:CreateVariable("g_RadarRangeIndoor",20);
	Game:CreateVariable("g_RadarRangeChangeSpeed",1);
	Game:CreateVariable("g_SuspenseRange",50);
	Game:CreateVariable("g_NearSuspenseRangeFactor",0.25);
	Game:CreateVariable("g_ShowConcentrationStats",0);
	Game:CreateVariable("g_ConcentrationAmbientVolume",0.7);
	Game:CreateVariable("g_ConcentrationMissionVolume",1.0);
	Game:CreateVariable("g_ConcentrationNormalVolume",0.9);
	Game:CreateVariable("g_ConcentrationFadeInTime",3);
	Game:CreateVariable("g_ConcentrationFadeOutTime",5);
	
	self:CommonInit();	
end
-----------------------------------------------------------------------------
function Hud:OnUpdate()
	local player=_localplayer;

	-- [marco] The environment can be affected by lightning, which blinds any player 
	-- using Night Vision for a brief period. In case of the night vision
	-- is done in the above call.
	if(tonumber(cl_display_hud)~=0)then
		if(player and player.classname=="Player")then
			ClientStuff.vlayers:DrawOverlay();
		
	
			-- [kirill] blinding player with flashlight
			
			local	scrPos =player.cnt:GetBlindScreenPos();
			local curBlind = 10;		
			local curW = 200;
			local curH = 150;
			
			while( scrPos ~= nil ) do
				curBlind = scrPos.z;		
				curW = 200 + 450 * curBlind;
				curH = 150 + 450 * curBlind;
	--			System:DrawImageColor( self.flashlight_blinding, scrPos.x-curW*.5, scrPos.y-curH*.5, curW, curH, 5, curBlind,curBlind,curBlind,curBlind);						
				System:DrawImageColor( self.flashlight_blinding, scrPos.x-curW*.5, scrPos.y-curH*.5, curW, curH, 4, 1, 1, 1, curBlind);
				scrPos = player.cnt:GetBlindScreenPos();
			end	
			
	
			-- [marco] When we are bludgeoned/clawed/bitten, the screen should actually reflect 
			-- the placement of the appendage when it hit with a bloody-smear, giving 
			-- the player a better feeling of being actually hit.
			if (self.meleedamagefade>0) then
				System:DrawImageColor(self.bloodsmearimage, 0, 0, 800, 600, 4, 1,1,1,self.meleedamagefade);
				self.meleedamagefade=self.meleedamagefade-_frametime;
			else
				self.meleedamagefade=-1;
			end				
	
			-- [lennert] When a loud noise occurs (grenade etc.), the player will be deafened. Client-effect only...
			if (self.deaf_time) then
				--System:LogToConsole("deafened:"..self.deaf_time);
				local fSoundScale=1;
				if (self.deaf_time<self.deafness_fadeout_time) then
					fSoundScale=self.deaf_time/self.deafness_fadeout_time;
				end
				Sound:SetGroupScale(SOUNDSCALE_DEAFNESS, 1-fSoundScale);
				if (not Sound:IsPlaying(self.EarRinging)) then
					--System:Log("start ear ringing");
					Sound:PlaySound(self.EarRinging);
				end
				Sound:SetSoundVolume(self.EarRinging, fSoundScale*255);
				self.deaf_time=self.deaf_time-_frametime;
				if (self.deaf_time<=0) then
					self.deaf_time=nil;
					Sound:StopSound(self.EarRinging);
					Sound:SetGroupScale(SOUNDSCALE_DEAFNESS, 1);
				end
			end
			
			if(hud_crosshair=="1")then
				self:DrawCrosshair(player);
			end
			
			if(cl_display_hud == "0")then
				return
			end
			
			local wscope=ClientStuff.vlayers:IsActive("WeaponScope");
			--CONCENTRATION FEATURE----------------------------------------------
			if(self.sound_scale==nil)then
				self.sound_scale=1;
			end
			%System:DrawImage(self.noconcentration, 24, 538, 36, 36, 4);
			--if((stats.concentration~=nil) and (stats.moving==nil))then
			if (player.cnt.moving==nil) then
				if (self.sound_scale>0) then
					self.sound_scale=self.sound_scale-(_frametime/g_ConcentrationFadeInTime);
					if (self.sound_scale<0) then
						self.sound_scale=0;
					end
				end
			else
				if (self.sound_scale<1) then
					self.sound_scale=self.sound_scale+(_frametime/g_ConcentrationFadeOutTime);
				end
			end
			if (self.sound_scale<1) then
				local ss=1-self.sound_scale;
				local AmbientSoundVolume=ss*g_ConcentrationAmbientVolume+self.sound_scale*g_ConcentrationNormalVolume;
				local MissionSoundVolume=ss*g_ConcentrationMissionVolume+self.sound_scale*g_ConcentrationNormalVolume;
				if (g_ShowConcentrationStats~="0") then
					%Game:WriteHudString( 0, 300, format( "AmbientSoundVolume: %1.3f", AmbientSoundVolume), 1, 1, 1, 13, 26);
					%Game:WriteHudString( 0, 350, format( "MissionSoundVolume: %1.3f", MissionSoundVolume), 1, 1, 1, 13, 26);
					%Game:WriteHudString( 0, 400, format( "sound_scale: %1.3f", self.sound_scale), 1, 1, 1, 13, 26);
					%Game:WriteHudString( 0, 450, format( "Scale: %1.3f", AmbientSoundVolume/MissionSoundVolume), 1, 1, 1, 13, 26);
				end
				--s_SFXVolume=MissionSoundVolume*g_GlobalSFXVolume;
				--%Sound:SetMasterVolumeScale(AmbientSoundVolume/MissionSoundVolume);
				Sound:SetGroupScale(SOUNDSCALE_MASTER, MissionSoundVolume*s_SFXVolume);
				Sound:SetGroupScale(SOUNDSCALE_SCALEABLE, AmbientSoundVolume/MissionSoundVolume);
				--%System:DrawImageColor(Hud.ConcentrationIcon, 210, 558, 32, 32, 4,(ss)/0.5,ss/0.5,ss/0.5,ss/0.5);
				%System:DrawImageColor(self.concentration, 24, 538, 36, 36, 4,(ss)/0.5,ss/0.5,ss/0.5,ss/0.5);
				--Hud.label="I'm so concentrated (scale:"..self.sound_scale..")"
				--FIXME-- add some visual feedback
			else
				--Hud.label="I'm not concentrated (scale:"..self.sound_scale..")"
				self.sound_scale=1;
				--s_SFXVolume=g_ConcentrationNormalVolume*g_GlobalSFXVolume;
				--%Sound:SetMasterVolumeScale(1);
				Sound:SetGroupScale(SOUNDSCALE_MASTER, g_ConcentrationNormalVolume*s_SFXVolume);
				Sound:SetGroupScale(SOUNDSCALE_SCALEABLE, 1);
			end
			--infos
			%Game:SetHUDFont("hud", "ammo");
			if(not ClientStuff.vlayers:IsActive("Binoculars") and player.cnt.health>0)then
				self:DrawCompass(player);
			end
	
			self:DrawHealthBar(player.cnt.health,player.cnt.armor);
			
			self:DrawGrenade(player);
			--self:DrawItems();
			self:MessagesBox();
			self:DrawLabel();
			self:DrawStance(player,wscope);
			
			
			
			self:DrawAmmo(player);
			
			
			
			local vehicle=player.cnt:GetCurVehicle();
			if(vehicle)then
				self:DrawVehicleBar(vehicle.fEngineHealth);
			end
			
			
			self:DrawWeaponSlots(player);
	
	
			-- [marco] BREATH O METER-------------------------------------------------
			Hud:DrawBreathOMeter(770,450);
			
			-- [marco] Items-------------------------------------------------
			self:DrawItems(player);
			self:DrawRadarLayout(0,480);
			Hud:FlushCommon();
			self:DrawRadar(5, 489, 104, 102);
			
			
			-- GOD O METER-------------------------------------------------
			if(god and (tonumber(god)==1))then
				
				%Game:WriteHudString( 10, 48, "GOD "..GameRules.god_mode_count ,0, 1, 0, 30, 30);
			end
			-- SNEAK O METER ----------------------------------------------
			local sneak = AI:GetPerception();
			if (sneak > 0) and (sneak <= 110) then
				-- if the AI starts attacking we send a COMBAT-mood event
				Sound:AddMusicMoodEvent("Alert", MM_ALERT_TIMEOUT);
			end
			if (sneak > 110) then
				-- if the AI starts attacking we send a COMBAT-mood event
				Sound:AddMusicMoodEvent("Combat", MM_COMBAT_TIMEOUT);
			end
	
			--if (sneak > 110) then
			--	%Game:WriteHudString( 10, 10, "SEEN" ,1, 0, 0, 50, 50);
			--elseif (sneak > 50) then
			--	%Game:WriteHudString( 10, 10, "LOST" ,1, 1, 0, 50, 50);
			--else
			--	if (sneak>5) then
			--		%Game:WriteHudNumber( 10, 10, sneak*10 ,1, 0.5, 0.5, 50, 50);
			--	else
			--		%Game:WriteHudNumber( 10, 10, sneak*10 ,1, 1, 1, 50, 50);
			--	end
			--end
	
			if (self.PrevSneakValue) then
				if (self.PrevSneakValue>50) and (sneak==0) and (Sound:IsInMusicMood("Combat")) then
					-- if the sneak value drops instantly from combat to 0 we killed the last guy, so we send a VICTORY-mood event
					Sound:AddMusicMoodEvent("Victory", 0);
					System:Log("VICTORY !!!");
				end
			end
			self.PrevSneakValue=sneak;
			
			ScoreBoardManager:Render();
		end
	end	
	--moved panoramic display before hud visibility check because we need panoramic in cut-scenes and dont anything else
	if(hud_panoramic=="1")then
		%System:DrawImage(self.black_dot, 0, 0, 800, tonumber(hud_panoramic_height), 0);
		%System:DrawImage(self.black_dot, 0, 600-tonumber(hud_panoramic_height), 800, tonumber(hud_panoramic_height), 0);
	end
end


-----------------------------------------------------------------------------
function Hud:OnShutdown()
	%System:Log("Hud:OnShutdown()");
	self.EarRinging=nil;
end
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------


