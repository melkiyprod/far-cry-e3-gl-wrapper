-- [wrapper v47 fix] shared motion blur suspend counter: night/heat vision and
-- zoom (binoculars, scope) switch e_motion_blur off while they are active and
-- the original value comes back when the last of them is off.
-- The same helper is defined in NightVision.lua, HeatVision.lua, ZoomView.lua.
if(not MotionBlurGuard)then MotionBlurGuard={count=0}; end
function MotionBlurGuard_Suspend()
	if(MotionBlurGuard.count==0)then
		MotionBlurGuard.saved=e_motion_blur;
		e_motion_blur=0;
	end
	MotionBlurGuard.count=MotionBlurGuard.count+1;
end
function MotionBlurGuard_Resume()
	if(MotionBlurGuard.count>0)then
		MotionBlurGuard.count=MotionBlurGuard.count-1;
		if(MotionBlurGuard.count==0 and MotionBlurGuard.saved)then
			e_motion_blur=MotionBlurGuard.saved;
			MotionBlurGuard.saved=nil;
		end
	end
end

ZoomView={
	IsActive = 0,
	--Zoomable = 1,
	NoZoom = 90 * 3.1415962 / 180,
	CurrZoomStep = 1,
	MaxZoomSteps = 1,
	ZoomSteps={ NoZoom },
	Sway = 0.0,
	MinSway = 0.2,
	MaxSway = 0.4,
	SwayInc = 1,
	StanceSwayModyfier = 1.0,
	AddZoom = 0.0,
};
--------------------------------------------------------
-- FOV setting (MelkiyProd, Far Cry E3 GL wrapper package v87)
--   cl_fov      = field of view as on a 4:3 screen, 60..130 (90 = the original game)
--   cl_fov_wide = 1: wider view on wide screens - the height of the picture stays as on 4:3 and the screen
--                 width is added at the sides (16:10 -> 108, 16:9 -> 120); 0 = the number as it is (original)
-- The engine makes the vertical angle = fov * height / width, so without this a wide screen cuts the top and
-- bottom off. Scopes and binoculars keep their magnification (they divide this base value).
if(cl_fov==nil)then Game:CreateVariable("cl_fov","90"); end
if(cl_fov_wide==nil)then Game:CreateVariable("cl_fov_wide","1"); end
-- cl_fov_smooth = 1: aiming in / out (iron sights) eases in and out; the way out takes 0.4 s (as long as the
-- weapon takes to come back) and ends exactly on the base value; the weapon (WeaponScope.lua) follows the same curve. 0 = as the original: linear in, accelerating out with a last step that stops for one frame
-- and then jumps (the "jerk" at the end of aiming).
if(cl_fov_smooth==nil)then Game:CreateVariable("cl_fov_smooth","1"); end
-- the GL wrapper writes fc_gl_fov.lua at every start from fc_gl.ini [graphics] fov / fov_wide / fov_smooth
-- (fov = auto / e3 / 60..130 / game); loaded here, so at game start and at every level load
Script:LoadScript("fc_gl_fov.lua");
function ZoomView:BaseFov()
	local f=tonumber(cl_fov);
	if(f==nil)then f=90 end
	if(f<60)then f=60 end
	if(f>130)then f=130 end
	if(tonumber(cl_fov_wide)~=0)then
		local w=tonumber(r_Width);
		local h=tonumber(r_Height);
		if(w and h and h>0)then
			local k=(w/h)/(4/3);
			if(k>1)then f=f*k end
		end
	end
	if(f>170)then f=170 end
	self.NoZoom=f*3.1415962/180;
	return self.NoZoom;
end
-- called every frame by ClientStuff:OnUpdate: applies the base field of view when it changes (console,
-- resolution) or when the engine has set its own default of 90 again (level load, new player)
function ZoomView:IdleUpdate()
	if(self.active)then return end
	local f=self:BaseFov();
	local key=tostring(cl_fov).."/"..tostring(cl_fov_wide).."/"..tostring(r_Width).."/"..tostring(r_Height);
	local cur=Game:GetCameraFov();
	local stock=(cur~=nil) and (abs(cur-1.5707981)<0.001) and (abs(f-cur)>0.001);
	if((key~=self.fov_key) or (self.fov_player~=_localplayer) or stock)then
		if(stock and (key==self.fov_key) and (self.fov_player==_localplayer))then
			System:Log("FOV: the engine set its 90 again - back to "..tostring(f*180/3.1415962));
		end
		self.fov_key=key;
		self.fov_player=_localplayer;
		Game:SetCameraFov(f);
	end
end
--------------------------------------------------------
function ZoomView:OnInit()
	Game:CreateVariable("h_zoom_speed");
	h_zoom_speed = 250 * 3.1415962 / 180;
	Game:CreateVariable("h_zoom_sway",1); 
end

-- smooth transitions: time since the last call, at most 0.025 s - a slow frame (stutter) then does not make the
-- view jump by a bigger step, the transition just takes a little longer
function ZoomView:FadeDt(last)
	local dt=_time-last;
	if(dt<0)then dt=0 end
	if(dt>0.025)then dt=0.025 end
	return dt;
end
function ZoomView:Reset()
	self:BaseFov();
	Game:SetCameraFov( self.NoZoom);
end
--------------------------------------------------------
function ZoomView:Activate(_keymap,_sway,_fixedfactor,_fade)
	self:BaseFov();
	self.fade_in_k=nil;
	self.fade_out_k=nil;
	self.AddZoom=0;
	if (_sway==nil) then
		_sway=0;
	end
	
	self.Sway = _sway;
	self.MinSway = _sway*0.5;
	
	System:Log("ACTIVATE self.MinSway'"..self.MinSway.."' * self.StanceSwayModyfier'"..self.StanceSwayModyfier.."'");
		
	if ( _keymap == nil ) then		-- no keymap specified => use default zoom map
		_keymap = "zoom";
	end
	
	Input:SetMouseSensitivityScale( 0.3 );
	self.ZoomOverlayFunc =_overlay;
	self.FixedFactor=_fixedfactor;
	local player = _localplayer;
	
	if ( _sway ) then
		player.cnt:SetSwayAmp( _sway );
		player.cnt:SetSwayFreq( 0.6 );
	end
	local stats = player.cnt;
	stats.zoom = 1;
	if(_fade)then
		self.fade=self.ZoomSteps[self.CurrZoomStep];
		self.fade_start=_time;
		self.fade_acc=0;
		self.fade_last=_time;
		self.fade_in_k=0;
		Game:SetCameraFov( self.NoZoom);
	else
		Game:SetCameraFov( self.NoZoom / self.ZoomSteps[self.CurrZoomStep] );
	end
	Input:SetActionMap(_keymap);
	self.active=1;
	-- [wrapper v47 fix] motion blur + binocular/scope lens distortion gives
	-- dark rings - off while zoomed (binoculars and weapon scopes)
	if(not self.mb_off)then MotionBlurGuard_Suspend(); self.mb_off=1; end
end
--------------------------------------------------------
function ZoomView:OnUpdate()
	self:BaseFov();
	if(tonumber(h_zoom_sway)~=0)then
		_localplayer.cnt:SetSwayAmp(self.MinSway * self.StanceSwayModyfier);
	else
		_localplayer.cnt:SetSwayAmp(0);
	end
	
	local ZoomTmp = (self.AddZoom / 50);
	if(ZoomTmp<0) then
		ZoomTmp=0;
	end
	
	if(self.fade)then
		local delta=_time-self.fade_start;
		if((tonumber(cl_fov_smooth)~=0) and self.fade_acc)then
			self.fade_acc=self.fade_acc+self:FadeDt(self.fade_last);
			self.fade_last=_time;
			delta=self.fade_acc;
		end
		local target = self.NoZoom/self.ZoomSteps[self.CurrZoomStep];
		local diff = self.NoZoom-target;
		local factor;	
		if(delta>=0.5)then
			self.fade=nil
			delta=0.5
		end
		factor=delta/0.5;
		if(tonumber(cl_fov_smooth)~=0)then factor=factor*factor*(3-2*factor); self.fade_in_k=factor; end
		self.currfov=self.NoZoom-(diff*factor);
		Game:SetCameraFov(self.currfov);
		
	else
		self.currfov=(self.NoZoom/self.ZoomSteps[self.CurrZoomStep]-ZoomTmp)
		Game:SetCameraFov(self.currfov);
	end
end
--------------------------------------------------------
function ZoomView:Deactivate()
	self:BaseFov();
	self.active=nil;
	self.FixedFactor=nil;
	self.AddZoom=0;
	Input:SetMouseSensitivityScale( 1.0 );
	local player = _localplayer;
	player.cnt:SetSwayAmp( 0 );
	local stats = player.cnt;
	stats.zoom = 0;
	Game:SetCameraFov( self.NoZoom );
	Input:SetActionMap( "default" );
	self.fading=nil;
	if(self.mb_off)then MotionBlurGuard_Resume(); self.mb_off=nil; end
end
--------------------------------------------------------
function ZoomView:FadeOut()
	self:BaseFov();
	if(self.currfov==nil) then self.currfov=self.NoZoom end
	if(tonumber(cl_fov_smooth)~=0)then
		if(not self.active)then
			-- not aiming (the game also calls this when a weapon is put away): nothing to fade, done at once -
			-- otherwise the weapon would be held in its aiming position during the switch animation
			self:Deactivate();
			return 1;
		end
		if(not self.fading)then
			self.fading=self.currfov-self.NoZoom;
			self.fading_time=_time
			self.fading_acc=0;
			Input:SetActionMap( "default" );
		end
		self.fading_acc=self.fading_acc+self:FadeDt(self.fading_time);
		self.fading_time=_time;
		local t=self.fading_acc/0.4;
		if((t>=1) or (self.fading>=-0.0001))then
			self.fade_out_k=0;
			self.currfov=self.NoZoom;
			self:Deactivate();
			return 1;
		end
		t=t*t*(3-2*t);
		self.fade_out_k=1-t;
		self.currfov=self.NoZoom+self.fading*(1-t);
		Game:SetCameraFov( self.currfov );
		return
	end
	if(not self.fading)then
		self.fading=self.currfov-self.NoZoom;
		self.fading_time=_time
		Input:SetActionMap( "default" );
	else
		if((self.currfov-self.NoZoom)>=0)then
			self:Deactivate();
			return 1;
		else
			self.currfov=self.currfov+abs(self.fading*((_time-self.fading_time)));
			if(self.currfov>self.NoZoom)then return end
			Game:SetCameraFov( self.currfov );
		end
	end
end
--------------------------------------------------------
function ZoomView:ZoomIn()
	if (self.active and self.FixedFactor==nil) then
		self:BaseFov();
		System:Log("ZoomIn")
		self.CurrZoomStep = self.CurrZoomStep + 1;
		if ( self.CurrZoomStep > self.MaxZoomSteps ) then
			self.CurrZoomStep = self.MaxZoomSteps;
		end
		Game:SetCameraFov( self.NoZoom / self.ZoomSteps[self.CurrZoomStep]);
	end
end
--------------------------------------------------------
function ZoomView:ZoomOut()
	if (self.active and self.FixedFactor==nil) then
		self:BaseFov();
		self.CurrZoomStep = self.CurrZoomStep - 1;
		if ( self.CurrZoomStep < 1 ) then
			self.CurrZoomStep = 1;
		end
		Game:SetCameraFov( self.NoZoom / (self.ZoomSteps[self.CurrZoomStep]) );
	end
end
--------------------------------------------------------
function ZoomView:IsActive()
	return self.active;
end
