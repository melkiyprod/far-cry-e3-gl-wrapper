WeaponScope={
	overlay_func=nil,
	v_000={x=0,y=0,z=0},
	v_01010={x=0.11,y=0.09,z=0.05},
	v_M4={x=0.09,y=0.01,z=0.03},
	temp={},
	v_out_of_the_view={x=-100,y=0,z=0},
	LastZoom=1
}
-------------------------------------------------------
function WeaponScope:OnActivate()
	
	local w=_localplayer.cnt.weapon;
	if(w)then
	
		System:Log("Aiming = TRUE");
		_localplayer.cnt.aiming=1;
		
		if(w.ZoomOverlayFunc)then
			self.overlay_func=w.ZoomOverlayFunc;
		else
			self.overlay_func=DefaultZoomHUD.DrawHUD
			--FIX THIS
			DefaultZoomHUD.MulMask = _localplayer.fireparams.ScopeTexId
		end
		
		_localplayer.cnt.bForceWalk = 1;
		
		if ( w.MaxZoomSteps ) then
			ZoomView.MaxZoomSteps = w.MaxZoomSteps;
			ZoomView.ZoomSteps = w.ZoomSteps;
		else
			ZoomView.MaxZoomSteps = 3;
			ZoomView.ZoomSteps = { 2, 4, 6 };
		end
		
		if(w.DoesFTBSniping)then
			self.fade=_time;
			self.has_aimmode=1;
			ZoomView.CurrZoomStep = 1;
		elseif(w.AimMode)then
			self.fade=_time;
			self.has_aimmode=1;
			ZoomView.CurrZoomStep = 1;
		else
			self.has_aimmode=nil;
			ZoomView.CurrZoomStep=min(self.LastZoom,ZoomView.MaxZoomSteps);
			_localplayer.cnt.drawfpweapon=nil;
			w.cnt:SetFirstPersonWeaponPos(self.v_out_of_the_view,self.v_000);	
		end
		
		if(w.DoesFTBSniping)then
			w:StartAnimation(0,"StartSniping",0,0);
		else
			System:Log("ZoomView:Activate");
			ZoomView:Activate(nil,w.Sway,w.ZoomFixedFactor,w.AimMode);
		end
		
	end
end
-------------------------------------------------------
function WeaponScope:OnDeactivate()
	local w=_localplayer.cnt.weapon;
	r_ScreenRefract=0
	self.LastZoom=ZoomView.CurrZoomStep;
	ZoomView:Deactivate();
	_localplayer.cnt.bForceWalk=nil;
	_localplayer.cnt.drawfpweapon=1;
	System:Log("Aiming = NIL");
	_localplayer.cnt.aiming=nil;
	if(w)then w.cnt:SetFirstPersonWeaponPos(self.v_000,self.v_000);end
end
-------------------------------------------------------
function WeaponScope:OnFadeOut()
	local w=_localplayer.cnt.weapon;
	r_ScreenRefract=0
	if(not self.has_aimmode)then 
		self:OnDeactivate(); 
		return 1 
	elseif(ZoomView:FadeOut())then
		self:OnDeactivate();
		return 1;
	end
	
	if(self.has_aimmode)then
		local pos=self.temp;
		pos.x=self.v_01010.x;
		pos.y=self.v_01010.y;
		pos.z=self.v_01010.z;
		
		--quick hack made for Marc(Ubi)
		if(w.name=="M4")then
			pos.x=self.v_M4.x;
			pos.y=self.v_M4.y;
			pos.z=self.v_M4.z;
		end
		if((tonumber(cl_fov_smooth)~=0) and ZoomView.fade_out_k)then
			-- FOV setting (cl_fov_smooth 1): the weapon comes back on the same curve as the view and arrives together
			-- with it (the original moved it for 0.4 s while the view was back after ~0.2 s at 60 FPS - the weapon
			-- then jumped the rest of the way: the jerk after letting go of the aim)
			ScaleVectorInPlace(pos,ZoomView.fade_out_k);
		elseif(self.deactivate_fade and (_time-self.deactivate_fade<0.4))then
			ScaleVectorInPlace(pos,abs(0.4-(_time-self.deactivate_fade))/0.4);
		end
		w.cnt:SetFirstPersonWeaponPos(pos,self.v_000);	
	end
end
-------------------------------------------------------
function WeaponScope:DrawOverlay()
	
	if((self.overlay_func and (not self.fade))
	or (self.fade and self.state~=1))then
		self:overlay_func(ZoomView.CurrZoomStep);
	end
	if (self.DoesFTBSniping and self.state~=1) then
		FTBSniping:OnEnhanceHUD();
	end
end
-------------------------------------------------------
function WeaponScope:OnUpdate()
	
	local w=_localplayer.cnt.weapon;
	if ((w.DoesFTBSniping and self.state==2) or (not w.DoesFTBSniping)) then
		ZoomView:OnUpdate();
	end
	
	if (w.DoesFTBSniping) then
		
		if(_time-self.fade<0.4)then
			System:Log("STATE 1");
			self.state=1;
			ZoomView:Reset()
		else
			if(self.state==1)then
				System:Log("STATE 1 >> STATE 2");
				self.state=2;
				_localplayer.cnt.drawfpweapon=nil;
				System:Log("ZoomView:Activate");
				ZoomView:Activate(nil,w.Sway,w.ZoomFixedFactor,w.AimMode);
				FTBSniping:OnActivate();
				-- [wrapper v47 fix] no scope lens while night/heat vision is on:
				-- it uses a screen copy that is not refreshed then (frozen image)
				if(ClientStuff.vlayers:IsActive("NightVision") or ClientStuff.vlayers:IsActive("HeatVision"))then
					r_ScreenRefract=0
				else
					r_ScreenRefract=2
				end
			end
			if (_localplayer.cnt.proning) then
				ZoomView.StanceSwayModyfier = _localplayer.SwayModyfierProning;
			elseif (_localplayer.cnt.crouching) then
				ZoomView.StanceSwayModyfier = _localplayer.SwayModyfierCrouching;
			else
				ZoomView.StanceSwayModyfier = 1.0;
			end
			FTBSniping:OnUpdate();
		end
		
	end
	if(w.AimMode)then
		local pos=self.temp;
		pos.x=self.v_01010.x;
		pos.y=self.v_01010.y;
		pos.z=self.v_01010.z;
		
		--quick hack made for Marc(Ubi)
		if(w.name=="M4")then
			pos.x=self.v_M4.x;
			pos.y=self.v_M4.y;
			pos.z=self.v_M4.z;
		end
		if((tonumber(cl_fov_smooth)~=0) and ZoomView.fade_in_k)then
			ScaleVectorInPlace(pos,ZoomView.fade_in_k);		-- FOV setting: on the same curve as the view
		elseif(self.fade and (_time-self.fade<0.5))then
			ScaleVectorInPlace(pos,(_time-self.fade)/0.5);
		end
		self.deactivate_fade=_time;
		w.cnt:SetFirstPersonWeaponPos(pos,self.v_000);	
	end
end