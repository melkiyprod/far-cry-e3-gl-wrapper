-- #Script.ReloadScript("scripts/default/entities/player/basicplayer.lua")

BasicPlayer =	 {
---------------------------------------------- common data
  	type = "Player",

	--speedRun = 7,
	--speedWalk = 4,
	--speedCrouch = 3,
	--speedProne = .6,
	--jumpForce = 4.3,
	--lean = 9,

	proneMinAngle = -25,
	proneMaxAngle = 25,

	normMinAngle = -85,
	normMaxAngle = 85,

	--bobPitch = 0.015,
	--bobRoll = 0.035,
	--bobLength = 5.5,
	--bobWeapon = 0.002,

	isPhysicalized = 0,

	holdedWeapon = nil,

	deathImpuls = {x=0,y=0,z=0},
	deathImpulseTorso = 0,
	deathPoint = {x=0,y=0,z=0},
  deathImpulsePart = 0,


	DTExplosion = 0,
	DTSingleP = 1,
	DTSingle = 2,
	DTRapid = 3,

	painSound = nil,
	downSound = 0,

	isProning = 0,
	InWater	= 0,
	isRefractive = 0,

	UpdateTime = 700,

	--	number of updates to move in bush to have max bush sound volume.Time would be UpdateTime*BushSoundScale
	BushSoundScale = 10,
	--  internal counter of updates
	BushInCounter = 0,
	--	the same for AI
	BushSoundScaleAI = 10,
	BushInCounterAI = 0,

	--in seconds
	drown_time=20,

	-- falling damage
	-- if land speed is greater than FallDmgS dammage will be applyed.
	-- ammount of damage is (landSpeed - FallDmgS)*FallDmgK
	-- speed = sqrt(2*9.8*height)
	FallDmgS = 12.5, -- default 7.67
	FallDmgK = 10.15, -- default 17.15

	-- collision damage coefficient
	CollisionDmg = .5, 


	-- protection stuff
	hasHelmet = 0,
--	hasArmor = 0,

--	bushSndTime=0,
--	bushSndTimeAI=0,

	-- flash light parametrs
--	lightFileShader="LightBeam",
--	lightFileTexture="Textures/Lights/Light_testgrid",
	
--	lightFileShader="sun_midday",
	lightFileShader="",	
	lightFileTexture="Textures/Lights/flashlight3",
--	lColor={1.0,1.0,1.0},
--	lightFlag	= 192,


	AnimationBlendingTimes={
		{"srunfwd",						.31},
		{"srunback",					.23},
		{"arunfwd",						.35},
		{"arunback",					.33},
		{"srunback_utaim",		.2},
		{"srunback_utshoot",	.2},
	},

	PainAnimations =
	{
		"pain_head",
		"pain_torso",
		"pain_larm",
		"pain_rarm",
		"pain_lleg",
		"pain_rleg"
	},


--	theWeapon = 0,

---------------------------------------------- common data over

--	sndUnderwaterAmbient = Sound:LoadSound("sounds/player/water/UnderwaterAmbient.wav"),

	soundScale = {
		run = 0.8,
		walk = 0.6,
		crouch = 0.4,
		prone = 0.3,
	},

	soundRadius = {
		run = 12,
		walk = 6,
		crouch = 1,
		prone = 1,
	},

	DynProp = {
		air_control = 0.4,  -- default 0.6
		gravity = 9.81,
		swimming_gravity = -1.0,
		inertia = 10.0,
		swimming_inertia = 1.0,
		nod_speed = 60.0,
		min_slide_angle = 46,
		max_climb_angle = 60,
		min_fall_angle = 70,
		max_jump_angle = 55,
	},

	sndWaterSwim = Sound:LoadSound("sounds/player/water/newswim2lp.wav"),
	--{
	--	Sound:LoadSound("sounds/player/footsteps/water/step1.wav"),
	--	Sound:LoadSound("sounds/player/footsteps/water/step2.wav"),
	--	Sound:LoadSound("sounds/player/footsteps/water/step3.wav"),
	--	Sound:LoadSound("sounds/player/footsteps/water/step4.wav"),
	--},

	sndUnderwaterNoise = Sound:LoadSound("sounds/player/water/underwaterloop.wav"),
	
	sndUnderWaterSplash = 	Sound:LoadSound("sounds/player/water/underwatersplash.wav"),

	sndWaterSplash = Sound:LoadSound("sounds/player/water/WaterSplash.wav"),	
	
	sndBreathIn = {
		Sound:LoadSound("sounds/player/breathin.wav"),
	},

	WaterRipples = {
		focus = 0.2,
		color = {1,1,1},
		speed = 0.0,
		count = 1,
		size = 0.15, size_speed=0.6,
		gravity=0,
		lifetime=3,
		tid = System:LoadTexture("textures\\ripple.dds"),
		frames=0,
		color_based_blending = 1,
		particle_type = 1,
	},

	WaterSplash = {
		focus = 3,
		color = {1,1,1},
		speed = 10,
		count = 140,
		size = 0.025, size_speed=0,
		gravity=1,
		lifetime=0.5,
		tid = 0,
		frames=0,
		color_based_blending = 0

	},

	--Steve, put some switcc souds for flight here	
	fLightSound = Sound:Load3DSound("SOUNDS/items/flight.wav",SOUND_UNSCALABLE,160,3,30),


  BulletImpactParams = {
    stiffness_scale = 73,
    max_time_step = 0.01
  },

  -- these values set the speed at which the heat intensity
  -- for bodies and weapons will fade between the previous values and the new values
  -- these values should be always positive (the handling of fading between positive
  -- and negative values is inside the C++ code)
  -- see the function OnBeginDeadState()
  -- use the value -1 to set immediately the new value without fading
  fHeatFadePlayerIntensity=0.002, -- this is affecting the player and enemies -- default .002
  fHeatFadeWeaponsIntensity=0.2, -- this is affecting the weapons -- default 0.2

}

--////////////////////////////////////////////////////////////////////////////
function BasicPlayer:OnBeginDeadState()
	-- when he dies set heat intensity for player to minimum gradually
	self.cnt:SetHeatVisionValues("HeatIntensity",0,BITMASK_PLAYER,self.fHeatFadePlayerIntensity);
	self:ReleaseLipSync();	-- we dont want the corpse to say anything...
end


--////////////////////////////////////////////////////////////////////////////
function BasicPlayer:OnBeginAliveState()
	-- at the beginning set heat intensity for player to maximum immediately
	self.cnt:SetHeatVisionValues("HeatIntensity",1,BITMASK_PLAYER,-1);
	self:DoRandomExpressions("Scripts/Expressions/DefaultRandomExpressions.lua", 0);
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:OnReset()

	merge( self, BasicPlayer );
	self["AddAmmo"]=BasicPlayer.AddAmmo;
	self.bShowOnRadar=nil;	-- dont show on radar by default...
	local stats = self.cnt;

	local nMaterialID=Game:GetMaterialIDByName("mat_flesh");
	self:CreateLivingEntity(self.PhysParams, nMaterialID);
	self:PhysicalizeCharacter(self.PhysParams.mass, nMaterialID, self.BulletImpactParams.stiffness_scale, 0);
	self:SetCharacterPhysicParams(0,"", PHYSICPARAM_SIMULATION,self.BulletImpactParams);
	self.isPhysicalized = 1;

	self.LastFootStepTime=0;

	--System:Log("--> OnReset() Called !");

	local CurWeaponInfo = self.weapon_info;
	if (CurWeaponInfo) then
		local tempfiremode = self.cnt.firemode+1;
		local w = self.cnt.weapon;
		if (w) then
			local CurFireParams = w.FireParams[tempfiremode];
			local SoundData = CurWeaponInfo.SndInstances[tempfiremode];
			if (SoundData) then
				BasicWeapon.StopFireLoop(CurWeapon, self, CurFireParams, SoundData);
				--System:Log("--> Fire Loop Stopped OnReset() !");
			end
		end
	end


	stats:SetCurrWeapon( 1 );

	stats:SetDimNormal(self.PlayerDimNormal);
	stats:SetDimCrouch(self.PlayerDimCrouch);
	stats:SetDimProne(self.PlayerDimProne);

	stats:SetMinAngleLimitV( self.normMinAngle );
	stats:SetMaxAngleLimitV( self.normMaxAngle );
	stats:EnableAngleLimitV( 1 );
	stats:EnableAngleLimitH( nil );

	self.cnt:SetAnimationRefSpeedRun(	self.AniRefSpeeds.RunFwd,
																		self.AniRefSpeeds.RunSide,
																		self.AniRefSpeeds.RunBack);
	self.cnt:SetAnimationRefSpeedWalk(self.AniRefSpeeds.WalkFwd,
																		self.AniRefSpeeds.WalkSide,
																		self.AniRefSpeeds.WalkBack);
	self.cnt:SetAnimationRefSpeedWalkRelaxed(self.AniRefSpeeds.WalkRelaxedFwd,
																		self.AniRefSpeeds.WalkRelaxedSide,
																		self.AniRefSpeeds.WalkRelaxedBack);
	self.cnt:SetAnimationRefSpeedXWalk(self.AniRefSpeeds.XWalkFwd,
																		self.AniRefSpeeds.XWalkSide,
																		self.AniRefSpeeds.XWalkBack);
	self.cnt:SetAnimationRefSpeedCrouch(self.AniRefSpeeds.CrouchFwd,
																		self.AniRefSpeeds.CrouchSide,
																		self.AniRefSpeeds.CrouchBack);


	--stats.SetRunSpeed( self.speedRun );
	--stats.SetWalkSpeed( self.speedWalk );
	--stats.SetCrouchSpeed( self.speedCrouch );
	--stats.SetProneSpeed( self.speedProne );

	--stats.SetJumpForce( self.jumpForce );
	--stats.SetLean( self.lean );
	--stats.SetCameraBob( self.bobPitch, self.bobRoll, self.bobLength );
	--stats.SetWeaponBob( self.bobWeapon );

	stats:SetDynamicsProperties( self.DynProp );

	stats.health = self.Properties.max_health;
	stats.max_health = GameRules.InitialPlayerStats.health;
	stats.armor = GameRules.InitialPlayerStats.armor;
	stats.max_armor = 100;

	self:EnablePhysics(1);

	self:GotoState( "Alive" );
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Server_OnInit()
	System:Log("function BasicPlayer:Server_OnInit()");
	-- Only when the player spawns the first time
	if (self == _localplayer and _LastCheckPPos == nil) then
		_LastCheckPPos = self:GetPos();
	end
	self.GrenadeType=GrenadesClasses[self.cnt.grenadetype];
	self:RegisterStates( self );
	BasicPlayer.OnReset( self );

	BasicPlayer.InitAllWeapons(self);

	self.MyInventory = new( Inventory );
	Game:CreateVariable("p_max_vert_angle");
	p_max_vert_angle=90;

	if(self.isPhysicalized == 0) then
		local nMaterialID=Game:GetMaterialIDByName("mat_flesh");
		self:PhysicalizeCharacter(self.PhysParams.mass, nMaterialID, self.BulletImpactParams.stiffness_scale, 0);
		self:SetCharacterPhysicParams(0,"", PHYSICPARAM_SIMULATION,self.BulletImpactParams);
		self.isPhysicalized = 1;
	end

	self.Refractive = nil;
	self.fLastRefractValue = 0;
	self.vLastPos = self:GetPos();

	self.GrenadeThrowFrame=12;

	System:LogToConsole("player "..self.id.." SetTimer");
	self:SetTimer(self.UpdateTime);

end


-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Client_OnInit()

	System:Log("function BasicPlayer:Client_OnInit()");
	BasicPlayer.OnReset( self );

	System:Log(" calling SetAnimationKeyEvent ");

	if(self.SoundEvents) then
		for i,event in self.SoundEvents do
			self:SetAnimationKeyEvent(event[1],event[2],event[3]);
			--System:Log("registering animation key "..event[1].."/"..event[2]);
			if(event[4]~=nil)then
				Sound:SetSoundVolume(event[3],event[4]);
			end
		end
	end

	if(self.AnimationBlendingTimes) then
		for k,blends in self.AnimationBlendingTimes do
			self.cnt:SetBlendTime(blends[1],blends[2]);
		end
	end

	self:RegisterStates();
	self:GotoState( "Alive" );

	BasicPlayer.InitAllWeapons(self);

	self.Refractive = nil;
	self.fLastRefractValue = 0;
	self.vLastPos = self:GetPos();

	if(self.isPhysicalized == 0) then
		local nMaterialID=Game:GetMaterialIDByName("mat_flesh");
		self:PhysicalizeCharacter(self.PhysParams.mass, nMaterialID, self.BulletImpactParams.stiffness_scale, 0);
		self:SetCharacterPhysicParams(0,"", PHYSICPARAM_SIMULATION,self.BulletImpactParams);
		self.isPhysicalized = 1;
	end
	Input:SetActionMap("default");

	self.GrenadeThrowFrame=12;

	self:RenderShadow( 1 ); -- enable rendering of player shadow

--	self.hasHelmet = self.Properties.bHelmetOnStart;
--	if(self.Properties.bHelmetOnStart == 1)	then
--		BasicPlayer.HelmetOn(self);
--		self.AttachObjectToBone( 0, "hat_bone" );
--	end

--	self:InitDynamicLight(self.lightFileTexture, self.lightFileShader);
	self.cnt:InitDynamicLight(self.lightFileTexture, self.lightFileShader);
	System:LogToConsole("player "..self.id.." SetTimer CLI");
	self:SetTimer(self.UpdateTime);

--	self.cnt:SetAnimationRefSpeed(4.15, 1.2728, 1.2554, 0.4705);

--	self.cnt:SetAnimationRefSpeedRun(4.62, 3.57, 3.6 );
--	self.cnt:SetAnimationRefSpeedWalk(1.27, 1.22, 1.29 );
--	self.cnt:SetAnimationRefSpeedXWalk(1.2, 1.0, 0.94 );
--	self.cnt:SetAnimationRefSpeedCrouch(1.02, 1.02, 1.04 );


	System:Log("function BasicPlayer:Client_OnInit() end");
end

function BasicPlayer:InitAllWeapons()

	
	-- Everytime AddWeapon() is called every active player entity gets
	-- ScriptInitWeapon() called for the new weapon. The name is also placed in
	-- the global WeaponsLoaded table. So new players need to traverse the list
	-- of recently spawned weapons themself and call ScriptInitWeapon() for each
	-- of them. Also, the player entity needs to call MakeWeaponAvailable() for
	-- each weapon in his weapon pack

	-- Check to prevent double initialize for local client
	 --if (self.bAllWeaponsInititalized ~= nil) then
		--return
	 --end

	 
	System:Log("BasicPlayer:InitAllWeapons");
	--System:Log("InitAllWeapons "..self:GetName());
	-- Let the container initialize the C/C++ strutures for all weapons
	self.cnt:InitWeapons();

	-- Main player doesn't have an equipEquipment property, copy from global
	-- table
--	System:LogToConsole(MainPlayerEquipPack);
	if ((self.Properties.equipEquipment == nil) or (self==_localplayer)) then
		self.Properties.equipEquipment = MainPlayerEquipPack;
	end





	self.Ammo={};
	for i,val in MaxAmmo do
		self.Ammo[i]=0;
	end
	local primary_weapon;
	-- Copy initial ammo table from equip pack
	if (self.Properties.equipEquipment) then
		--System:Log("LOADING EQUIP PACK "..self.Properties.equipEquipment);
		local WeaponPack = EquipPacks[self.Properties.equipEquipment];
		if (WeaponPack) then
			merge(self.Ammo,WeaponPack.Ammo);
		--System:Log("DUMPING AMMO");
		--for i,val in WeaponPack.Ammo do
			--System:Log(i.."="..val);
		--end

		--search if there is a primary weapon
		for i,val in WeaponPack do
			if(val.Primary)then
				primary_weapon=val;
			end
		end

		end

	end

	--System:Log("PLAYER AMMO");
	--for i,val in self.Ammo do
		--	System:Log(i.."="..val);
	--end
		-- Initialize all loaded weapons, and tell the container which weapons
	-- are available
	local idx, CurWeapon;
	for idx, CurWeapon in WeaponsLoaded do
		--System:Log("BasicPlayer.ScriptInitWeapon(self,"..CurWeapon..")");
		BasicPlayer.ScriptInitWeapon(self, CurWeapon);
	end


	--System:Log("PLAYER AMMO---------");
	--for i,val in self.Ammo do
		--	System:Log(i.."="..val);
	--end
	
	if(primary_weapon)then
		self.cnt:SetCurrWeapon(Game:GetEntityClassIDByClassName(primary_weapon.Name));
	else
		-- Make sure we have a weapon active
		self.cnt:SelectFirstWeapon();
	end
	--select granade
	--the rock
	self.cnt.grenadetype=1;
	local id=2;--rick id is 1
	for i=id,count(GrenadesClasses) do
		if(self.Ammo and self.Ammo[GrenadesClasses[id]]>0)then
			self.cnt.grenadetype=id;
			self.cnt.numofgrenades=self.Ammo[GrenadesClasses[id]];
			self.GrenadeType=GrenadesClasses[id];
		end
	end

	self.bAllWeaponsInititalized = 1;
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:ScriptInitWeapon(WeaponDesc)
	-- Add the data structures for the passed weapon to this player and make an instance
	-- of the sounds. Give the weapon to the player if it is in his weapon pack

--	assert(self.bAllWeaponsInititalized==nil)
	-- Create a new map to map weapon entity class IDs to weapon state information
	if (self.WeaponState == nil) then
		self.WeaponState = new(Map);
	end

	-- Initializing weapon state info
	local WeaponStateTemplate  = {
		--C_FireTime,	     -- Last time we fired.
		FireAnim,	     -- Is weapon fire animation weapon is playing now.
		AnimFrame,	     -- Current animation frame for weapon.
		FireMode,	     -- Firemode
		LastCamState,        -- Control weapon visibility while changing from 1st to 3rd person mode
		AmmoInClip,          -- Amount of ammunition in the current clip
		MSLeftToFire,
	};

	local WeaponTable;
	local CurWeapon = nil;
	local CurWeaponClsID = nil;

	-- Find ClassID
	for _iUnused, CurTable in { WeaponClasses, MountedWeapons } do
		for i, _CurWeapon in CurTable do
			if (_CurWeapon[1] == WeaponDesc) then
				CurWeapon = _CurWeapon;
				CurWeaponClsID = _CurWeapon[2];
			end
		end
	end

	if (CurWeapon == nil) then
		System:Log("ERROR: Can't find weapon '"..WeaponDesc.."' in weapon tables !");
	end

	-- Weapon name and table
	local wName = CurWeapon[1];
	local weapontbl = getglobal(wName);

	-- Create the state table for this weapon
	local NewTable = new(WeaponStateTemplate);
	--NewTable.C_FireTime = 0;
	--NewTable.S_FireTime = 0;
	NewTable.FireAnim = 0;
	NewTable.AnimFrame = 0;
	NewTable.FireMode = 1;
	NewTable.LastCamState = -1;
	NewTable.AmmoInClip = {0};
	NewTable.SndInstances = {};

	--System:Log("AMMO!!"..WeaponDesc);
	--for i,val in self.Ammo do
		--	System:Log(i.."="..val);
	--end
	-- Load sounds
	for i2, CurFireParameters in weapontbl.FireParams do


		NewTable.AmmoInClip[i2] = 0;--CurFireParameters.bullets_per_clip;
		-- TODO: Don't give player a full clip by default, pull the first clip from the pool
		--if (self.Ammo[CurFireParameters.AmmoType] ~= nil and self.Ammo[CurFireParameters.AmmoType] > 0) then
		--	NewTable.AmmoInClip[i2] = min(self.Ammo[CurFireParameters.AmmoType], CurFireParameters.bullets_per_clip);
		--	self.Ammo[CurFireParameters.AmmoType] = self.Ammo[CurFireParameters.AmmoType] - min(self.Ammo[CurFireParameters.AmmoType], CurFireParameters.bullets_per_clip);
		--end
		if(i2==1 and self.Ammo[CurFireParameters.AmmoType] and self.Ammo[CurFireParameters.AmmoType]>0)then
			local amount;
			local bpc=CurFireParameters.bullets_per_clip;
			--System:Log("---Ammo "..CurFireParameters.AmmoType);
			--System:Log("---Ammo Before"..self.Ammo[CurFireParameters.AmmoType]);
			amount=min(bpc,self.Ammo[CurFireParameters.AmmoType]);
			self.Ammo[CurFireParameters.AmmoType]=self.Ammo[CurFireParameters.AmmoType]-amount;
			
			
			NewTable.AmmoInClip[i2]=amount;
			
			--System:Log("---In clip "..NewTable.AmmoInClip[i2]);
			--System:Log("---Left "..self.Ammo[CurFireParameters.AmmoType]);
		end
		local flags = bor(SOUND_RELATIVE, SOUND_UNSCALABLE);

		-- Marco's NOTE: I'm adding here sound priority for weapon sounds. The last parameter
		-- in load3dsound is the sound priority, the range is from 0 to 255, with 255
		-- being maximum priority
		NewTable.SndInstances[i2] = { };
		if (type(CurFireParameters.DrySound) == "string") then
			NewTable.SndInstances[i2]["DrySound"] = Sound:Load3DSound(CurFireParameters.DrySound, flags,
			CurFireParameters.SoundMinMaxVol[1],
			CurFireParameters.SoundMinMaxVol[2], CurFireParameters.SoundMinMaxVol[3],128);
		end
		if (type(CurFireParameters.FireLoop) == "string") then
			NewTable.SndInstances[i2]["FireLoop"] = Sound:Load3DSound(CurFireParameters.FireLoop, flags,
			CurFireParameters.SoundMinMaxVol[1],
			CurFireParameters.SoundMinMaxVol[2], CurFireParameters.SoundMinMaxVol[3],255);
		end
		if (type(CurFireParameters.TrailOff) == "string") then
			NewTable.SndInstances[i2]["TrailOff"] = Sound:Load3DSound(CurFireParameters.TrailOff,flags,
			CurFireParameters.SoundMinMaxVol[1],
			CurFireParameters.SoundMinMaxVol[2], CurFireParameters.SoundMinMaxVol[3],128);
		end
		if (CurFireParameters.FireSounds) then
			NewTable.SndInstances[i2]["FireSounds"] = { };
			for iSingleSnd, CurSndFile in CurFireParameters.FireSounds do
				if (type(CurSndFile) == "string") then
					local CurrSound = Sound:Load3DSound(CurSndFile, flags,
       											CurFireParameters.SoundMinMaxVol[1],
														CurFireParameters.SoundMinMaxVol[2], CurFireParameters.SoundMinMaxVol[3],255);
					if (CurrSound) then
						Sound:SetSoundPitching(CurrSound, 100);
					end
					NewTable.SndInstances[i2]["FireSounds"][iSingleSnd] = CurrSound;
				end
			end
		end
	end

	-- Add to the weapon state of this player
	self.WeaponState[CurWeaponClsID]=NewTable;

	-- Make the weapons available which belong to the player's weapon pack
	local WeaponPackName = self.Properties.equipEquipment;

	if (WeaponPackName) then
		local PlayerPack = EquipPacks[WeaponPackName];
		if (PlayerPack ~= nil) then
			for iIdx, CurPackWeapon in PlayerPack do
				if (CurPackWeapon.Type == "Weapon" and CurPackWeapon.Name == wName) then
					self.cnt:MakeWeaponAvailable(CurWeaponClsID, 1);
					--System:LogToConsole(" --> Name: "..wName);
				end
			end
		end
	end
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:HelmetOn()
	self:AttachObjectToBone( 0, "hat_bone" );
--self.DrawObject(0,1);
	self.hasHelmet = 1;
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:HelmetOff()
	self:DetachObjectToBone( "hat_bone" );
--	self.DrawObject(0,0);
	self.hasHelmet = 0;

end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:HelmetHitProceed( direction, impuls )

	if( random(0,3)>1 ) then
		do return end
	end

local helmet = Server.SpawnEntity("Helmet");
--	self.theHelmet = Server.SpawnEntity("Helmet");

	local pos = self:GetBonePos("hat_bone");
--	self.theHelmet.
	helmet:EnablePhysics( 1 );
	helmet:SetPos( pos );

	direction.z = direction.z + 5;

	helmet:AddImpulseObj(direction, impuls);
--	theHelmet.Activate(theHelmet, direction, impuls);
	helmet:DrawObject(0,1);

	BasicPlayer.HelmetOff( self );
end

function BasicPlayer:AddAmmo(AmmoType, Amount)

	if(self.Ammo[AmmoType] == nil) then
		System:Log("Unknown ammo type so far, add to WeaponSystem.lua-->AmmoAvailable");
		return
	end

	local wi = self.weapon_info;
	if(self.cnt.weapon and self.cnt.weapon.FireParams[wi.FireMode].AmmoType==AmmoType)then
		self.cnt.ammo=self.cnt.ammo + Amount;
		self.Ammo[AmmoType] = self.cnt.ammo;
	elseif(GrenadesClasses[self.cnt.grenadetype]==AmmoType)then
		self.cnt.numofgrenades=self.cnt.numofgrenades + Amount;
		self.Ammo[AmmoType] = self.cnt.numofgrenades;
	else
		self.Ammo[AmmoType] = self.Ammo[AmmoType] + Amount;
	end
	--automatically switches grenade type
	for i,val in GrenadesClasses do
		if(AmmoType==val)then
			BasicPlayer.SelectGrenade(self,AmmoType);
		end
	end
	--debug check
	if(self.Ammo[AmmoType]>MaxAmmo[AmmoType])then
		System:Log("Ammo : "..self.Ammo[AmmoType].." (Type: "..AmmoType..")");
		assert(self.Ammo[AmmoType]<=MaxAmmo[AmmoType]);
	end
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Client_OnUpdate( DeltaTime )

--	--System.MeasureTime("CliSTART");
--
--	-- Cache some frequently accessed tables
--	local stats = self.cnt;
--	local my_player = _localplayer;
--
--
----	if( stats.light==1 ) then
----		local lPos = self:GetPos();
----		local lDir = self:GetAngles();
----		lPos.z = lPos.z + 1.9;
----		self:AddDynamicLight(lPos, 10, self.lColor[1], self.lColor[2],
----													self.lColor[3], 1, 1, 1, 0.3, 1, 0, self.lightFlag, lDir, 12 );
----	end
--
--
--	if (self == my_player) then
--
--		------------------------------------------
--		-- Main player specific update code
--		------------------------------------------
--
--		self.vLastPos = self:GetPos();
--
----		-- restrict angles
----		if ( stats.proning ) then
----			if (self.isProning==0) then
----				self.isProning=1;
----				--stats:SetAngleLimitBaseOnEnviroment();
----				stats:SetMinAngleLimitV( self.proneMinAngle );
----				stats:SetMaxAngleLimitV( self.proneMaxAngle );
----				Input:SetMouseSensitivityScale( 0.1 );
----			end
----		else
----			if (self.isProning==1) then
----				self.isProning=0;
----				--stats:SetAngleLimitBaseOnVertical();
----				stats:SetMinAngleLimitV( self.normMinAngle );
----				stats:SetMaxAngleLimitV( self.normMaxAngle );
----				Input:SetMouseSensitivityScale( 1.0 );
----			end
----		end
--
--
--	else
--		------------------------------------------
--		-- Non main player specific update code
--		------------------------------------------
--	end
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Client_DeadOnUpdate( DeltaTime )

	local stats = self.cnt;

--printf( "deafUpdate" );

	if (stats:HasCollided() == nil) then
		do return end
	end

	if (self.downSound == 0) then

		-- Would be nice to have a shorter and more elegant way to do that
		local CurWeaponInfo = self.weapon_info;
		if (CurWeaponInfo) then
			local CurFireMode = CurWeaponInfo.FireMode;
			local CurWeapon = self.cnt.weapon;
			if (CurWeapon) then
				local CurFireParams = CurWeapon.FireParams[CurFireMode];
				local SoundData = CurWeaponInfo.SndInstances[CurFireMode];
				if (SoundData) then
					System:LogToConsole("--> Death Fire Loop Stop Stuff Called !!!");
					BasicWeapon.StopFireLoop(CurWeapon, self, CurFireParams, SoundData);
				end
			end
		end

		self:SetShader( "" );
		self.downSound = 1;
		local normal={x=0,y=0,z=1};
		local material=self.cnt:GetTreadedOnMaterial();

--printf( "deafUpdate HAS COLLIDED" );

		if(material ~= nil) then
			ExecuteMaterial(self:GetPos(),normal,material.player_drop,1);
		end
	end
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Server_OnUpdate( DeltaTime )
	--System.MeasureTime("SrvSTART");


	-- Precache some frequently used tables
--	local stats = self.cnt;
--
--	-- If not in vehicle and not at mounted weapon
--	-- restrict angles
--
--
--	if ( stats.proning ) then
--		if (self.isProning == 0) then
--			self.isProning=1;
--			stats:SetMinAngleLimitV( self.proneMinAngle );
--			stats:SetMaxAngleLimitV( self.proneMaxAngle );
--		end
--	else
--		if (self.isProning == 1) then
--			self.isProning=0;
--			stats:SetMinAngleLimitV( self.normMinAngle );
--			stats:SetMaxAngleLimitV( self.normMaxAngle );
--		end
--	end

--	-- Recover energy
--	if (self.EnergyChanged == nil) then
--		self.ChangeEnergy( self, DeltaTime * 1 );
--	else
--		self.EnergyChanged = nil;
--	end

	--System.MeasureTime("SrvEND");
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Server_OnEvent( EventId, Params )
	local handler=BasicPlayer.Server_EventHandler[EventId];
	if(handler)then
		return handler(self,Params)
	end
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Client_OnEvent( EventId, Params)
	local handler=BasicPlayer.Client_EventHandler[EventId];
	if(handler)then
		return handler(self,Params)
	end
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:PlayOneSound( soundList, chance )

	local randnum=random(1,100);
	if( randnum<chance ) then

		local nsounds=getn(soundList);
		local sound=soundList[random(1,nsounds)]

		Sound:SetSoundPosition(sound,self:GetPos());

		Sound:PlaySound(sound);

		self.painSound = sound;
	end


end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:SetDeathImpulse( hit )
  self.deathImpuls.x = hit.dir.x;
  self.deathImpuls.y = hit.dir.y;
  self.deathImpuls.z = hit.dir.z;

--printf(">>>>> %.2f",hit.impact_force_mul_final);
	if(hit.impact_force_mul_final)then
		self.deathImpuls.x = self.deathImpuls.x*hit.impact_force_mul_final;
		self.deathImpuls.y = self.deathImpuls.y*hit.impact_force_mul_final;
		self.deathImpuls.z = self.deathImpuls.z*hit.impact_force_mul_final;
		if (hit.target_material	and ((hit.target_material.type=="head") or (hit.target_material.type=="leg"))) then
		  self.deathImpulseTorso = 0;
		else
  		  if( not hit.impact_force_mul_final_torso ) then
  		  	hit.impact_force_mul_final_torso  = 0;
  		  end	
		  self.deathImpulseTorso = hit.impact_force_mul_final_torso;
		  if (hit.impact_force_mul_final_torso>0) then
		    self.deathImpuls.x = self.deathImpuls.x*2.0;
		    self.deathImpuls.y = self.deathImpuls.y*2.0;
		    self.deathImpuls.z = self.deathImpuls.z*2.0;
		  end  
		end
	end

	if( hit.pos )  then				-- hit was in some point
		self.deathPoint.x = hit.pos.x;
		self.deathPoint.y = hit.pos.y;
		self.deathPoint.z = hit.pos.z;
		self.deathImpulsePart = hit.ipart;
	else											-- just damage (fall)
		self.deathPoint.x = 0;
		self.deathPoint.y = 0;
		self.deathPoint.z = 0;
		self.deathImpulsePart = 0;
	end

end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Server_OnDamage( hit )

	BasicPlayer.SetDeathImpulse( self, hit );

	GameRules:OnDamage(hit);

	if(self.cnt.health ~= 0 and (not hit.explosion)) then
		if( hit.ipart ) then
			self:AddImpulse( hit.ipart, hit.pos, hit.dir, hit.impact_force_mul );
			--System:Log("self:AddImpulse( hit.ipart, hit.pos, hit.dir,"..hit.impact_force_mul..")")
		else
			--System:Log("self:AddImpulse( -1, hit.pos, hit.dir,"..hit.impact_force_mul..")")
			self:AddImpulse( -1, hit.pos, hit.dir, hit.impact_force_mul );
		end
	end

end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Server_OnDamageDead( hit )
--printf("server on Damage DEAD %.2f %.2f",hit.impact_force_mul_final,hit.impact_force_mul);
	if( hit.ipart and (not hit.explosion)) then
		self:AddImpulse( hit.ipart, hit.pos, hit.dir, hit.impact_force_mul );
	else
		self:AddImpulse( -1, hit.pos, hit.dir, hit.impact_force_mul );
	end
end


-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Client_OnDamage( hit )

--System:LogToConsole("client damage "..hit.damage);
--System.LogToConsole("client damage "..hit.weapon_death_anim_id);
--System.LogToConsole("deathImp "..hit.dir.x.." "..hit.dir.y.." "..hit.dir.z  );

--if (type(hit) == "table") then
--System:LogToConsole( "It was tableHit!" );
--else
--System:LogToConsole( "It was valueHit!  "..hit );
--do return end
--end

	BasicPlayer.SetDeathImpulse( self, hit );

	--target_material

	if(self.painSound~=nil or Sound:IsPlaying(self.painSound)==nil ) then
		BasicPlayer.PlayOneSound( self, self.painSounds, 70 );
	end

--no pain animations now - use physics
--	BasicPlayer.PlayPainAnimation( self, hit );

--	self:AddImpulse( hit.ipart, hit.pos, hit.dir, 500 );
--	self.AddImpulse( hit.ipart, hit.pos, hit.dir, hit.damage*5 );

	if ( self == _localplayer ) then	-- shake it, baby !
		local ShakeAxis = self.cnt:CalcDmgShakeAxis( hit.dir );
		if ( ShakeAxis ) then
			if ( ShakeAxis.y < -0.5 ) then Hud.dmgindicator = bor( Hud.dmgindicator, 1 ); end
			if ( ShakeAxis.y > 0.5 ) then Hud.dmgindicator = bor( Hud.dmgindicator, 2 ); end
			if ( ShakeAxis.x < -0.5 ) then Hud.dmgindicator = bor( Hud.dmgindicator, 4 ); end
			if ( ShakeAxis.x > 0.5 ) then Hud.dmgindicator = bor( Hud.dmgindicator, 8 ); end
			-- camera shake sux a bit, lets try without any - Tig
			local ShakeAmount = hit.damage * .1;		--was 0.5
			if ( ShakeAmount > 45 ) then ShakeAmount = 45; end
			if(random(1,100)<50) then
				ShakeAmount = -ShakeAmount;
			end	
			self.cnt:ShakeCamera( ShakeAxis, ShakeAmount, 3, .33);
		end
		
		-- draw some blood on the screen if it was a melee attack
		-- from a mutant or whatever
		if (hit.melee) then
		
			Hud:OnMeleeDamage();
			--System:Log("DRAW MELEE BLOOD 222");
		end

	end

	
	

end


-----------------------------------------------------------------------------------------------------------
function BasicPlayer:DoStepSound()


--	if( self.cnt.doStepSound == 1 ) then
		local pos=self:GetPos();
		local normal={x=0,y=0,z=1};
		self.LastMaterial=self.cnt:GetTreadedOnMaterial();

 		if(self.LastMaterial ~= nil) then
-- 			if ((_time-self.LastFootStepTime)<0.25) then
 --				System:Log("Skipping Footstep");
 	--			return
 	--		end
 	--		self.LastFootStepTime=_time;
 			--if(self~=_localplayer)then
-- 				System:LogToConsole("AI footstep");
 			--else
-- 				System:LogToConsole("Player footstep");
 			--end
 			if(self.InWater==0) then
 				local SoundScale=1;
				if( self.cnt.running ) then
--					AI.SoundEvent(self.id,pos,BasicPlayer.soundRadius.run,0,1,self.id);
					SoundScale=BasicPlayer.soundScale.run;
				elseif( self.cnt.crouching ) then
--					AI.SoundEvent(self.id,pos,BasicPlayer.soundRadius.crouch,0,1,self.id);
					SoundScale=BasicPlayer.soundScale.crouch;
				elseif( self.cnt.proning ) then
--					AI.SoundEvent(self.id,pos,BasicPlayer.soundRadius.prone,0,1,self.id);
					SoundScale=BasicPlayer.soundScale.prone;
				else
--					AI.SoundEvent(self.id,pos,BasicPlayer.soundRadius.walk,0,1,self.id);
					SoundScale=BasicPlayer.soundScale.walk;
				end
				ExecuteMaterial(pos, normal, self.LastMaterial.player_walk, SoundScale, nil, nil, self.cnt);
				--System:LogToConsole("FOOTSTEP");
				-- lets play random equipment sounds if available
				if (self.EquipmentSoundProbability and self.EquipmentSounds) then
					local EquipmentSounds=getn(self.EquipmentSounds);
					if ((EquipmentSounds>0) and (random(1,100)<=self.EquipmentSoundProbability)) then
						local EquipmentSound=self.EquipmentSounds[random(1, EquipmentSounds)];
						--Sound:SetSoundPosition(EquipmentSound, pos);
						self.cnt:PlaySound(EquipmentSound, SoundScale);
					end
				end
			else
				if ((self.Diving and self.Diving==0) or (self.Diving==nil)) then
					ExecuteMaterial(pos,normal,self.LastMaterial.player_walk_inwater,1, nil, nil, self.cnt);
				end
				--System:LogToConsole("WATER FOOTSTEP");
			end
		else
			--System:LogToConsole("BasicPlayer:DoStepSound() nil material");
			if(self.cnt.flying~=nil)then
				--System:LogToConsole("BasicPlayer:DoStepSound() nil material");
			end
		end

end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:DoBushSound()

	do return end	-- [lennert] this will execute footsteps twice in indoors !
--		local pos=self:GetPos();
--		local normal={x=0,y=0,z=1};
--		local materialSoft=self.cnt:GetTouchedMaterial();

-- the following expression comment out all code between [[ and ]]
	bush_thing=[[
	if(materialSoft ~= nil) then
			self.BushInCounter = self.BushInCounter + 1;
 			if(self.InWater==0) then
				local soundScale = self.BushInCounter/self.BushSoundScale;
				if(soundScale > 1) then
					soundScale = 1;
				end

--System:LogToConsole( " bush soundScale "..soundScale );

				if( self.cnt.running ) then
					ExecuteMaterial(pos,normal,materialSoft.player_walk,BasicPlayer.soundScale.run*soundScale);
				elseif( self.cnt.crouching ) then
					ExecuteMaterial(pos,normal,materialSoft.player_walk,BasicPlayer.soundScale.crouch*soundScale);
				elseif( self.cnt.proning ) then
					ExecuteMaterial(pos,normal,materialSoft.player_walk,BasicPlayer.soundScale.prone*soundScale);
				else
					ExecuteMaterial(pos,normal,materialSoft.player_walk,BasicPlayer.soundScale.walk*soundScale);
				end
			end
		else
			self.BushInCounter = 0;
		end
		]]

		local pos=self:GetPos();
		local normal={x=0,y=0,z=1};
		local materialSoft=self.cnt:GetTouchedMaterial();

		if(materialSoft ~= nil) then
 			if(self.InWater==0) then
				--System:Log("touching material");
				if( self.cnt.running ) then
					ExecuteMaterial(pos,normal,materialSoft.player_walk,BasicPlayer.soundScale.run);
				elseif( self.cnt.crouching ) then
					ExecuteMaterial(pos,normal,materialSoft.player_walk,BasicPlayer.soundScale.crouch);
				elseif( self.cnt.proning ) then
					ExecuteMaterial(pos,normal,materialSoft.player_walk,BasicPlayer.soundScale.prone);
				else
					ExecuteMaterial(pos,normal,materialSoft.player_walk,BasicPlayer.soundScale.walk);
				end
			end


		end
--		self.bushSndTime = 0.7;
end


-----------------------------------------------------------------------------------------------------------
function BasicPlayer:DoStepSoundAI()

	-- no footstep sound when in stealth mode

		local material=self.cnt:GetTreadedOnMaterial();

 		if(material ~= nil) then
				self.BushInCounterAI = self.BushInCounterAI + 1;
				local soundScale = self.BushInCounterAI/self.BushSoundScaleAI;
				if(soundScale > 1) then
					soundScale = 1;
				end

				local pos=self:GetPos();
-- 			if(self.InWater==0) then
				if( self.cnt.running ) then
					AI:SoundEvent(self.id,pos,BasicPlayer.soundRadius.run*soundScale,0,1,self.id);
				elseif( self.cnt.crouching ) then
					AI:SoundEvent(self.id,pos,BasicPlayer.soundRadius.crouch*soundScale,0,1,self.id);
				elseif( self.cnt.proning ) then
					AI:SoundEvent(self.id,pos,BasicPlayer.soundRadius.prone*soundScale,0,1,self.id);
				else
					AI:SoundEvent(self.id,pos,BasicPlayer.soundRadius.walk*soundScale,0,1,self.id);
				end
		else
			self.BushInCounterAI = 0;
		end
end
-----------------------------------------------------------------------------------------------------------
function BasicPlayer:DoBushSoundAI()

	local stats = self.cnt;

	-- no footstep sound when in stealth mode
	local materialSoft=stats:GetTouchedMaterial();

	if(materialSoft ~= nil) then
		local pos=self:GetPos();

			if( stats.running ) then
				AI:SoundEvent(self.id,pos,BasicPlayer.soundRadius.run,0,1,self.id);
			elseif( stats.crouching ) then
				AI:SoundEvent(self.id,pos,BasicPlayer.soundRadius.crouch,0,1,self.id);
			elseif( stats.proning ) then
				AI:SoundEvent(self.id,pos,BasicPlayer.soundRadius.prone,0,1,self.id);
			else
				AI:SoundEvent(self.id,pos,BasicPlayer.soundRadius.walk,0,1,self.id);
			end
	end
--	self.bushSndTimeAI = 0.7;
end



-----------------------------------------------------------------------------------------------------------
function BasicPlayer:DoLandSound()

--	if( self.cnt.doLandSound == 1 ) then
		local pos=self:GetPos();
		local normal={x=0,y=0,z=1};
		local material=self.cnt:GetTreadedOnMaterial();
		if(material ~= nil) then
			ExecuteMaterial(pos,normal,material.player_walk,1);
		end
--	end
--	self.cnt.doLandSound = 0;
end


-----------------------------------------------------------------------------------------------------------
function BasicPlayer:UpdateInWaterSplash()
	if (self ~= _localplayer) then
		return
	end

	if (Game:IsPointInWater(self:GetPos()) ~= nil) then	-- player feet under water
		Sound:SetGroupScale(SOUNDSCALE_UNDERWATER, 1);
		local vCamPos = self:GetCameraPosition();		
		local bIsCameraUnderwater = Game:IsPointInWater(vCamPos);
		
		self.InWater = 1;

		-- If player is partialy in water, play swim/splash sounds do particles
		if (bIsCameraUnderwater==nil) then	-- partially under water

			--r_WaterRefractions=0;

			-- stop underwater sound
			if ((self.sndUnderwaterNoise~=nil) and (Sound:IsPlaying(self.sndUnderwaterNoise)==1)) then
				Sound:StopSound(self.sndUnderwaterNoise);
			end
			if (self.Diving and self.Diving~=0) then
				Sound:PlaySound(self.sndBreathIn[random(1, getn(BasicPlayer.sndBreathIn))]);
			end
			self.Diving=0;
			if (not self.cnt.moving) then
				return
			end
			if (self.LastMaterial==nil) then
				if ((self.SwimSound==nil) or (Sound:IsPlaying(self.SwimSound)~=1)) then
	--				local iSoundIdx = random(1, getn(BasicPlayer.sndWaterSwim));
	--				self.SwimSound = BasicPlayer.sndWaterSwim[iSoundIdx];
					self.SwimSound = BasicPlayer.sndWaterSwim;
					if (self.SwimSound) then
						Sound:SetSoundLoop(self.SwimSound, 1);
						Sound:PlaySound(self.SwimSound);
					end
				end
			else
				if ((self.SwimSound~=nil) and (Sound:IsPlaying(self.SwimSound)==1)) then
					Sound:StopSound(self.SwimSound);
					self.SwimSound=nil;
				end
			end
			-- Spawn ripples if player enters water
			if (iLastWaterSurfaceParticleSpawnedTime == nil) then
				self.iLastWaterSurfaceParticleSpawnedTime = _time;
			end
			if (_time - self.iLastWaterSurfaceParticleSpawnedTime > 0.2) then
				local vVec = self:GetPos();
				vVec.z = Game:GetWaterHeight() + 0.02;	
				vVec.x = vVec.x + 0.25 - random(1, 100) / 200;
				vVec.y = vVec.y + 0.25 - random(1, 100) / 200;	
				Particle:CreateParticle( vVec, {x=0, y=0, z=0}, BasicPlayer.WaterRipples );
				self.iLastWaterSurfaceParticleSpawnedTime = _time;
			end
		else		-- fully under water
			Sound:SetGroupScale(SOUNDSCALE_UNDERWATER, 0);
			self.Diving=1;

			--r_WaterRefractions=1;

			-- If player is under water, play random under-water noises and stop
			-- the swim/splash sounds
			if ((self.SwimSound~=nil) and (Sound:IsPlaying(self.SwimSound)==1)) then
				Sound:StopSound(self.SwimSound);
				self.SwimSound=nil;
			end
			if ((self.sndUnderwaterNoise==nil) or (Sound:IsPlaying(self.sndUnderwaterNoise)~=1)) then
				Sound:SetSoundLoop(self.sndUnderwaterNoise, 1);
				Sound:PlaySound(self.sndUnderwaterNoise);
			end
		end
	else	-- not in water at all
		Sound:SetGroupScale(SOUNDSCALE_UNDERWATER, 1);
		self.InWater = 0;
		self.Diving=0;
		if ((self.SwimSound~=nil) and (Sound:IsPlaying(self.SwimSound)==1)) then
			Sound:StopSound(self.SwimSound);
			self.SwimSound=nil;
		end
		if ((self.sndUnderwaterNoise~=nil) and (Sound:IsPlaying(self.sndUnderwaterNoise)==1)) then
			Sound:StopSound(self.sndUnderwaterNoise);
		end
	end
end


-----------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------
--
-----------------------------------------------------------------------------------------------------------
function BasicPlayer:Reload()

	local stats = self.cnt;
	local CurWeaponInfo = self.weapon_info;
	local CurWeapon = stats.weapon;
	if(stats.reloading)then return end	-- fix 13: not again while a reload is running (the clip is 0 then)
	if(stats.weapon and self.fireparams and self.fireparams.bullets_per_clip and stats.ammo_in_clip < self.fireparams.bullets_per_clip and (stats.ammo > 0 or self.fireparams.AmmoType == "Unlimited"))then	-- fix 13: no reload with a full clip or no reserve ammo
		BasicWeapon.Server_Reload( CurWeapon, self );
		BasicWeapon.Client_Reload( CurWeapon, self );
		stats.weapon_busy=CurWeapon.FireParams[CurWeaponInfo.FireMode].reload_time;
		self:StartAnimation(0,"reload",4);
	end

end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:OnLoad(stm)

	self.Energy=stm:ReadInt();
	self.MaxEnergy=stm:ReadInt();
	self.Refractive=stm:ReadBool();
	self.Ammo=ReadFromStream(stm);
	local count=stm:ReadInt();
	while(count>0) do
		local idx=stm:ReadInt();
		System:Log("LOADING "..idx);
		local t=ReadFromStream(stm);
		local fm=stm:ReadInt();
		if(self.WeaponState[idx])then
			self.WeaponState[idx].AmmoInClip=t;
			self.WeaponState[idx].FireMode=fm;
		else
			System:Log("WARNING WEAPON STATE NOT FOUND ");
		end
		count=count-1
	end
	if(GrenadesClasses[self.cnt.grenadetype])then
		self.GrenadeType=GrenadesClasses[self.cnt.grenadetype];
	end
end

-----------------------------------------------------------------------------------------------------------
function BasicPlayer:OnSave(stm)

	stm:WriteInt(self.Energy);
	stm:WriteInt(self.MaxEnergy);
	stm:WriteBool(self.Refractive);
	WriteToStream(stm,self.Ammo);
	local nentries=0;
	for i,val in self.WeaponState do
		if(type(i)=="number"
		and type(val.AmmoInClip)=="table")then nentries=nentries+1; end
	end
	stm:WriteInt(nentries);
	for i,val in self.WeaponState do
		-- [wrapper v47 fix] same condition as the count above, otherwise a weapon
		-- without an AmmoInClip table is written but not counted and the
		-- checkpoint can't be loaded ("CSTREAM:Read (string too long...over 256)")
		if(type(i)=="number"
		and type(val.AmmoInClip)=="table")then
			--System:Log("SAVING "..i);
			stm:WriteInt(i);
			WriteToStream(stm,val.AmmoInClip);
			stm:WriteInt(val.FireMode);
		end
	end
end


--------------------------------------------------------------------------------------------------------
function BasicPlayer:ProcessCommand( Params )
	local Sender = System:GetEntity( Params.Sender );
	-- SAY
	if ( Params.CommandID == CMD_GO ) then
		Game:ShowIngameDialog(-1, "", "", 12,	"A new command has been received: $4Go to the location marked on your map !", 10);
		Game:SetNavPoint("Go", Params.Target);
	elseif ( Params.CommandID == CMD_ATTACK ) then
		Game:ShowIngameDialog(-1, "", "", 12,	"A new command has been received: $4Attack the location marked on your map !", 10);
		Game:SetNavPoint("Attack", Params.Target);
	elseif ( Params.CommandID == CMD_DEFEND ) then
		Game:ShowIngameDialog(-1, "", "", 12,	"A new command has been received: $4Defend the location marked on your map !", 10);
		Game:SetNavPoint("Defend", Params.Target);
	elseif ( Params.CommandID == CMD_COVER ) then
		Game:ShowIngameDialog(-1, "", "", 12,	"A new command has been received: $4Cover the location marked on your map !", 10);
		Game:SetNavPoint("Cover", Params.Target);
	elseif ( Params.CommandID == CMD_BARRAGEFIRE ) then
		Game:ShowIngameDialog(-1, "", "", 12,	"A new command has been received: $4Barrage Fire at the location marked on your map !", 10);
		Game:SetNavPoint("Barrage Fire", Params.Target);
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicPlayer:Server_OnFireGrenade(Params)
	if (Params.underwater) then return end
	self.GrenadeThrowParam = new(Params);

	if((self.cnt.grenadetype == 1) or (self.cnt.numofgrenades>0))then
		self.cnt.numofgrenades=self.cnt.numofgrenades-1;
		self.cnt.weapon_busy=1.5;
	else
		System:Log("WARNING self.cnt.numofgrenades<0 this shouldn't happen");
	end
	Game:SetTimer(self, self.GrenadeThrowFrame * (1000/30));

end

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicPlayer:Client_OnFireGrenade(Params)
	if ((not ( (self.cnt.numofgrenades>0) or (self.cnt.grenadetype==1) ) ) ) then
		do return end;
	end

	if (_localplayer == self) then
		self.cnt.weapon:StartAnimation(0, "Grenade1"..self.weapon_info.FireMode,0,0);
	end

	self.cnt.weapon_busy=1.5;
end

-------------------------------------------------------------------------
--
function BasicPlayer:Server_OnTimer()

local stats = self.cnt;

	if(stats.underwater>self.drown_time)then
		stats.health=stats.health-5;
		--stats.underwater=stats.underwater-1;
			local	hit = {
				dir = {x=0, y=0, z=1},
				damage = 2,
				target = self,
				shooter = self,
				landed = 1,
				impact_force_mul_final=5,
				impact_force_mul=5,
			};
--			System:LogToConsole( "Palyer landed "..Params.." damage "..fallDmg);
--			self:OnDamage( hit );
			self:Damage( hit );
	end

	-- If not in vehicle and not at mounted weapon
	-- restrict angles
	if ( stats.proning ) then
		if (self.isProning == 0) then
			self.isProning=1;
			stats:SetMinAngleLimitV( self.proneMinAngle );
			stats:SetMaxAngleLimitV( self.proneMaxAngle );
		end
	else
		if (self.isProning == 1) then
			self.isProning=0;
			stats:SetMinAngleLimitV( self.normMinAngle );
			stats:SetMaxAngleLimitV( self.normMaxAngle );
		end
	end

	if (stats.health < 1 and self == _localplayer and Game:ShowSaveGameMenu()) then
		Game:ToggleMenu();
	else
		self:SetTimer(self.UpdateTime);
		if (stats.moving ) then
			BasicPlayer.DoBushSoundAI(self);
		end
	end
	
end


-------------------------------------------------------------------------
--
function BasicPlayer:OnEnterWater()

	-- player has just entered the water, check its velocity
	local vel =new(self:GetVelocity());
	--System:LogToConsole("vel="..vel.x..","..vel.y..","..vel.z);
	if ((vel.z < -1.1)) then
		Sound:SetSoundPosition(self.sndWaterSplash,self:GetPos());
		Sound:PlaySound(self.sndWaterSplash);
		--System:LogToConsole("splash");
	end		
end

-------------------------------------------------------------------------
--
function BasicPlayer:Client_OnTimer()

	if (self.ai) then 
		BasicAI.DoChatter(self);
	end


	if( self.Client_OnTimerCustom ) then
	 self:Client_OnTimerCustom();
	end


	local stats = self.cnt;

	-- check for local client only
	if (Hud and (self==_localplayer)) then
		-- spawn some bubbles when he drows			
		if (stats.underwater>0) then
			local Pos=self:GetPos();
			Pos.z=Pos.z+1.5;
			BasicWeapon.UnderwaterBubbles.count=16+random(1,64);		
			BasicWeapon.UnderwaterBubbles.fPosRandomOffset=1.5;
			Particle:CreateParticle(Pos, BasicWeapon.normal_001, BasicWeapon.UnderwaterBubbles);		
			BasicWeapon.UnderwaterBubbles.count=1;
			BasicWeapon.UnderwaterBubbles.fPosRandomOffset=0;
	
	
			-- When the player is underwater, a Breath Meter appears on the HUD.
			-- this meter displays the amount of air the player has before he will
			-- begin to take damage.
				
			if (stats.underwater>self.drown_time)then
				--System:Log("aaaauuughggghghghg auuughhghg");
				Hud.breathlevel=0;
			else						
				Hud.breathlevel=(self.drown_time-stats.underwater)/(self.drown_time+1); -- avoid divisions by 0				
			end

		else
			Hud.breathlevel=-1;
		end
	end
--	System:LogToConsole("--> Client Timer Event Received !");
	--System:LogToConsole("CLI OnTimer("..self.id..")");
	self:SetTimer(self.UpdateTime);

	BasicPlayer.UpdateInWaterSplash(self);
--	if (Game:IsPointInWater(self:GetPos()) ~= nil and self.cnt.moving) then
--		self.InWater = 1;
		--reenable the following line if you want water splash when the player walk/swim in water
--		BasicPlayer.UpdateInWaterSplash(self);
--	else
--		self.InWater = 0;
--	end

	self:ApplyForceToEnvironment(0.5, 0.73);
--	self.bushSndTime = self.bushSndTime - DeltaTime;

--	if (stats.moving and self.bushSndTime <= 0) then
	if (stats.moving) then
		BasicPlayer.DoBushSound(self);
		--System.MeasureTime("DoBushSound");
	end
	
	-- play heavy breathing sound when exhausted...
	-- COMMENTED DUE TO BAD SOUNDING, PLEASE DO NOT REMOVE YET !!!
--	if (stats.running and self.ExhaustedBreathingSound) then
--		if (not self.ExhaustedStartTime) then
--			self.ExhaustedStartTime=0;
--		end
--		self.ExhaustedStartTime=self.ExhaustedStartTime+self.UpdateTime/1000;
--		if (self.ExhaustedStartTime>self.ExhaustedBreathingStart) then
--			if (not Sound:IsPlaying(self.ExhaustedBreathingSound)) then
--				System:LogToConsole("Start Breathing");
--				Sound:SetSoundLoop(self.ExhaustedBreathingSound, 1);
--				Sound:PlaySound(self.ExhaustedBreathingSound);
--				self.ExhaustedStopTime=0;
--			end
--		end
--	else
--		self.ExhaustedStartTime=0;
--		if (self.ExhaustedStopTime) then
--			System:LogToConsole("self.ExhaustedStopTime");
--			self.ExhaustedStopTime=self.ExhaustedStopTime+self.UpdateTime/1000;
--			if (self.ExhaustedStopTime>self.ExhaustedBreathingStop) then
--				System:LogToConsole("Stop Breathing");
--				Sound:SetSoundLoop(self.ExhaustedBreathingSound, 0);
--				self.ExhaustedStopTime=nil;
--				--Sound:StopSound(self.ExhaustedBreathingSound);
--			end
--		end
--	end

	if (self == _localplayer) then
		------------------------------------------
		-- Main player specific update code
		------------------------------------------
		self.vLastPos = self:GetPos();
		-- restrict angles
		if ( stats.proning ) then
			if (self.isProning==0) then
				self.isProning=1;
				--stats:SetAngleLimitBaseOnEnviroment();
				stats:SetMinAngleLimitV( self.proneMinAngle );
				stats:SetMaxAngleLimitV( self.proneMaxAngle );
				Input:SetMouseSensitivityScale( 0.1 );
			end
		else
			if (self.isProning==1) then
				self.isProning=0;
				--stats:SetAngleLimitBaseOnVertical();
				stats:SetMinAngleLimitV( self.normMinAngle );
				stats:SetMaxAngleLimitV( self.normMaxAngle );
				Input:SetMouseSensitivityScale( 1.0 );
			end
		end

		-- set send an sneaking-mood-event if we're crouching or proning
		if ( self.cnt.crouching or self.cnt.proning ) then
			Sound:AddMusicMoodEvent("Sneaking", MM_SNEAKING_TIMEOUT);
		end

	end
end


function BasicPlayer:PhysicalizeOnDemand()
  if(self.cnt.health ~= 0) then
    self:SetCharacterPhysicParams(0,"", PHYSICPARAM_SIMULATION,self.BulletImpactParams);  
  end
end


BasicPlayer.Server_EventHandler={
	[ScriptEvent_FireModeChange]=function(self,Params)
		local CurWeapon = self.cnt.weapon;
		local bRetVal;
		Params.shooter=self;
		--Params.firemode;
		bRetVal = BasicWeapon.Server_OnEvent(CurWeapon, ScriptEvent_FireModeChange, Params);
		if (bRetVal) then
			-- Change the firemode
			local wi = self.weapon_info;
			wi.FireMode = Params.firemode;
		end

		return bRetVal;
	end,
	[ScriptEvent_AnimationKey]=function(self,Params)
		BasicPlayer.DoStepSoundAI(self);
	end,
	[ScriptEvent_Use]=function(self,Params)
		local entities=self:GetEntitiesInContact();
		local used;
		if(entities)then
			for id,ent in entities do
				if(ent.OnUse)then
					ent:OnUse(self);
					used=1;
				end
			end
		end
		return used
	end,
	[ScriptEvent_FireGrenade]=function(self,Params)

		--NOTE self.cnt.grenadetype=1 is the ROCK so unlimited ammo
		if(self.cnt.grenadetype==1 or (self.cnt.numofgrenades>0))then
			return BasicPlayer.Server_OnFireGrenade(self, Params);
		else
			return
		end
	end,
	[ScriptEvent_Timer]=function(self,Params)
		-- Lets just assume we are supposed to throw a grenade
		local Grenade = Server:SpawnEntity(self.GrenadeType);
		if(self.GrenadeThrowParam.lifetime)then
			System:Log("lifetime is "..self.GrenadeThrowParam.lifetime)
		else
			System:Log("lifetime IS NIL")
		end

		--projectiles (grenades, for ex) should inherit player's velocity
		--it's calculated in C code, here we should get the correct velocity already
		Grenade:Launch(self.cnt.weapon, self, self.GrenadeThrowParam.pos, self.GrenadeThrowParam.angles, self.GrenadeThrowParam.dir,self.GrenadeThrowParam.lifetime);		
		--Grenade:Launch(self.cnt.weapon, self, self:GetPos(), self.GrenadeThrowParam.angles, self.GrenadeThrowParam.dir,self.GrenadeThrowParam.lifetime);
		
	end,
	[ScriptEvent_Land] = function(self,Params)
		if(self.NoFallDamage) then return end
		local	fallDmg = Params/100;
		if(fallDmg>self.FallDmgS) then
			fallDmg = (fallDmg - self.FallDmgS)*self.FallDmgK;
			local	hit = {
			dir = {x=0, y=0, z=1},
			damage = fallDmg,
			target = self,
			shooter = self,
			landed = 1,
			impact_force_mul_final=5,
			impact_force_mul=5,
			};
			self:Damage( hit );
		end
	end,
	[ScriptEvent_PhysCollision] = function(self,Params)
		local	cldDmg = Params.damage*self.CollisionDmg;
		local	hit = {
			dir = new(Params.dir),
			ipart = -1,
			damage = cldDmg,
			target = self,
			shooter = self,
			landed = 1,
			impact_force_mul_final=5,
			impact_force_mul=5,
			impact_force_mul_final_torso=0,
			target_material={type="arm"},
			};
		if ((not Params.collider) or (not Params.collider.Properties.damage_players) or (Params.collider.Properties.damage_players==0)) then
		  return
		end
		if (Params.collider_mass >	self.PhysParams.mass) then
		  if ((Params.collider) and (Params.collider.Properties) and (Params.collider.Properties.hit_upward_vel)) then
		    hit.dir.x=0; hit.dir.y=0; hit.dir.z=1;
		    hit.impact_force_mul_final_torso = Params.collider.Properties.hit_upward_vel*self.PhysParams.mass;
		  else
		    hit.impact_force_mul_final_torso = Params.collider_velocity*self.PhysParams.mass*1.3;
		  end  
		end
		self:Damage( hit );
	end,
	[ScriptEvent_CycleGrenade] = function(self,Params)
		--System:Log("CYCLING "..self.cnt.grenadetype);
		local curr=self.cnt.grenadetype;
		local gtypecount=count(GrenadesClasses);
		local n=0;
		local next=curr;

		repeat
			next=next+1;
			n=n+1;
			if(next>gtypecount)then
				next=1;
			end
		--next == 1 mean "rock" so always available
		until(next==1 or (self.Ammo[GrenadesClasses[next]] and self.Ammo[GrenadesClasses[next]]>0) or n>=gtypecount)


		self.Ammo[GrenadesClasses[curr]]=self.cnt.numofgrenades;
		self.cnt.numofgrenades=self.Ammo[GrenadesClasses[next]];
		self.cnt.grenadetype=next;
		self.GrenadeType=GrenadesClasses[next];
	end,
	[ScriptEvent_MeleeAttack]=function(self,Params)
		--System:Log("MELEE SERVER");
		self.cnt.weapon_busy=1;
		-- move the raycast in C++ and send just a event when an hit occur
		local t=Game:GetInstantHit(Params);
		if(t)then
			if(t.target)then
				if(self.melee_damage)then
					t.damage=self.melee_damage
				else
					t.damage=100;
				end
				t.melee=1;
				t.target:Damage(t);

				--System:Log("DRAW MELEE BLOOD 111");				
			end
			local MeleeHit=t.target_material.melee_punch;
			if (self.MeleeHitType and t.target_material[self.MeleeHitType]) then
				MeleeHit=t.target_material[self.MeleeHitType];
				System:LogToConsole("player specific melee");
			else
				System:LogToConsole("standard melee");
			end
			ExecuteMaterial(t.pos,t.normal,MeleeHit,1);
		else
			--System:Log("MISSED");
		end
	end,
	[ScriptEvent_PhysicalizeOnDemand]=BasicPlayer.PhysicalizeOnDemand,
};

BasicPlayer.Client_EventHandler={
	[ScriptEvent_FireModeChange]=function(self,Params)
		local CurWeapon = self.cnt.weapon;
		local WeaponParams =
		{
			shooter = self;
		};
		-- Call the weapon so it has the chance to abort any active
		-- processes going on for the old firemode
		return BasicWeapon.Client_OnEvent(CurWeapon, ScriptEvent_FireModeChange, WeaponParams);
	end,
	[ScriptEvent_FlashLightSwitch]=function(self,Params)
--System:Log( "---------------------- fLight switched" );
		if(self.fLightSound == nil) then return end
		Sound:SetSoundPosition(self.fLightSound, self:GetPos());
		Sound:PlaySound( self.fLightSound );
	end,
	[ScriptEvent_Command]=BasicPlayer.ProcessCommand,
	[ScriptEvent_AnimationKey]=function(self,Params)
		if( type(Params) == "table" ) then 
			if( Params.userdata ) then
				if( Params.userdata~=0 ) then
--System:Log("Playing SOUND on ANI");
System:Log("Playing SOUND on ANI "..Params.animation);
					Sound:SetSoundPosition(Params.userdata, self:GetPos());
					Sound:PlaySound( Params.userdata );
				end
			else
				BasicPlayer.DoStepSound( self );
			end
		else
			BasicPlayer.DoStepSound( self );
		end
	end,
	[ScriptEvent_SelectWeapon]=function(self,Params)
		if((self==_localplayer) and ClientStuff.vlayers:IsActive("Binoculars"))then
			ClientStuff.vlayers:DeactivateLayer("Binoculars",1);
		end
		if(not self.cnt.first_person)then
			self:StartAnimation(0,"weaponswitch",1);
		end
	end,
	[ScriptEvent_FireGrenade]=function(self,Params)
		local gclass=GrenadesClasses[self.cnt.grenadetype]
		if(gclass and self.Ammo[gclass]>0)then
			return BasicPlayer.Client_OnFireGrenade(self, Params);
		end
	end,
	[ScriptEvent_MeleeAttack]=function(self,Params)
		System:Log("MELEE CLIENT");
		--PLAY SOUND

		if(self.melee_sounds~=nil) then
			System:Log("BasicPlayer.PlayOneSound( self, self.melee_sounds, 100 )");
			BasicPlayer.PlayOneSound( self, self.melee_sounds, 100 );
		end

		if(self.cnt.first_person)then
			if(self.cnt.weapon)then
				self.cnt.weapon:StartAnimation( 0, "Melee" , 0.1, 0);
			end
		else
			self:StartAnimation( 0, "amelee" , 0, 0);
		end
	end,
	[ScriptEvent_PhysicalizeOnDemand]=BasicPlayer.PhysicalizeOnDemand,
	[ScriptEvent_StanceChange]=function(self,Params)
		if (self.StanceChangeSound) then
			Sound:PlaySound(self.StanceChangeSound);
		end
	end,

	[ScriptEvent_EnterWater]=BasicPlayer.OnEnterWater,		
};


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicPlayer:PlayPainAnimation( hit )

	if(hit.explosion)then return end 					-- no pain ani for explosions
	if(hit.melee) then return end 						-- no pain ani for melle
	if(hit.shooter == self) then return end		-- no pain ani for falling/droving damage
	
	local zone = self.cnt:GetBoneHitZone(hit.ipart);	
	if(zone == 0) then zone = 1; end
	local aniname = BasicPlayer.PainAnimations[zone];
	
	System:Log("  pain ani ---------  "..zone.."  "..aniname);
	
	self:StartAnimation(0, aniname..1, 4, .1, 1);
	
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicPlayer:SelectGrenade(name)
	local cyclefunc = self.Server_EventHandler[ScriptEvent_CycleGrenade];
	local currgrenade=GrenadesClasses[self.cnt.grenadetype];
	local selected;
	for i,val in GrenadesClasses do
		cyclefunc(self);
		if(GrenadesClasses[self.cnt.grenadetype]==name)then
			selected=1;
			break;
		end
	end
	if(not selected)then
		BasicPlayer.SelectGrenade(self,currgrenade);
	end
end
