Player = {

------------------------------------------------------------------------------------
	painSounds = {
			Sound:Load3DSound("SOUNDS/testaudio/paintest1.wav",0,115,3,30),
			Sound:Load3DSound("SOUNDS/testaudio/paintest1.wav",0,115,3,30),
			Sound:Load3DSound("SOUNDS/testaudio/paintest1.wav",0,115,3,30),
			Sound:Load3DSound("SOUNDS/testaudio/paintest1.wav",0,115,3,30),
		},

	deathSounds = {
			Sound:Load3DSound("SOUNDS/testaudio/paintest1.wav",0,115,3,20),
			Sound:Load3DSound("SOUNDS/testaudio/paintest1.wav",0,115,3,20),
			Sound:Load3DSound("SOUNDS/testaudio/paintest1.wav",0,115,3,20),
			Sound:Load3DSound("SOUNDS/testaudio/paintest1.wav",0,115,3,20),
		},
		
	melee_sounds = {
			Sound:Load3DSound("Sounds/Weapons/melee/swish.wav",0,115,3,20),
	},
	EquipmentSounds = {
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle1.wav",SOUND_UNSCALABLE,50,5,30),
		--Sound:Load3DSound("SOUNDS/player/playermovement/gingle2.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle3.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle4.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle5.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle6.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle7.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle8.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle9.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle10.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle11.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle12.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle13.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle14.wav",SOUND_UNSCALABLE,50,5,30),
		Sound:Load3DSound("SOUNDS/player/playermovement/gingle15.wav",SOUND_UNSCALABLE,50,5,30),

	},
	EquipmentSoundProbability=100,
	--StanceChangeSound=Sound:LoadSound("SOUNDS/player/playermovement/stancechange4.wav",SOUND_UNSCALABLE,255),
	
	-- COMMENTED DUE TO BAD SOUNDING, PLEASE DO NOT REMOVE YET !!! 
	--ExhaustedBreathingSound=Sound:LoadSound("sounds/player/exhaustedbreathLP2.wav",SOUND_UNSCALABLE,255),
	--ExhaustedBreathingStart=3,	-- start breathing after this amount of seconds after start running
	--ExhaustedBreathingStop=2,		-- stop breathing after this amount of seconds after stop running
------------------------------------------------------------------------------------

	iLastWaterSurfaceParticleSpawnedTime = _time,
  Energy = 50,
	MaxEnergy = 100,
	EnergyChanged = nil,


	vLastPos = { x=0, y=0, z=0 },
	fLastRefractValue = 0,
    bSplashProcessed = nil,
	--iCurVehicle = nil,
	
	BinocularsActive = 0,

	Ammo = {
		Pistol = 0,
		Assault = 0,
		Sniper = 0,
		Minigun = 0,
		Shotgun = 0,
		MortarShells = 0,
		Grenades = 0,
		HandGrenades = 0,
		Rocket = 0,
		Battery = 0,
	},

	WeaponState = nil,

	soundtimer = 0,

	Properties = {
		bHasArmor = 0,
		bHelmetOnStart = 0,
		eye_height = 2.0,
		species = 0,
		max_health = 100,
		groupid = 0,
		bTrackable=1,

	},
	
	PhysParams = {
		mass = 80,
		height = 1.8,
		-- Original Eye eyeheight = 1.7,
		eyeheight = 1.6,
		sphereheight = 1.2,
		radius = 0.45,
	},

--pe_player_dimensions structure
-- change log
-- 1.july.02: x,y size changed from 0.6 to 0.4 allow the player to enter a 1meter wide gap
--            animation looks fine, no wall cliping. Crouch height changed from 1.1 to 1.5
--            and x,y from 0.6 to 0.45. At height 1.1 the players head was inside a wall. 
--            Now looks better :] (ray)

	PlayerDimNormal = {
		height = 1.8,
		eye_height = 1.7,
		ellipsoid_height = 1.2,
		x = 0.45,
		y = 0.45,
		z = 0.6,
	},
	PlayerDimCrouch = {
		height = 1.5,
		eye_height = 1.0,
		ellipsoid_height = 0.95,
		x = 0.45,
		y = 0.45,
		z = 0.5,
	},
	PlayerDimProne = {
		height = 0.4,
		eye_height = 0.5,
		ellipsoid_height = 0.35,
		x = 0.45,
		y = 0.45,
		z = 0.2,
	},
	AniRefSpeeds = {
	-- those are not real scale ceff's - animaation will slide, BUT sound for first person should be ok
		WalkFwd = 3.5,
		WalkSide = 3.5,
		WalkBack = 3.5,
		XWalkFwd = 3.5,
		XWalkSide = 3.5, 
		XWalkBack = 3.5,
		RunFwd = 4.8,
		RunSide = 4.8,
		RunBack = 4.8,
		CrouchFwd = 2.6,
		CrouchSide = 2.6,
		CrouchBack = 2.6,
		
--		WalkFwd = 1.27,
--		WalkSide = 1.22,
--		WalkBack = 1.29,
--		XWalkFwd = 1.2,
--		XWalkSide = 1.0, 
--		XWalkBack = 0.94,
--		RunFwd = 4.62,
--		RunSide = 3.57,
--		RunBack = 4.62,
--		CrouchFwd = 1.02,
--		CrouchSide = 1.02,
--		CrouchBack = 1.04,
		
		
	},
	
	DeadBodyParams = {
	  max_time_step = 0.025,
	  gravityz = -7.5,
	  sleep_speed = 0.025,
	  damping = 0.3,
	  freefall_gravityz = -9.81,
	  freefall_damping = 0.1,

	  lying_mode_ncolls = 4,
	  lying_gravityz = -5.0,
	  lying_sleep_speed = 0.065,
	  lying_damping = 1.5,
		
		water_damping = 0.1,
		water_resistance = 1000,	
	},
	
	Params = { }, --used to pass params to the basic player

	keycards={},	-- holds player's keycards
	explosives={},	-- holds player's explosives

	SwayModyfierProning = 0.01,
	SwayModyfierCrouching = 0.5,

--	OnReset = BasicPlayer.OnReset,

	GrenadeType = "ProjFlashbangGrenade",
	
	move_params={
		speed_run=5.6,
		speed_walk=3.5,
		speed_crouch=2.6,
		speed_prone=0.6,
		jump_force=4.3,
		lean_angle=7.5,
		bob_pitch=0.015,
		bob_roll=0.035,
		bob_lenght=5.5,
		bob_weapon=0.002,
	},
	
	SoundEvents={
		{"srunfwd",		7  },
		{"srunfwd",		19 },
		{"srunback",		5  },
		{"srunback",		14 },
		{"xwalkfwd", 		2  },
		{"xwalkfwd", 		26 },
		{"xwalkback", 		0  },
		{"xwalkback", 		23 },
		{"xwalkright",		2  },
		{"xwalkright",		19 },
		{"xwalkleft",		2  },
		{"xwalkleft",		27 },
		{"swalkback", 		0  },
		{"swalkback", 		16 },
		{"swalkfwd",  		2  },
		{"swalkfwd",  		19 },
		{"swalkleft",  		2  },
		{"swalkleft",  		19 },
		{"swalkright",		4  },
		{"swalkright",		13 },
                {"srunleft",		13 },
                {"srunleft",		13 },
		{"srunright",		3  },
		{"srunright",		13 },
--		{"cwalkback",		14,			0},
--		{"cwalkback",		30,			0},
--		{"cwalkfwd",		1,			0},
--		{"cwalkfwd",		17,			0},
--		{"cwalkleft",		1,			0},
--		{"cwalkleft",		12,			0},
--		{"cwalkright",		4,			0},
--		{"cwalkright",		19,			0},


		{"cwalkback",		9  },
		{"cwalkback",		33 },
		{"cwalkfwd",		12 },
		{"cwalkfwd",		31 },
		{"cwalkleft",		10 },
		{"cwalkleft",		27 },
		{"cwalkright",		7  },
		{"cwalkright",		29 },

    		{"pwalkfwd",		3  },

		{"arunback",		6  },
		{"arunback", 		15 },
		{"arunfwd", 		7  },
		{"arunfwd", 		19 },
		{"awalkback", 		1  },
		{"awalkback", 		17 },
		{"awalkfwd", 		1  },
		{"awalkfwd", 		20 },
		{"awalkleft", 		1  },
		{"awalkleft", 		18 },
		{"awalkright", 		1  },
		{"awalkright", 		20 },
		{"arunleft", 		4  },
		{"arunleft", 		13 },
		--{"arunback", 		5  },
		--{"arunback", 		15 },
		--{"arunleft", 		4  },
		--{"arunleft", 		13 },
		{"arunright", 		3  },
		{"arunright", 		13 },
		{"pwalkback",		3  },
		{"pwalkleft",		3  },
		{"pwalkright",		3  },
		
--		{"cwalkfwd",		1,Sound:Load3DSound("SOUNDS/ai/pain/pain5.wav",SOUND_UNSCALABLE,250,150,230)},
		
},
	
	
}

--------------------------------------------------------------------------------------------------------
function Player:OnReset()	
	if (self.JustLoaded==nil) then	-- [lennert] this is a dirty hack because OnReset is called after OnLoad for not very clear reasons; this should be fixed !
		self.keycards={};
	end
	self.JustLoaded=nil;	-- [lennert] this is a dirty hack because OnReset is called after OnLoad for not very clear reasons; this should be fixed !
	self.explosives={};	
	
	self.cnt:SetMoveParams(self.move_params);
	BasicPlayer.OnReset(self)
	AI:RegisterWithAI(self.id, AIOBJECT_PLAYER, self.Properties);
	self:EnableUpdate(1);
end


--------------------------------------------------------------------------------------------------------
function Player:RegisterStates()
	self:RegisterState( "Alive" );
	self:RegisterState( "Dead" );
end

function Player:LoadModel()
	if(self.model_loaded==nil)then
		System:Log("self.cnt.model = "..self.cnt.model);
		self:LoadCharacter(self.cnt.model,0);
		self["model_loaded"]=1;
		if(self.Properties.bHelmetOnStart==1)	then
			self:LoadObject( "objects/characters/mercenaries/accessories/helmet.cgf", 0, 1 );
		end	
	end
end
--------------------------------------------------------------------------------------------------------
function Player:Server_OnInit()
	-- register as main guy in the AI system
	self:LoadModel();
	BasicPlayer.Server_OnInit( self );
	self.cnt:SetMoveParams(self.move_params);			
	self:OnReset();
end

--------------------------------------------------------------------------------------------------------
function Player:Client_OnInit()
	self:LoadModel();
	BasicPlayer.Client_OnInit( self );
	self.cnt:SetMoveParams(self.move_params);			
end

--------------------------------------------------------------------------------------------------------
function Player:ChangeEnergy( Units )
	self.EnergyChanged = 1;
	self.Energy = self.Energy + Units;
	if (self.Energy > self.MaxEnergy) then
		self.Energy = self.MaxEnergy;
	end
	if (self.Energy < 0) then
		self.Energy = 0;
	end
end

--------------------------------------------------------------------------------------------------------
function Player:OnLoad(stm)
	BasicPlayer.OnLoad(self,stm);
	self.keycards=ReadFromStream(stm);
	-- fix 15: mission objectives (TAB screen) come back with the checkpoint. They travel inside the keycards
	-- table (key "__objectives"), so the save layout stays the same: older saves still load, saves made with
	-- this file also load with the original scripts (the keycard HUD draws only entries equal to 1).
	local objs=nil;
	if(self.keycards)then
		objs=self.keycards.__objectives;
		self.keycards.__objectives=nil;
	end
	if(Hud)then
		Hud.objectives=objs or {};
	end
	self.JustLoaded=1;	-- [lennert] this is a dirty hack because OnReset is called after OnLoad for not very clear reasons; this should be fixed !
end

--------------------------------------------------------------------------------------------------------
function Player:OnSave(stm)
	BasicPlayer.OnSave(self,stm);
	if(Hud and Hud.objectives and self.keycards)then	-- fix 15 (see OnLoad)
		self.keycards.__objectives=Hud.objectives;
	end
	WriteToStream(stm,self.keycards);
	if(self.keycards)then
		self.keycards.__objectives=nil;
	end
end

--------------------------------------------------------------------------------------------------------
Player.Server =
{
	OnTimer = BasicPlayer.Server_OnTimer,
	OnEvent = BasicPlayer.Server_OnEvent,
	OnInit = Player.Server_OnInit,
	Alive = {
		OnBeginState = function( self )
			System:LogToConsole("ServerAliveState");
		end,
		OnEvent = BasicPlayer.Server_OnEvent,
		OnDamage = BasicPlayer.Server_OnDamage,
		OnTimer = BasicPlayer.Server_OnTimer,
	},
	Dead = {
		OnBeginState = function( self )
			self:NetPresent(nil);
			System:LogToConsole("ServerDeadState health "..self.cnt.health);
		end,
		OnDamage = function (self, hit)
			BasicPlayer.Server_OnDamageDead( self, hit);
		end,		
		OnEndState = function( self )
		end,
		OnTimer = BasicPlayer.Server_OnTimer,
	},
}

--------------------------------------------------------------------------------------------------------
Player.Client =
{
	OnTimer = BasicPlayer.Client_OnTimer,
	OnInit = Player.Client_OnInit,
	Alive = {
		OnTimer = BasicPlayer.Client_OnTimer,
		OnBeginState = function( self )
			BasicPlayer.OnBeginAliveState(self);
			if( self== _localplayer) then
				Input:SetActionMap("default");
				System:LogToConsole("ClientAliveState MY player");
				self.AnimationSystemEnabled = 1;
				self:EnablePhysics(1);
				if (Hud) then
					Hud.deaf_time=nil;
				end
			end
			System:LogToConsole("ClientAliveState");
		end,
		OnEndState = function( self )
		end,
		OnDamage = BasicPlayer.Client_OnDamage,
		OnContact = Player.OnContact,
		OnEvent = function (self,EventId,Params)
			local EventSwitch=self.EventHandlers[EventId];
			if(EventSwitch)then
				EventSwitch(self,EventId,Params);
			else
				BasicPlayer.Client_OnEvent(self,EventId,Params);
			end
		end
	},
	Dead = {
		OnBeginState = function( self )
			BasicPlayer.OnBeginDeadState(self);
			if (self == _localplayer) then
				ClientStuff.vlayers:DeactivateAll();
				if (Hud) then
					Hud.deaf_time=nil;
				end
			end
			self:KillCharacter(0);
			self:SetPhysicParams(PHYSICPARAM_SIMULATION, self.DeadBodyParams);
			self:SetPhysicParams(PHYSICPARAM_ARTICULATED, self.DeadBodyParams);
			self:SetPhysicParams(PHYSICPARAM_BUOYANCY, self.DeadBodyParams);
			self.cnt:StartDie( self.deathImpuls, self.deathPoint, self.deathImpulsePart, self.deathType );
			-- stop breathing sound in case it is still playing...
			if (self.ExhaustedBreathingSound) then
				Sound:StopSound(self.ExhaustedBreathingSound);
			end
			System:Log("ClientDeadState --- health "..self.cnt.health);
			BasicPlayer.PlayOneSound( self, self.deathSounds, 110 );
		end,
		OnUpdate = BasicPlayer.Client_DeadOnUpdate,
		OnEndState = function( self )
		end,
		OnDamage=BasicPlayer.Client_OnDamage,
	},
}

--------------------------------------------------------------------
-- Items switch
Player.ItemActivation={
	-------------------------------
	[0]=function(self)
		--System:LogToConsole("ITEM1")

		if(ClientStuff.vlayers:IsActive("NightVision"))then
			ClientStuff.vlayers:DeactivateLayer("NightVision");
		end

		if(ClientStuff.vlayers:IsActive("HeatVision"))then
			ClientStuff.vlayers:DeactivateLayer("HeatVision");
		end

		if(ClientStuff.vlayers:IsActive("Binoculars"))then
			ClientStuff.vlayers:DeactivateLayer("Binoculars");
		else
			if(ClientStuff.vlayers:IsActive("WeaponScope"))then
				ClientStuff.vlayers:DeactivateLayer("WeaponScope",1);
			end
			ClientStuff.vlayers:ActivateLayer("Binoculars");
		end
	end,
	-------------------------------
	[1]=function(self)
		System:LogToConsole("ITEM1");
		-- cycle through nigth vision, heat vision etc.
		if(ClientStuff.vlayers:IsActive("NightVision"))then			
			ClientStuff.vlayers:DeactivateLayer("NightVision");
			-- switch to heat vision now
			r_ScreenRefract=0;
			ClientStuff.vlayers:ActivateLayer("HeatVision");
		else
			if(ClientStuff.vlayers:IsActive("HeatVision"))then
				-- go back to normal binocular layer
				-- [wrapper v47 fix] binocular lens only if the binoculars are
				-- really up; sniper scope lens if the FTB scope is up;
				-- otherwise none (ITEM_1 can also be used without binoculars)
				if(ClientStuff.vlayers:IsActive("Binoculars"))then
					r_ScreenRefract=1;
				elseif(ClientStuff.vlayers:IsActive("WeaponScope") and WeaponScope.state==2
					and _localplayer and _localplayer.cnt.weapon
					and _localplayer.cnt.weapon.DoesFTBSniping)then
					r_ScreenRefract=2;
				else
					r_ScreenRefract=0;
				end
				ClientStuff.vlayers:DeactivateLayer("HeatVision");
			else
				-- activate night vision
				r_ScreenRefract=0;
				ClientStuff.vlayers:ActivateLayer("NightVision");			
			end			
		end
	end,

	-------------------------------
	--[2]=function(self)
	--	System:LogToConsole("ITEM2")
	--	if ( self.Refractive ) then
	--		self.Refractive = nil;
	--		System:LogToConsole("Refr Off");
	--	else
	--		self.Refractive = 1;
	--		System:LogToConsole("Refr On");
	--		end
	--end,
	-------------------------------
	--[3]=function(self)
	--	System:LogToConsole("ITEM3")
	--	if(ClientStuff.vlayers:IsActive("HeatVision"))then
	--		ClientStuff.vlayers:DeactivateLayer("HeatVision");
	--	else
	--		ClientStuff.vlayers:DeactivateLayer("NightVision");
	--		ClientStuff.vlayers:ActivateLayer("HeatVision");
	--	end
	--end,
}
--------------------------------------------------------------------
-- Events switch
Player.EventHandlers={
	-------------------------------
	[ScriptEvent_ZoomToggle] = function(self,EventId,Params)
		System:LogToConsole("ScriptEvent_ZoomToggle");
		if (self.cnt.weapon and (not self.cnt.weapon.NoZoom)) then
			local dead_switch=self.cnt.weapon.ZoomDeadSwitch;
			if (self.cnt.first_person) then
				if(ClientStuff.vlayers:IsActive("WeaponScope"))then
					if( (Params==0 and (not dead_switch))
						or (Params==1 and dead_switch))then
						ClientStuff.vlayers:DeactivateLayer("WeaponScope");
					end
				else
					if(Params==1)then
						if(ClientStuff.vlayers:IsActive("Binoculars"))then
							ClientStuff.vlayers:DeactivateLayer("Binoculars",1);
						end
						ClientStuff.vlayers:ActivateLayer("WeaponScope");
					end
				end
			end
		end
	end,
	-------------------------------
	[ScriptEvent_ZoomIn] = function(self,EventId,Params)
		ZoomView:ZoomIn();
	end,
	-------------------------------
	[ScriptEvent_ZoomOut] = function(self,EventId,Params)
		ZoomView:ZoomOut();
	end,
	-------------------------------
	[ScriptEvent_ItemActivated] = function(self,EventId,Params)
		local ItemSwitch=self.ItemActivation[Params];
		if(ItemSwitch)then
			ItemSwitch(self);
		end
	end,
	-------------------------------
	[ScriptEvent_Deafened] = function(self,EventId,Params)
		if (self==_localplayer and Hud~=nil) then
			if (Hud.deaf_time) then
				if (Hud.deaf_time<Params.fTime) then
					Hud.deaf_time=Params.fTime;
				end
			else
				Hud.deaf_time=Params.fTime;
			end
			System:LogToConsole("Deafened for "..Hud.deaf_time.." seconds...");
		end
	end,
	[ScriptEvent_SelectWeapon]=function (self,eventid,Params)
		if(Hud)then
			Hud.weapons_alpha=1;
		end
		BasicPlayer.Client_OnEvent(self,EventId,Params);
	end,
}
--------------------------------------------------------------------------------------------------------