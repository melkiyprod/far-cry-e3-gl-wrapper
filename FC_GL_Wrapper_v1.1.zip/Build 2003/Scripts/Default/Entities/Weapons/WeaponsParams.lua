-- MaxAmmo
MaxAmmo = 
{
	Battery=100,
	Pistol=150,
	SMG=300,
	Assault=300,
	Sniper=10,
	Minigun=100,
	Shotgun=50,
	MortarShells=10,
	Grenades=6,
	HandGrenade=6,
	Rock=6,
	FlashbangGrenade=6,
	GlowStick=6,
	SmokeGrenade=6,
	FlareGrenade=6,
	Rocket=10,
	Stamina=9999999,
}

--			min_accuracy=the worst the gun ever gets: 1 = good, 0 = bad, (ending)
--			max_accuracy=the best the gun ever gets: 1 = good, 0 = bad, (starting)
--			reload_time=
--			fire_rate= seconds between rounds (pretty good now)
--			distance= distance of 1 paratime!
--			damage= units of damage at end of first paratime 
--			damage_drop_per_meter=begns at beginning of second paratime,
--			bullet_per_shot=1,
--			angle_decay=10, angle of a single paratime
--			paratimes= number of paratimes,
--			min_recoil= The best it gets 
--			max_recoil= The worst it gets 
----------------------------------------------------------------------
----------------------------------------------------------------------
----------------------------------------------------------------------

WeaponsParams={
----------------------------------------------------------------------
--Machete (knify thingy)
----------------------------------------------------------------------
----NOT YET IMPLEMENTED--

----------------------------------------------------------------------
--DE (Pistol/small cannon)
----------------------------------------------------------------------
	DE={
		--SINGLE FIRE-------------------------------------------------
		{
			aim_impovement=0.1,
			accuracy_decay_on_run=0.8,
			min_accuracy=0.60,
			max_accuracy=0.88,
			reload_time=1.62,
			fire_rate=0.7,
			distance=30,
			damage=60, 
			damage_drop_per_meter=.40,
			bullet_per_shot=1,
			angle_decay=5,
			paratimes=3,
			min_recoil=1.0,
			max_recoil=2.0,
			iImpactForceMul = 100, -- 5 bullets divided by 10
			iImpactForceMulFinal = 40, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 130, -- 5 bullets divided by 10
			hud_icon="single",
		},
	},
----------------------------------------------------------------------
--M4 (Assault rifle)
----------------------------------------------------------------------
	M4={
		--AUTOMATIC FIRE----------------------------------------------
		{
			aim_impovement=0.2,
			accuracy_decay_on_run=0.8,
			min_accuracy=0.75,
			max_accuracy=0.88,
			reload_time=2.3,
			fire_rate=0.08,
			distance=35,
			damage=42, 
			damage_drop_per_meter=.2,
			bullet_per_shot=1,
			angle_decay=5,
			paratimes=3,
			min_recoil=0.4,
			max_recoil=0.7,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 40, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 130, -- 5 bullets divided by 10
			hud_icon="auto",

		},
		--SINGLE SHOT-------------------------------------------------
		{
			aim_impovement=0.2,
			accuracy_decay_on_run=0.8,
			min_accuracy=0.75,
			max_accuracy=0.88,
			reload_time=2.3,
			fire_rate=0.08,
			distance=40,
			damage=42, 
			damage_drop_per_meter=.3,
			bullet_per_shot=1,
			angle_decay=5,
			paratimes=4,
			min_recoil=0.45,
			max_recoil=1.0,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 40, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 130, -- 5 bullets divided by 10
			hud_icon="single",

		},
	},
----------------------------------------------------------------------
--AG36 (Assault rifle with grenade launcher)
----------------------------------------------------------------------
	AG36={
		--AUTOMATIC FIRE----------------------------------------------
		{
			aim_impovement=0.3,
			accuracy_decay_on_run=1,
			min_accuracy=0.25,
			max_accuracy=1.1,
			reload_time=2.6,
			fire_rate=0.11,
			distance=40,
			damage=42, 
			damage_drop_per_meter=.1,
			bullet_per_shot=1,
			angle_decay=5,
			paratimes=3,
			min_recoil=0.5,
			max_recoil=1.5,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 40, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 130, -- 5 bullets divided by 10
			hud_icon="auto",	-- fix 18: was "single" - the HUD showed one bullet for automatic fire
		},
		--GRENADE-----------------------------------------------------
		{
			--accuracy [desn't apply]
			reload_time=1.5,
			fire_rate=1.0,
			-- distance [desn't apply]
			-- damage [desn't apply]
			-- damage_drop_per_meter [desn't apply]
			bullet_per_shot=1,
			-- angle_decay [desn't apply]
			-- paratimes [desn't apply]
			-- min_recoil [desn't apply]
			-- max_recoil [desn't apply]
			hud_icon="grenade",
		},
	},
----------------------------------------------------------------------
--OICW (Assault rifle with 20mm secondary fire)
----------------------------------------------------------------------
	OICW={
		--AUTOMATIC FIRE----------------------------------------------
		{
			aim_impovement=0.3,	
			accuracy_decay_on_run=0.7,
			min_accuracy=0.60,
			max_accuracy=0.95,
			reload_time=2.6,
			fire_rate=0.07,
			distance=35,
			damage=42, 
			damage_drop_per_meter=.2,
			bullet_per_shot=1,
			angle_decay=5,
			paratimes=3,
			min_recoil=0.3,
			max_recoil=1.23,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 40, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 130, -- 5 bullets divided by 10
			hud_icon="auto",
		},
		--grenade (not 20MM)-----------------------------------------------------
		{
			accuracy_decay_on_run=0.8,
			min_accuracy=0.65,
			max_accuracy=0.99,
			reload_time=2.3,
			fire_rate=0.8,
			distance=40,
			damage=130, 
			damage_drop_per_meter=.06,	
			bullet_per_shot=1,
			angle_decay=10,
			paratimes=3,
			min_recoil=0.5,
			max_recoil=1.2,
			hud_icon="grenade",
		},
	},
----------------------------------------------------------------------
--MP5 (Sub machine gun)
----------------------------------------------------------------------
	MP5={
		--AUTOMATIC FIRE----------------------------------------------
		{
			aim_impovement=0.1,
			accuracy_decay_on_run=0.8,
			min_accuracy=0.60,
			max_accuracy=0.85,
			reload_time=2.3,
			fire_rate=0.06,
			distance=30,
			damage=25, 
			damage_drop_per_meter=.4,
			bullet_per_shot=1,
			angle_decay=10,
			paratimes=3,
			min_recoil=0.4,
			max_recoil=0.8,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 15, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 75, -- 5 bullets divided by 10
			hud_icon="auto",

		},
		--SINGLE SHOT-------------------------------------------------
		{
			aim_impovement=0.1,
			accuracy_decay_on_run=0.8,
			min_accuracy=0.60,
			max_accuracy=0.85,
			reload_time=2.3,
			fire_rate=0.2,
			distance=30,
			damage=25, 
			damage_drop_per_meter=.4,	
			bullet_per_shot=1,
			angle_decay=10,
			paratimes=3,
			min_recoil=0.25,
			max_recoil=1.2,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 15, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 75, -- 5 bullets divided by 10
			hud_icon="single",
		},
	},
----------------------------------------------------------------------
--P90 (Sub machine gun)
----------------------------------------------------------------------
	P90={
		--AUTOMATIC FIRE----------------------------------------------
		{
			aim_impovement=0.1,
			accuracy_decay_on_run=0.4,
			min_accuracy=0.70,
			max_accuracy=0.80,
			reload_time=2.6,
			fire_rate=0.05,
			distance=35,
			damage=35, 
			damage_drop_per_meter=.2,
			bullet_per_shot=1,
			angle_decay=8,
			paratimes=3,
			min_recoil=0.25,
			max_recoil=0.5,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 30, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 100, -- 5 bullets divided by 10
			hud_icon="auto",
		},
	},

----------------------------------------------------------------------
--AW50 (Sniper rifle/camping device)
----------------------------------------------------------------------
	AW50={
		--SINGLE FIRE-------------------------------------------------
		{
			accuracy_decay_on_run=1,
			min_accuracy=1.00,
			max_accuracy=1.00,
			reload_time=2.5,
			fire_rate=1.35,
			distance=160,
			damage=600, 
			damage_drop_per_meter=.3,
			bullet_per_shot=1,
			angle_decay=0,
			paratimes=4,
			min_recoil=0,
			max_recoil=0.3,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 15, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 300, -- 5 bullets divided by 10
			hud_icon="single",
		},
	},
----------------------------------------------------------------------
--Pancor (Semi automatic shotgun)
----------------------------------------------------------------------
	Pancor={
		--SINGLE FIRE-------------------------------------------------
		{
			aim_impovement=0.1,
			accuracy_decay_on_run=0,
			min_accuracy=0.080,
			max_accuracy=0.080,
			reload_time=2.4,
			fire_rate=0.4,
			distance=30,
			damage=120,
			damage_drop_per_meter=0.2,
			bullet_per_shot=20,
			angle_decay=1,
			paratimes=3,
			min_recoil=0.1,
			max_recoil=0.15,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 100, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 150, -- 5 bullets divided by 10
			hud_icon="single",
		},
	},
----------------------------------------------------------------------
--M249 (Heavy machine gun)
----------------------------------------------------------------------
	M249={
		--AUTOMATIC FIRE-------------------------------------------------
		{
			accuracy_decay_on_run=1,
			min_accuracy=0.6,
			max_accuracy=0.8,
			reload_time=3.3,
			fire_rate=0.12,
			distance=60,
			damage=25, 
			damage_drop_per_meter=.05,
			bullet_per_shot=1,
			angle_decay=8,
			paratimes=4,
			min_recoil=0.25,
			max_recoil=2.50,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 30, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 100, -- 5 bullets divided by 10
			hud_icon="auto",
		},
	},
----------------------------------------------------------------------
--Shocker (Purse weapon/women's self defence weapon)
----------------------------------------------------------------------
	Shocker={
		--SINGLE FIRE-------------------------------------------------
		{
			min_accuracy=1,
			max_accuracy=1,
			reload_time=0.1,
			fire_rate=0.1,
			distance=2.2,
			damage=70,
			--damage_drop_per_meter [doesn't apply]
			--angle_decay [doesn't apply]
			paratimes=1,
			min_recoil=0,
			max_recoil=0,
			no_ammo=1,
			hud_icon="melee",
		},
	},
----------------------------------------------------------------------
--Machete (Bucher weapon)
----------------------------------------------------------------------
	Machete={
		--SINGLE FIRE-------------------------------------------------
		{
			min_accuracy=1,
			max_accuracy=1,
			reload_time=0.1,
			fire_rate=0.3,
			distance=1.4,
			damage=80,
			--damage_drop_per_meter [doesn't apply]
			--angle_decay [doesn't apply]
			paratimes=1,
			min_recoil=0,
			max_recoil=0,
			no_ammo=1,
			mat_effect="melee_slash",
			hud_icon="melee",
		},
	},
----------------------------------------------------------------------
--RL (Rocket Launcher)
----------------------------------------------------------------------
	RL={
		--SINGLE FIRE-------------------------------------------------
		{
			--accuracy [doesn't apply]
			reload_time=4.5,
			fire_rate=5,
			--distance [doesn't apply]
			--damage [doesn't apply]
			--damage_drop_per_meter [doesn't apply]
			--angle_decay [doesn't apply]
			--paratimes [doesn't apply]
			--min_recoil [doesn't apply]
			--max_recoil [doesn't apply]
			hud_icon="rocket",
		},
	},
----------------------------------------------------------------------
--MG (Mounted Machine Gun)
----------------------------------------------------------------------
	MG={
		{
			aim_impovement=0.1,
			--accuracy_decay_on_run=0.8,
			min_accuracy=0.75,
			max_accuracy=0.95,
			--reload_time=2.3,
			fire_rate=0.082,
			distance=70,
			damage=25, 
			damage_drop_per_meter=.2,
			bullet_per_shot=1,
			angle_decay=5,
			paratimes=2,
			min_recoil=0.4,
			max_recoil=0.7,
			iImpactForceMul = 25, -- 5 bullets divided by 10
			iImpactForceMulFinal = 40, -- 5 bullets divided by 10	
			iImpactForceMulFinalTorso = 130, -- 5 bullets divided by 10
			hud_icon="auto",
		--
		}
	},

}