Script:LoadScript("scripts/default/hud/DefaultZoomHUD.lua");
Script:LoadScript("scripts/default/hud/AimModeZoomHUD.lua");
Game:CreateVariable("w_firstpersontrail","0")
BasicWeapon = {
	UnderwaterBubbles = {
		focus = 0.2,
		color = {1,1,1},
		speed = 0.25,
		count = 1,
		size = 0.05, size_speed=0.0, -- default size 0.2
		gravity = { x = 0.0, y = 0.0, z = 2.6 },
		lifetime=1.5, -- default 2.5
		tid = System:LoadTexture("textures\\bubble.tga"),
		frames=0,
		color_based_blending = 1,
		fPosRandomOffset=0,
	},
	--temp tables
	normal_000={x=0,y=0,z=0},
	normal_001={x=0,y=0,z=1},
	normal_101={x=1,y=0,z=1},
	temp_dir={x=0,y=0,z=0},
	temp_pos={x=0,y=0,z=0},
	VoidDist = 1000,		-- trace distance if no hit
	blip=Sound:LoadSound("SOUNDS/hit.wav",0,128),
};
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:SyncVarCache(shooter)
	shooter.firemodenum=shooter.cnt.firemode+1;
	shooter.fireparams=self.cnt[shooter.cnt.firemode];
	shooter.sounddata=shooter.weapon_info.SndInstances[shooter.firemodenum];
end

function BasicWeapon:InitParams()
	if(self.name and (not self.params_initialized))then
		if(WeaponsParams[self.name])then
			System:Log("~~~~~~~~~~~~~~~~~~Initializing"..self.name);
			for i,val in self.FireParams do
				local params=WeaponsParams[self.name][i];
				if(params)then
					System:Log("~~~~~~~~~~~~~~~~~~Merging"..i);
					merge(val,params);
				end
			end
			self.params_initialized=1;
		end
	end
end
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_OnInit()
	BasicWeapon.InitParams(self);
	if (self.bFireParamsSet == nil) then
		self.bFireParamsSet = 1;
		for idx, element in self.FireParams do
			self.cnt:SetWeaponFireParams( element );
		end
	end
	if ( self.CrosshairTexturePath ) then
		self.cnt:SetWeaponCrosshair( self.CrosshairTexturePath, 0);
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnInit()
	BasicWeapon.InitParams(self);
	-- at the beginning set heat intensity for objects,1st and 3rd person weapons to minimum 
	self:SetShaderFloat("HeatIntensity",0,0,-1);

	if(self.ZoomNoSway)then
		self.Sway=nil;
	else
		self.Sway=1.5;
	end
	
	if (self.bFireParamsSet == nil) then
		self.bFireParamsSet = 1;
		for idx, element in self.FireParams do
			self.cnt:SetWeaponFireParams( element );
		end
	end

	self.cnt:SetWeaponBind("weapon_bone");
	if ( self.CrosshairTexturePath ) then
		self.cnt:SetWeaponCrosshair( self.CrosshairTexturePath, 0);
	end
	
	if (self.iconname) then
		self.icon=System:LoadImage(self.iconname);
	end

	--Attach animation key events to sounds(the table SoundEvents
	--is optionally implemented in the weapon script
	if(self.SoundEvents) then
		for i,event in self.SoundEvents do
			System:Log("ADDING SOUND ["..self.name.."] <"..event[1]..">")
			self:SetAnimationKeyEvent(event[1],event[2],event[3]);
			if(event[4]~=nil)then
				Sound:SetSoundVolume(event[3],event[4]);
			end
		end
	else
		System:Log("WARNING SoundEvents empty ["..self.name.."]")
	end

System:Log("\003 BasicWeapon Init "..self.name);
	if( self.FireParams[1].type ) then
		self.cnt:SetHoldingType(self.FireParams[1].type);
--		self.cnt.type = self.FireParams[1].type;
System:Log("\003 BasicWeapon TYPE is "..self.FireParams[1].type);		
	else 
		self.cnt:SetHoldingType( 1 );
	end	

	self.crosshair=System:LoadImage("Textures/Hud/new/Aimcrosshair.tga");
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnUpdate(delta, shooter)
	-- Cache frequently acessed tables
	if (shooter == _localplayer) then
		local stats = shooter.cnt;
		---------------------------------------
		-- Main Player Specific Behavior
		---------------------------------------
		local CurWeapon = shooter.cnt.weapon;
		shooter.cnt.dmgFireAccuracy = 100;
		-- Idle / fidget animations
		if (self.bDisableIdle == nil) then
			if (self:GetCurAnimation(0) == nil) then
				if (self:IsAnimationRunning(0) == nil) then

				-- Once he begins swimming in the water (using the movement keys
				-- while on top of the water), the player arms will immediately switch 
				-- to a swimming animation, denying him the ability to shoot his gun unless 
				-- he stands still.

					if (shooter.cnt:IsSwimming()) then
						BasicWeapon.RandomAnimation(self,"swim",shooter.firemodenum);
					else	
						if(not shooter.cnt.firing)then
							BasicWeapon.RandomAnimation(self,"idle",shooter.firemodenum);
						end
					end						
				end
			end
		end
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Hide(shooter)
	shooter.cnt.drawfpweapon=nil;
	self:ResetAnimation(0);
--	System:Log("BasicWeapon:Hide");
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Show(shooter)
	shooter.cnt.drawfpweapon=1;
--	System:Log("BasicWeapon:Show");
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_OnFire( params )
	local retval;
	local wi;
	local ammo;
	local TotalAmmoTypeLeft;
	local shooter = params.shooter;
	local stats = shooter.cnt;

	-- For mounted weapons or other unlimited ammo weapons
	if (shooter.fireparams.AmmoType == "Unlimited") then
		wi = nil;
		FireModeNum = 1;
		ammo = 1;
		ammo_left = 1;
	else
		wi = shooter.weapon_info;
		ammo = stats.ammo_in_clip;
		ammo_left = stats.ammo;			
	end

	if (ammo_left > 0 or ammo > 0) then
		if (ammo > 0) then
			-- Substract ammunition
			if (wi  and (shooter.fireparams.AmmoType ~= "Unlimited")) then
				stats.ammo_in_clip = stats.ammo_in_clip - params.bullets;
				ammo = stats.ammo_in_clip;
			end
			
			local AISound = AIWeaponProperties[self.name];
			if (AISound and (shooter.sounddata.FireSounds or shooter.sounddata.FireLoop)) then
				-- generate event
				if (shooter.sounddata.FireLoop) then
					AI:SoundEvent(shooter.sounddata.FireLoop,shooter:GetPos(),AISound.VolumeRadius,AISound.fThreat,0,shooter.id);
				else
					AI:SoundEvent(shooter.sounddata.FireSounds[1],shooter:GetPos(),AISound.VolumeRadius,AISound.fThreat,0,shooter.id);
				end
			else
				if (AISound==nil) then
					System:LogToConsole("\003 [WEAPON WARNING] Weapon "..self.name.." has no AI properties table in the AIWeapons.lua (please add!)");
				else
					System:LogToConsole("\003 [WEAPON WARNING] Weapon "..self.name.." has no sounds registered in the shooter "..shooter:GetName());
				end	
			end

			retval = 1;
		end
		------------------------------------------------------------------------------
		-- AI EVENT clip nearly empty
		-- triggered if ammo in clip is less than 30% of total clip size
		----------------------------------------------------------------------------
		if ( ammo ==  floor(shooter.fireparams.bullets_per_clip*0.33) ) then
			AI:Signal(0,1,"OnClipNearlyEmpty",shooter.id);
		end
	end

	if (stats.ammo == 0) then
		AI:Signal(0,1,"OnNoAmmo",shooter.id);
	end

	-- Return value indicates if weapon can fire
	return retval;
end

function BasicWeapon:PlayShellsEjectionSound(shooter,material_field)
		local normal=self.normal_001;
		local material=shooter.cnt:GetTreadedOnMaterial();
		if (material~=nil) then
			local BulletHitZOffset=-1;		-- offset from gun to play the bullet-hit sound from...
			local BulletHitPos=new(self:GetPos());
			BulletHitPos.z=BulletHitPos.z+BulletHitZOffset;
			ExecuteMaterial(BulletHitPos, normal, material[material_field], 1);
		end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnStopFiring(shooter)
	-- when we stop firing, set heat intensity to minimum 
	shooter.cnt:SetHeatVisionValues("HeatIntensity",0,BITMASK_WEAPON,0.004); -- default 0.2
	BasicWeapon.StopFireLoop(self, shooter, shooter.fireparams, shooter.sounddata);
	if(shooter==_localplayer)then
		if (shooter.fireparams.BulletRejectType==BULLET_REJECT_TYPE_RAPID) then
			BasicWeapon.PlayShellsEjectionSound(self,shooter,"bullet_drop_rapid");
		elseif (shooter.fireparams.BulletRejectType==BULLET_REJECT_TYPE_SINGLE) then
			BasicWeapon.PlayShellsEjectionSound(self,shooter,"bullet_drop_single");			
		end

	end
	
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_ExternalReload(shooter)
	BasicPlayer.Reload(shooter);
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnFire( Params )
	local basic_weapon=BasicWeapon;
	local my_player=_localplayer;
	local shooter=Params.shooter;
	local sound=Sound;
	local cur_time=_time;
	local ReturnVal = nil;
	local FireModeNum;
	local WeaponStateData = nil;
	local CurFireParams;
	local ammo;
	local TotalAmmoTypeLeft;
	local stats;

	-- when we start to fire, set heat intensity to maximum 
	shooter.cnt:SetHeatVisionValues("HeatIntensity",1,BITMASK_WEAPON,-1);

	-- For mounted weapons or other unlimited ammo weapons
	if (self.FireParams[1].AmmoType == "Unlimited") then
		stats = shooter.cnt;
		WeaponStateData = shooter.weapon_info;
		CurFireParams = self.FireParams[1];
		ammo = 1;
		TotalAmmoTypeLeft = 1;
	else
		stats = shooter.cnt;
		WeaponStateData = shooter.weapon_info;
		CurFireParams = shooter.fireparams;
		ammo = stats.ammo_in_clip;
	 	TotalAmmoTypeLeft = stats.ammo;			
	end

	if ((not shooter.cnt.canfire) and shooter.sounddata.DrySound) then
		shooter.cnt:PlaySound( shooter.sounddata.DrySound );
		System:Log("DRYSOUND")
		return
	end
	-- Play animation
	--local FireAnimName = "Fire"..random(1, 2)..(shooter.firemodenum);
	if (shooter == my_player) then
		BasicWeapon.RandomAnimation(self,"fire",shooter.firemodenum);
	end

	-- Obtain the muzzle flash bone
	local fire_pos = Params.pos;
	local bMountedWeapon = shooter.cnt.lock_weapon;
	
	if ((stats.first_person and stats.weaponid > -1)) then
		if( bMountedWeapon )	then 	-- mounted weapon - just get helper
			fire_pos = shooter.cnt:GetTPVHelper(0, "spitfire");
		else
    			fire_pos = self.cnt:GetBonePos("spitfire");
    		end	
	else
--		if( shooter.cnt.lock_weapon )	then 	-- mounted weapon - just get helper
--			fire_pos = self:GetHelperPos("spitfire");		
--		else
			fire_pos = shooter.cnt:GetTPVHelper(0, "spitfire");
--		end
 	end

	-- Fire sound
	if (CurFireParams.FireLoop and CurFireParams.TrailOff) then
		-- Sound is modelled as a loop with a trailoff
		sound:SetSoundLoop(shooter.sounddata.FireLoop, 1);
		if (sound:IsPlaying(shooter.sounddata.FireLoop) == nil and shooter.sounddata.FireLoop) then
			shooter.cnt:PlaySound(shooter.sounddata.FireLoop);
		end
	else
		-- Sound is modelled as a random series of different fire sounds
		local nSoundIdx = random(1, getn( shooter.sounddata.FireSounds ) );
		shooter.cnt:PlaySound(shooter.sounddata.FireSounds[nSoundIdx]);
	end

	-- Spawn a trail
	if(not (tonumber(w_firstpersontrail)==0 and shooter.cnt.first_person))then
		if (CurFireParams.TrailParticle or CurFireParams.Trace) then
				local TrailOrigin=fire_pos;
				-- Use a temporary member table to avoid a table creation		
				local vDirection = basic_weapon.temp_dir;
				
				if (Params.HitPt == nil or (Params.HitPt.x == 0 and Params.HitPt.y == 0 and Params.HitPt.z == 0) ) then
					FastSumVectors(vDirection,TrailOrigin, ScaleVector(Params.dir, basic_weapon.VoidDist));
					vDirection.x = vDirection.x - TrailOrigin.x - (Params.pos.x - TrailOrigin.x );
					vDirection.y = vDirection.y - TrailOrigin.y - (Params.pos.y - TrailOrigin.y );
					vDirection.z = vDirection.z - TrailOrigin.z - (Params.pos.z - TrailOrigin.z );
				else
					vDirection = Params.HitPt;
					vDirection.x = vDirection.x - TrailOrigin.x;
					vDirection.y = vDirection.y - TrailOrigin.y;
					vDirection.z = vDirection.z - TrailOrigin.z;
				end

				-- moving trace
				if (CurFireParams.Trace) then				
					CurFireParams.Trace.init_angles = Params.angles;
					if(Params.HitDist<0) then
						CurFireParams.Trace.lifetime = basic_weapon.VoidDist/CurFireParams.Trace.speed;
					else	
						CurFireParams.Trace.lifetime = Params.HitDist/CurFireParams.Trace.speed;
					end	
					Particle:CreateParticle(TrailOrigin, vDirection, CurFireParams.Trace);
				end
		end
	end

--Particle system flags
--#define PART_FLAG_BILLBOARD     0 // usual particle
--#define PART_FLAG_HORIZONTAL    1 // flat horisontal rounds on the water
--#define PART_FLAG_UNDERWATER    2 // particle will be removed if go out from outdoor water
--#define PART_FLAG_LINEPARTICLE  4 // draw billboarded line from vPosition to vPosition+vDirection
--#define PART_FLAG_SWAP_XY       8 // alternative order of rotation (zxy)
--#define PART_SIZE_LINEAR       16 // change size liner with time
--#define PART_FLAG_NO_OFFSET    32 // disable centering of static objects
--#define PART_FLAG_DRAW_NEAR    64 // render particle in near (weapon) space

	local scope=ClientStuff.vlayers:IsActive("WeaponScope");
	if ((shooter~=_localplayer) or (not scope) or (self.AimMode and scope)) then
		-- Spawn smoke, bubbles, SpitFire etc.
		if (Game:IsPointInWater(Params.pos) == nil) then
			if (fire_pos) then
				if(CurFireParams.MuzzleFlash) then
					CurFireParams.MuzzleFlash.init_angles = Params.angles;
					CurFireParams.MuzzleFlash.init_angles.y = random(0, 360);
					
					-- remember flags
					local flag = CurFireParams.MuzzleFlash.particle_type;
					-- if first person - chcange it
					
					if (bMountedWeapon) then
					--OLD MUZZLE FLASH PARTICLE SYSTEM
						Particle:CreateParticle(fire_pos, shooter.cnt:GetCharacterAngles(), CurFireParams.MuzzleFlash);
					else
					 -- NEW MUZZLE FLASH
					-- restore flags
--					CurFireParams.MuzzleFlash.particle_type = flag;
--NEW MUZZLE FLASH ATTACHMENT SYSTEM //TIMUR&MAX					
						local MuzzleFlashParams = {};
						MuzzleFlashParams.weapon = self;
						MuzzleFlashParams.shooter = shooter;
						MuzzleFlashParams.bFirstPerson = nil;
						MuzzleFlashParams.MuzzleFlash = CurFireParams.MuzzleFlash;
						if (stats.first_person) then
							MuzzleFlashParams.bFirstPerson = 1;
							else
							if (CurFireParams.MuzzleFlashTPV) then
									MuzzleFlashParams.MuzzleFlash = CurFireParams.MuzzleFlashTPV;
							end
						end
						BasicWeapon.ShowMuzzleFlash( self,MuzzleFlashParams,1 );
					end
					
-------------------------^end^-------------------------			

				end	
				if(CurFireParams.ExitSmoke) then
					Particle:CreateParticle( fire_pos, basic_weapon.normal_000, CurFireParams.ExitSmoke );
				end	
			end
		end

		-- Shell Cases
		if (CurFireParams.ShellCases) then
			if (CurFireParams.ShellCases.geometry) then
				local bFirstPerson = 0;
				if (shooter == my_player) then
					if (shooter.cnt.first_person and shooter.cnt.weaponid > -1) then
			    			bFirstPerson = 1;
			   		end
				end

				local ShellCaseExitPt;
				
				if (bFirstPerson == 1) then
					if(stats.lock_weapon) then	-- mounted weapon - just get helper
						ShellCaseExitPt = stats:GetTPVHelper(0, "shells");
					else	
						ShellCaseExitPt = self.cnt:GetBonePos("shells");
					end	
				else
--					if(stats.lock_weapon) then	-- mounted weapon - just get helper
--						ShellCaseExitPt = self:GetHelperPos("shells");
--					else	
						ShellCaseExitPt = stats:GetTPVHelper(0, "shells");
--					end
				end

				if (ShellCaseExitPt and CurFireParams.ShellCases) then
					CurFireParams.ShellCases.init_angles = Params.angles;
--					CurFireParams.ShellCases.speed = 2;
					local vDirection = basic_weapon.temp_dir;
					vDirection.x = Params.dir.y;
					vDirection.y = -Params.dir.x;
					vDirection.z = 0;
					Particle:CreateParticle(ShellCaseExitPt, vDirection, CurFireParams.ShellCases);
--					Particle:CreateParticle(ShellCaseExitPt, basic_weapon.normal_101, CurFireParams.ShellCases);
				else
					System:Log("ERROR: Shells / Bone missing, artists fix !");
				end
			else
				System:Log("ERROR: No CGF File Specified For Shell Case Particle System !");
			end
		end
	end
	
	-- create bullet-drop-sound
--	if (shooter and (shooter==_localplayer) and CurFireParams.BulletRejectType and (CurFireParams.BulletRejectType~=BULLET_REJECT_TYPE_NONE)) then
--		if (CurFireParams.BulletRejectType==BULLET_REJECT_TYPE_SINGLE) then
--			BasicWeapon.PlayShellsEjectionSound(self,shooter,"bullet_drop_single");			
--		end
--	end

	-- Spawn a trace of bubbles when underwater	
	if(shooter.cnt.underwater~=0)then		
		--ONLY IF IS UNDERWATER
		local vCurPosOnTrace=basic_weapon.temp_pos
		local vStep = Params.dir;
		CopyVector(vCurPosOnTrace,Params.pos);
		ScaleVector(vStep, 3);
		for i=0, 50 do
			FastSumVectors(vCurPosOnTrace,vCurPosOnTrace, vStep);
			if (Game:IsPointInWater(vCurPosOnTrace) == nil) then break;	end
			Particle:CreateParticle(vCurPosOnTrace, basic_weapon.normal_001, basic_weapon.UnderwaterBubbles);
		end
	else
		--ONLY IF IS NOT UNDERWATER

		if (CurFireParams.LightFlash) then
			-- vPos, fRadius, DiffR, DiffG, DiffB, DiffA, SpecR, SpecG, SpecB, SpecA, fLifeTime
			local diff=CurFireParams.LightFlash.vDiffRGBA;
			local spec=CurFireParams.LightFlash.vSpecRGBA;
			self:AddDynamicLight(fire_pos,CurFireParams.LightFlash.fRadius,diff.r,diff.g,diff.b,diff.a,spec.r,spec.g,spec.b,spec.a,
				CurFireParams.LightFlash.fLifetime);
		end
		
		if (Params.BulletPlayerPos and CurFireParams.whizz_sound) then
			local bSkip=0;
			if (CurFireParams.whizz_probability) then
				if (random(0, 1000)>CurFireParams.whizz_probability) then
					bSkip=1;
				end
			end
			if (bSkip==0) then
				local pWhizzSound=CurFireParams.whizz_sound[random(1, getn(CurFireParams.whizz_sound))];
				if (pWhizzSound) then
					Sound:SetSoundPosition(pWhizzSound, Params.BulletPlayerPos);
					Sound:PlaySound(pWhizzSound);
				end
			end
		end
	end
	ReturnVal = 1;
	
	if (self.DoesFTBSniping and (shooter==_localplayer)) then
		FTBSniping.OnFire(FTBSniping);
	end
	return ReturnVal;
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_OnHit( hit )
	if (hit.target_material) then
		if (hit.target_material.AI) then
			AI:FreeSignal(1,"OnBulletRain",hit.pos, hit.target_material.AI.fImpactRadius);	
		else
			System:LogToConsole("\003 [MATERIAL ERROR] Hit material that has no AI properties (for BulletRain) (please add in the material .lua file!)");
		end
	else
		System:LogToConsole("\003 [MATERIAL ERROR] Registered hit but could not retrieve material.");
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnHit( hit )
	if(hit.shooter==_localplayer)then
		if(hit.target and (hit.target.type=="Player"))then
			Hud.hit=5;
		end
	end

	local effect="bullet_hit";
	
	if(hit.shooter and hit.shooter.fireparams.mat_effect)then
		effect=hit.shooter.fireparams.mat_effect;
		--System:Log("custom EFFECT!!!! "..effect);
	end
	if (hit.target_material) then
		ExecuteMaterial2( hit ,effect);
	end
	
	-- [marco] I've removed this 'cos it's completely broken anyway		
	--if (hit.target and hit.target.type~="Player") then
	--	System:Log("Adding impulse"..hit.target.type);
	--	if(hit.target.bNoImpulse == nil ) then
	--		hit.target:AddImpulse( -1, hit.pos, hit.dir, hit.impact_force_mul );
	--	end	
	--else
		--System:Log("failed "..type(hit.target));
	--end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_OnEvent( EventId, Params )
	local EventSwitch=BasicWeapon.Server_EventHandler[EventId];
	if(EventSwitch)then
		return EventSwitch(self,Params);
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnEvent( EventId, Params )
	local EventSwitch=BasicWeapon.Client_EventHandler[EventId];
	if(EventSwitch)then
		return EventSwitch(self,Params);
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
function BasicWeapon:Server_OnTimer( timerId )
	-- Lets just assume we are supposed to throw a grenade
	local Grenade = Server:SpawnEntity("ProjFlashbangGrenade");
	--weapon, shooter, pos, angles, dir
	Grenade:Launch(Grenade, self, self.GrenadeThrowParam.shooter, self.GrenadeThrowParam.pos, self.GrenadeThrowParam.angles, self.GrenadeThrowParam.dir);
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


--NEW MUZZLE FLASH ATTACHMENT SYSTEM //TIMUR&MAX	----------------------------------------------------------------------------------------------------------------------------------	
-- MuzzleFlashTimer turn off timer callback.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
MuzzleFlashTurnoffCallback =
{
	OnEvent = function( self,event,Params )
		BasicWeapon.ShowMuzzleFlash( Params.weapon,Params,0 );
	end
}

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
function BasicWeapon:ShowMuzzleFlash( MuzzleFlashParams,bEnable )
	local geomName = "Objects\\Weapons\\MUZZLEFLASH\\muzzleflash.cgf";
	local boneName;
	local lifetime = 10;
	
	if (MuzzleFlashParams.bFirstPerson) then
		boneName = "spitfire";
	else
		boneName = "weapon_bone";
	end

	if (MuzzleFlashParams.MuzzleFlash.geometry_name) then
		geomName = MuzzleFlashParams.MuzzleFlash.geometry_name;
	end
	-- Life time must be in seconds.
	if (MuzzleFlashParams.MuzzleFlash.lifetime) then
		lifetime = MuzzleFlashParams.MuzzleFlash.lifetime * 1000;
	end
	if (MuzzleFlashParams.MuzzleFlash.bone_name) then
		boneName = MuzzleFlashParams.MuzzleFlash.bone_name;
	end
	
	local target;
	if (MuzzleFlashParams.bFirstPerson) then
		target = MuzzleFlashParams.weapon;
	else
		target = MuzzleFlashParams.shooter;
	end
	
	if (bEnable == 1) then
		target:LoadObject( geomName,2,1 );
		MuzzleFlashParams.bind_handle = target:AttachObjectToBone( 2, boneName,1 );
	else
		if (MuzzleFlashParams.bind_handle) then
			target:DetachObjectToBone( boneName,MuzzleFlashParams.bind_handle );
		end
	end
	
	if (bEnable == 1) then
		-- This will result in a call to BasicWeapon:Client_TimerEvent
		Game:SetTimer( MuzzleFlashTurnoffCallback,lifetime,MuzzleFlashParams );
	end
end

-------------------^end^-------------------------------------------------------

function BasicWeapon:Server_FireModeChange(params)
	-- Did we get the owner passed ?
	if (type(params) == "table" and params.shooter) then
		local shooter = params.shooter;
		if (shooter.cnt.reloading == nil) then
			-- Abort any reloading sequence
			shooter.cnt.reloading = nil;
			local switchclip=1;
			if(shooter.fireparams.AmmoType==shooter.cnt.weapon.FireParams[params.firemode+1].AmmoType)then
				switchclip=nil;
			end
			-- Make sure we can't fire etc. as long as we are changing
			shooter.cnt.weapon_busy=self:GetAnimationLength("Activate"..shooter.firemodenum)
			--
			if(switchclip)then
				shooter.Ammo[shooter.fireparams.AmmoType]=shooter.cnt.ammo;
				shooter.weapon_info.AmmoInClip[shooter.firemodenum]=shooter.cnt.ammo_in_clip;
			end
			--
			shooter.weapon_busy= shooter.fireparams.FModeActivationTime;
			shooter.weapon_info.FireMode=params.firemode;
			BasicWeapon.SyncVarCache(self,shooter);
			--
			if(switchclip)then
				shooter.cnt.ammo = shooter.Ammo[shooter.fireparams.AmmoType];
				shooter.cnt.ammo_in_clip = shooter.weapon_info.AmmoInClip[shooter.firemodenum];
			end
			return 1
		end
	end
	return nil
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_FireModeChange(Params)
	-- Did we get the owner passed ?
	if (type(Params) == "table" and Params.shooter) then
		local shooter = Params.shooter;
		if (shooter.cnt.reloading == nil) then	
			BasicWeapon.SyncVarCache(self,shooter);
			-- Abort any reloading sequence and animation
			self:StartAnimation(0, "Default", 0, 0);
			self:ResetAnimation(0);
			-- Start activation animation for this firemode
			BasicWeapon.RandomAnimation(self,"modeactivate",shooter.firemodenum);
			-- Make sure we can't fire etc. as long as we are changing
			return 1
		end
	end
	return nil
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:DrawCrosshair(r,g,b,accuracy,wmin,wmax)
	
	if((not wmin) or (not wmax))then wmin=0; wmax=0; end
	
	--waccuacy=(((1-wmax)*10)-((1-wmin)*10))*accuracy;
	
	local diff=( ((1-(wmax-wmin))*20) )*accuracy;
	
	local shift=floor( (diff) + ((1-wmax)*10) );

	local xcent=400;
	local ycent=300;

	--local myplayer = _localplayer;
	--if (myplayer and myplayer.cnt.first_person==nil) then
	--	local hit_pt=myplayer.cnt:GetViewIntersection();
	--	if (hit_pt) then		
	--		xcent=hit_pt.winx;
	--		ycent=hit_pt.winy;
	--	end
	--end

	%System:Draw2DLine(xcent-7-shift,ycent,xcent-2-shift,ycent,r,g,b,1);
	%System:Draw2DLine(xcent+2+shift,ycent,xcent+7+shift,ycent,r,g,b,1);
	%System:Draw2DLine(xcent,ycent-2-shift,xcent,ycent-7-shift,r,g,b,1);
	%System:Draw2DLine(xcent,ycent+2+shift,xcent,ycent+7+shift,r,g,b,1);
	
	--waccuacy=(1-waccuacy)*10;
	--local shift=floor((((accuracy+0.1)*10)+waccuacy)*2);

	--local xcent=400;
	--local ycent=300;

	--local myplayer = _localplayer;
	--if (myplayer and myplayer.cnt.first_person==nil) then
	--	local hit_pt=myplayer.cnt:GetViewIntersection();
	--	if (hit_pt) then		
	--		xcent=hit_pt.winx;
	--		ycent=hit_pt.winy;
	--	end
	--end

	--%System:Draw2DLine(xcent-7-shift,ycent,xcent-2-shift,ycent,r,g,b,1);
	--%System:Draw2DLine(xcent+2+shift,ycent,xcent+7+shift,ycent,r,g,b,1);
	--%System:Draw2DLine(xcent,ycent-2-shift,xcent,ycent-7-shift,r,g,b,1);
	--%System:Draw2DLine(xcent,ycent+2+shift,xcent,ycent+7+shift,r,g,b,1);
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnEnhanceHUD(bhit)
	local myplayer = _localplayer;
	if (myplayer) then
		if (myplayer.cnt.first_person and myplayer.fireparams.HasCrosshair) then
			if ((not ClientStuff.vlayers:IsActive("Binoculars")) and ((not ClientStuff.vlayers:IsActive("WeaponScope")) or (self.AimMode))) then
				if(bhit and bhit>0)then
					BasicWeapon.DrawCrosshair(self,1,0,0,myplayer.cnt.accuracy,myplayer.fireparams.min_accuracy,myplayer.fireparams.max_accuracy);
				else
					BasicWeapon.DrawCrosshair(self,1,1,0,myplayer.cnt.accuracy,myplayer.fireparams.min_accuracy,myplayer.fireparams.max_accuracy);
				end
			end
		end
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_OnActivate(Params)
	-- Set player-related stuff...
	local shooter = Params.shooter;
	if (shooter) then
		local stats = shooter.cnt;
		local AmmoType;
		shooter.weapon_info=GetPlayerWeaponInfo(shooter);
		if( shooter.weapon_info) then
			BasicWeapon.SyncVarCache(self,shooter);
			AmmoType = shooter.fireparams.AmmoType;
			stats.ammo = shooter.Ammo[AmmoType];
			stats.ammo_in_clip = shooter.weapon_info.AmmoInClip[shooter.firemodenum];
			stats.weapon_busy=self:GetAnimationLength("Activate"..shooter.firemodenum)
		end
		self.OldSpeedScale = stats.speedscale;
		stats.speedscale = self.PlayerSlowDown;
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnActivate(Params)
	-- set player-related stuff...
	local shooter = Params.shooter;
	if (shooter) then
		local stats = shooter.cnt;
		
		shooter.weapon_info=GetPlayerWeaponInfo(shooter);
		if (shooter.weapon_info ~= nil) then
			BasicWeapon.SyncVarCache(self,shooter);
		end

		if (shooter == _localplayer) then
			if (self.ActivateSound) then
				shooter.cnt:PlaySound( self.ActivateSound );
			end
			if (shooter.firemodenum ~= nil) then
				BasicWeapon.RandomAnimation(self,"activate",shooter.firemodenum);
			end
		end
		BasicWeapon.Show(self,shooter);
		self.OldSpeedScale = stats.speedscale;
		stats.speedscale = self.PlayerSlowDown;
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_OnDeactivate(Params)
	-- Did we get the owner passed ?
	if (Params.shooter) then
		-- Abort any reloading sequence
		local shooter=Params.shooter;
		shooter.cnt.reloading = nil;
		shooter.Ammo[shooter.fireparams.AmmoType]=shooter.cnt.ammo;
		shooter.weapon_info.AmmoInClip[shooter.firemodenum]=shooter.cnt.ammo_in_clip;
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_OnDeactivate(Params)
	-- Did we get the owner passed ?
	if (type(Params) == "table" and Params.shooter) then
		-- Stop firing loop and play trailoff when using that particular
		local shooter = Params.shooter;
		if (shooter == _localplayer) then
			-- Hide the weapon
			BasicWeapon.Hide(self,shooter);
			ClientStuff.vlayers:DeactivateLayer("WeaponScope");
			self:ResetAnimation(0);
		end
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_Drop( Params )
	if( not Params.Player.cnt.weapon) then return end
	local player=Params.Player;
	local weapon=player.cnt.weapon;
	local cid=Game:GetEntityClassIDByClassName("Pickup"..weapon.classname);
	if(cid)then
		local ammo_in_clip=player.cnt.ammo_in_clip;
		player.Ammo[player.fireparams.AmmoType]=player.cnt.ammo;
		player.cnt.ammo_in_clip=0;
		
		local Offset = SumVectors(player:GetPos(),{x=0.0,y=0.0,z=1.5});
		local Direction = player:GetDirectionVector();
		
		Direction.z = 0.0;
		--DroppedItem:SetPos(SumVectors(Offset, ScaleVector(Direction, 1.5)));
		
		local ed={
			classid=cid,
			pos=SumVectors(Offset, ScaleVector(Direction, 1.5)),
		}
		-- Create the dropped item
		local DroppedItem = Server:SpawnEntity(ed);
		-- Set the start position, which is offset from the players position
		player.cnt:MakeWeaponAvailable(self.classid,0);
		DroppedItem.autodelete=1;
		
		DroppedItem.Properties.Amount=ammo_in_clip;
		
		player.cnt:SelectFirstWeapon();
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_WeaponReady(shooter)
	if(shooter.cnt.reloading)then
		local fireparams = shooter.fireparams;
		local Ammo = shooter.cnt.ammo;
		local stats = shooter.cnt;
		-- Finished
		stats.reloading = nil;
		-- Obtain fire params to get ammo type and clip size
		if (Ammo >= fireparams.bullets_per_clip) then
			-- Got enough ammo left to fill a clip
			stats.ammo = stats.ammo - fireparams.bullets_per_clip;
			stats.ammo_in_clip = fireparams.bullets_per_clip;
		elseif (Ammo > 0) then
			-- Partially fill the clip
			stats.ammo_in_clip = Ammo;
			stats.ammo = 0;
		end
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Server_Reload(shooter)
	if (not shooter.cnt.reloading ) then
		local w=shooter.cnt.weapon;
		if (w and shooter.fireparams and shooter.cnt.ammo_in_clip < shooter.fireparams.bullets_per_clip and (shooter.cnt.ammo > 0 or shooter.fireparams.AmmoType == "Unlimited")) then
			shooter.cnt.weapon_busy=w.FireParams[shooter.firemodenum].reload_time
			-- In the case of a partial reload, put all remaining ammo from the clip into the ammo pool
			if (shooter.cnt.ammo > 0) then
				shooter.cnt.ammo = shooter.cnt.ammo + shooter.cnt.ammo_in_clip;
				shooter.cnt.ammo_in_clip = 0;
			end
			shooter.cnt.reloading=1
			shooter.reload_started=_time;	-- fix 13: this reload started now (Client_Reload plays it only once)
			AI:Signal(0,1,"OnReload",shooter.id);
		end
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:Client_Reload(shooter )
	local ReloadAnimName = "Reload"..(shooter.firemodenum);
	if (shooter.cnt.reloading and shooter.reload_started ~= _time) then return end	-- fix 13: no second reload animation while reloading (the clip is 0 then)
	if (shooter.fireparams and shooter.cnt.ammo_in_clip < shooter.fireparams.bullets_per_clip and (shooter.cnt.ammo > 0 or shooter.fireparams.AmmoType == "Unlimited")) then
	if (shooter == _localplayer) then
		if(ClientStuff.vlayers:IsActive("WeaponScope"))then
			ClientStuff.vlayers:DeactivateLayer("WeaponScope",1);
		end
		BasicWeapon.RandomAnimation(self,"reload",shooter.firemodenum);
	else
		shooter:StartAnimation(0,"reload",4);
	end
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function BasicWeapon:StopFireLoop(shooter, fireparams, sound_data)
	local sound=Sound;
	if (sound:IsPlaying(sound_data.FireLoop)) then
		sound:StopSound(sound_data.FireLoop);
		shooter.cnt:PlaySound(sound_data.TrailOff);
		if (fireparams) then
			sound:SetSoundVolume(sound_data.TrailOff,fireparams.SoundMinMaxVol[1]);
			sound:SetMinMaxDistance(sound_data.TrailOff,fireparams.SoundMinMaxVol[2],fireparams.SoundMinMaxVol[3]);
		end
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BasicWeapon.Server = {
	OnInit = BasicWeapon.Server_OnInit,
	OnFire = BasicWeapon.Server_OnFire,
	OnHit = BasicWeapon.Server_OnHit,
	OnEvent = BasicWeapon.Server_OnEvent,
	FireModeChange = BasicWeapon.Server_FireModeChange,
	OnEnhanceHUD = BasicWeapon.Server_OnEnhanceHUD,
	OnSave = BasicWeapon.Server_OnSave,
	OnLoad = BasicWeapon.Server_OnLoad,
	OnActivate = BasicWeapon.Server_OnActivate,
	OnDeactivate = BasicWeapon.Server_OnDeactivate,
	Drop = BasicWeapon.Server_Drop,
}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BasicWeapon.Client = {
	OnInit = BasicWeapon.Client_OnInit,
	OnUpdate = BasicWeapon.Client_OnUpdate,
	OnFire = BasicWeapon.Client_OnFire,
	OnHit = BasicWeapon.Client_OnHit,
	OnEvent = BasicWeapon.Client_OnEvent,
	FireModeChange = BasicWeapon.Client_FireModeChange,
	OnEnhanceHUD = BasicWeapon.Client_OnEnhanceHUD,
	OnSave = BasicWeapon.Client_OnSave,
	OnLoad = BasicWeapon.Client_OnLoad,
	OnActivate = BasicWeapon.Client_OnActivate,
	OnDeactivate = BasicWeapon.Client_OnDeactivate,
	Drop = BasicWeapon.Client_Drop,
}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BasicWeapon.Server_EventHandler={
	[ScriptEvent_Activate]=BasicWeapon.Server_OnActivate,
	[ScriptEvent_Deactivate]=BasicWeapon.Server_OnDeactivate,
	[ScriptEvent_DropItem]=BasicWeapon.Server_Drop,
	[ScriptEvent_FireModeChange]=BasicWeapon.Server_FireModeChange,
	[ScriptEvent_WeaponReady]=BasicWeapon.Server_WeaponReady,
	[ScriptEvent_Hit]=BasicWeapon.Server_OnHit,
	[ScriptEvent_Fire]=BasicWeapon.Server_OnFire,
	[ScriptEvent_FireCancel]=BasicWeapon.Server_OnFireCancel,
	[ScriptEvent_Reload]=BasicWeapon.Server_Reload,
}
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BasicWeapon.Client_EventHandler={
	[ScriptEvent_AnimationKey]=function(self,Params)
		if (Params.userdata) then
			Sound:PlaySound(Params.userdata);
		end
	end,
	[ScriptEvent_Activate]=BasicWeapon.Client_OnActivate,
	[ScriptEvent_Deactivate]=BasicWeapon.Client_OnDeactivate,
	[ScriptEvent_FireModeChange]=BasicWeapon.Client_FireModeChange,
	[ScriptEvent_Hit]=BasicWeapon.Client_OnHit,
	[ScriptEvent_Fire]=BasicWeapon.Client_OnFire,
	[ScriptEvent_StopFiring]=BasicWeapon.Client_OnStopFiring,
	[ScriptEvent_FireCancel]=BasicWeapon.Client_OnFireCancel,
	[ScriptEvent_ViewModeChange]=BasicWeapon.Client_OnViewModeChange,
	[ScriptEvent_Reload]=BasicWeapon.Client_Reload,
}


function BasicWeapon:RandomAnimation(anim,firemode)
	if(self.anim_table)then
		local at=self.anim_table[firemode]
		if(at)then
			local t=at[anim];
			if(t)then
				self:StartAnimation(0,t[random(1,getn(t))],0,0);
			--else
			--	System:Log("BasicWeapon:RandomAnimation("..anim..","..firemode..") NO ANIM");
			end
		--else
		--	System:Log("BasicWeapon:RandomAnimation("..anim..","..firemode..") NO ANIM TABLE");
		end
	--else
	--	System:Log("BasicWeapon:RandomAnimation("..anim..","..firemode..") self.anim_table is nil");
	end
end