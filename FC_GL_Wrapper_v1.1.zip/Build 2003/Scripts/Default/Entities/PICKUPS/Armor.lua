Script:LoadScript("scripts/default/entities/pickups/basepickup.lua");

local funcPick=function (self,collider)

	--self:NotifyMessage("collider.cnt.armor="..collider.cnt.armor..", collider.cnt.max_armor="..collider.cnt.max_armor);

	if(collider.cnt.armor>=collider.cnt.max_armor)then
		Hud.cannot_pickup=1;
		return nil;
	end	

	collider.cnt.armor = collider.cnt.armor + self.Properties.Amount;
	-- fix 12: the original compared armor with itself, so armor went over max_armor (e.g. 95 + 15 = 110); with armor
	-- over 100 the damage of GameRules:OnDamage turns negative - the player is invulnerable and armor keeps growing
	if(collider.cnt.max_armor and collider.cnt.armor>collider.cnt.max_armor)then
		collider.cnt.armor=collider.cnt.max_armor;
	end
	self:NotifyMessage("You picked up "..self.Properties.Amount.." unit of armor")
	
	return 1;
		
end

local params={
	func=funcPick,
	model="Objects/pickups/armor/bodyarmor.cgf",
	default_amount=15,
	sound="sounds/items/health.wav",
	modelchoosable=nil,
	soundchoosable=nil,
	floating_icon="Objects/Pickups/armor/armor_icon.cga"
}

Armor=CreateCustomPickup(params);
