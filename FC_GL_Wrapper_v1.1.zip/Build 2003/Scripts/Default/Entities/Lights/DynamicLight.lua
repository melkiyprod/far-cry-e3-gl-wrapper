DynamicLight = 
{
	Properties=
	{
		bActive=1, 
		lighttype=0,		
		-- 0=normal light without object,
		-- 1=normal light with object,
		-- 2=industrial light with ropes		
		-- 3=swinglight
--		bCastShadows=0,
        bProjectInAllDirs=0,
        AnimationSpeed=0,

--		vector_RndPos = {x=0.0,y=0.0,z=0.0},
--		vector_LightDir = {x=0.0,y=0.0,z=0.0},
		vector_LightDir = {x=0.0,y=90.0,z=0.0},		
		RndPosFreq=0.5,

		OuterRadius=5,			

		clrDiffuse={1, 1, 1},
		DiffuseMultiplier=1,

		clrSpecular={1, 1, 1},
		SpecularMultiplier=1,

		weight = 5,

		fileModel01="Objects/Editor/invisiblebox.cgf",
		fileModel2="Objects/glm/ww2_indust_set1/lights/LIGHT_INDUST2/light_indust2.cgf",
		fileModel3="Objects/Indoor/lights/light6phys.cgf",
		AnimName="default", 
		bUseAnimation=1,
		ProjectorFov=90,
		texture_ProjectorTexture="",
		shader_lightShader="",
		bAffectsThisAreaOnly=1,
		shakeAmount=100,
		shakeRefreshTime=0,
		bUsedInRealTime=1,
		bFakeLight=0,
		bHeatSource=0,
	},

	TempPos = {x=0.0,y=0.0,z=0.0},

	Editor=
	{
		Model="Objects/Editor/LightSphear.cgf",
	},

}

function DynamicLight:OnReset()
	self:NetPresent(nil);
	self:EnableUpdate(1);
	--self.active=self.Properties.bActive;	
	
	if (self.Properties.lighttype == 0) then
		self:LoadObject( self.Properties.fileModel01, 0,0);
		self:DrawObject( 0,0 );
	elseif (self.Properties.lighttype == 1) then
		self:LoadObject( self.Properties.fileModel01, 0,0);
		self:DrawObject( 0,1 );
	else
		self:CreateRigidBody(0,1,0);
		local RopeParams = {
			entity_id = -1,
		  entity_part_id = 0,
		};

		if (self.Properties.lighttype == 2) then
			self:LoadCharacter(self.Properties.fileModel2,0);

			self:PhysicalizeCharacter(self.Properties.weight,0,0,0);
			self:SetCharacterPhysicParams(0,"rope1", PHYSICPARAM_ROPE,RopeParams);
			self:SetCharacterPhysicParams(0,"rope2", PHYSICPARAM_ROPE,RopeParams);
		else
			self:LoadCharacter(self.Properties.fileModel3,0);

			self:PhysicalizeCharacter(self.Properties.weight,0,0,0);
			self:SetCharacterPhysicParams(0,"rope", PHYSICPARAM_ROPE,RopeParams);
		end

		self:DrawObject(0, 1);
	end

	self:SetRadius(0);

	self.proj_tex_id = System:LoadTexture(self.Properties.texture_ProjectorTexture,1);
	
	self:InitDynamicLight(self.Properties.texture_ProjectorTexture, self.Properties.shader_lightShader, 
		self.Properties.bProjectInAllDirs, self.Properties.AnimationSpeed);
	
	if (self.Properties.shakeRefreshTime>0) then
		self:SetTimer(self.Properties.shakeRefreshTime);
	end
end

function DynamicLight:OnPropertyChange()
	self:OnReset();
end

function DynamicLight:OnDamage( hit )

	--System:LogToConsole("dir="..hit.dir.x..","..hit.dir.y..","..hit.dir.z);
	--System:LogToConsole("pos="..hit.pos.x..","..hit.pos.y..","..hit.pos.z);
	--System:LogToConsole("impact_force="..hit.impact_force_mul);

	if( hit.ipart ) then
		self:AddImpulse( hit.ipart, hit.pos, hit.dir, hit.impact_force_mul );
	else	
		self:AddImpulse( -1, hit.pos, hit.dir, hit.impact_force_mul );
	end	
end

function DynamicLight:OnSave(stm)
	--WriteToStream(stm,self.Properties);
	--stm.WriteInt(self.Properties.bActive);
end

function DynamicLight:OnLoad(stm)
	--self.Properties=ReadFromStream(stm);
	self:OnReset();
	--self.Properties.bActive=stm.ReadInt();
end

function DynamicLight:OnInit()
	self:EnableUpdate(1);
	-- game fix (MelkiyProd): no 'update only if potentially visible' - a light bound to an object (green sticks)
	-- gets its world position only in its own update; before that it sits at its local coordinates near the
	-- map origin, is never 'visible' there, is never updated and never moves to the object.
	-- self:SetUpdateIfPotentiallyVisible(1);
	--self.Pos=self:GetPos();
	self:OnReset();
end

function DynamicLight:OnTimer()
	self:Event_Shake();

	-- this check is needed because in the editor the
	-- shaking time can be set to 0 (no shake) while the light
	-- is still shaking...
	if (self.Properties.shakeRefreshTime>0) then
		self:SetTimer(self.Properties.shakeRefreshTime*1000);
	end
end


function DynamicLight:OnUpdate( DeltaTime )

	if (self.Properties.bActive == 0) then
		return
	end

	local Dir;
	local diffR = self.Properties.clrDiffuse[1];
	local diffG = self.Properties.clrDiffuse[2];
	local diffB = self.Properties.clrDiffuse[3];
	local specR = self.Properties.clrSpecular[1];
	local specG = self.Properties.clrSpecular[2];
	local specB = self.Properties.clrSpecular[3];
	local orad = self.Properties.OuterRadius;

	local pos=new(self:GetPos());

	self.TempPos=pos;

	if (self.Properties.lighttype>1) then		
--		self.TempPos=self:GetBonePos("lamp");
--	elseif (self.Properties.lighttype==3) then		
		self.TempPos=self:GetBonePos("LightBone");
	end	

	
--!-------------------------------


	Dir=self:GetAngles();
	Dir.x=Dir.x+self.Properties.vector_LightDir.x;
	Dir.y=Dir.y+self.Properties.vector_LightDir.y;
	Dir.z=Dir.z+self.Properties.vector_LightDir.z;


	self:AddDynamicLight(self.TempPos,
				orad, 
				diffR*self.Properties.DiffuseMultiplier, 
				diffG*self.Properties.DiffuseMultiplier, 
				diffB*self.Properties.DiffuseMultiplier,
				1,
				specR*self.Properties.SpecularMultiplier, 
				specG*self.Properties.SpecularMultiplier, 
				specB*self.Properties.SpecularMultiplier,
				1,
				0,
				0, -- not used
				Dir,
				self.Properties.ProjectorFov,
				self.proj_tex_id,
				self.Properties.bAffectsThisAreaOnly,
				self.Properties.bUsedInRealTime,
				self.Properties.bHeatSource, 
				self.Properties.bFakeLight );
end



function DynamicLight:Event_Enable()
	self.Properties.bActive=1;
	AI:FreeSignal(1,"LIGHTS_ON",self:GetPos(),10);
end

function DynamicLight:Event_Disable()
	self.Properties.bActive=0;
	AI:FreeSignal(1,"LIGHTS_OFF",self:GetPos(),10);
end

function DynamicLight:Event_Shake()
	local hit={};	
	hit.pos=self:GetPos();
	hit.dir={x=0.9,y=0.2,z=0.2};
	hit.impact_force_mul=self.Properties.shakeAmount;
	self:OnDamage(hit);
end

function DynamicLight:OnShutDown()
end

function DynamicLight:OnWrite( stm )
end

function DynamicLight:OnRead( stm )
end

function DynamicLight:OnSave( stm )
end

function DynamicLight:OnLoad( stm )
end 