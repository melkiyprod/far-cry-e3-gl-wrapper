
-- simple entity

BasicEntity = {
	Name = "BasicEntity",
	Properties = {
		object_Model = "",

		Physics = {
			bRigidBody=0, -- True if rigid body.
			bRigidBodyActive = 1, -- If rigid body is originally created (1) OR will be created only on OnActivate (0).
			bActivateOnDamage = 0, -- Activate when a rocket hit the entity.
			bResting = 0, -- If rigid body is originally in resting state.
			Density = -1,
			Mass = 700,
			vector_Impulse = {x=1,y=2,z=3}, -- Impulse to apply at event.
			max_time_step = 0.01,
			sleep_speed = 0.04,
			damping = 0,
			water_damping = 1.5,
			water_resistance = 0,	
		},

		Animation = {
			Animation = "Default",
			Speed=1,
			bLoop=0,
			bPlaying=0,
		},

		ImpactSound = {
			sndFilename="",			
			InnerRadius = 1,
			OuterRadius = 100,
			nVolume=255,
		},
		damage_players=0,
	},
	temp_vec={x=0,y=0,z=0},
}

------------------------------------------------------------------------------------------------------
function BasicEntity:SetFromProperties()
	if (self.Properties.object_Model == "") then
		do return end;
	end
	local bPhysicalize = 1;
	if (self.ModelName ~= self.Properties.object_Model) then
		self.ModelName = self.Properties.object_Model;
		--bPhysicalize = 1;
		
		-- try to load an animated model first
		if (self:LoadCharacter(self.ModelName,0)==1) then
			self.bCharacter = 1;
			self:DrawCharacter(0,1);
		else
			-- let's create either a rigid body or a normal static object
			self:LoadObject( self.ModelName,0,1 );
			self.bCharacter = 0;
			self:DrawObject(0,1); --param nPos(slot number), nMode(0 = Don't draw, 1 = Draw normally, 3 = Draw near)
			System:LogToConsole( "Object Loaded" );
		end
	end
	
	if (self.Properties.Animation.bPlaying ~= self.bAnimPlaying or self.Properties.Animation.bLoop ~= self.bAnimLoop or 
			self.Properties.Animation.Animation ~= self.AnimName) then
		self.bAnimPlaying = self.Properties.Animation.bPlaying;
		self.bAnimLoop = self.Properties.Animation.bLoop;
		self.AnimName = self.Properties.Animation.Animation;
		if (self.Properties.Animation.bPlaying == 1) then
			self:StartAnimation( 0,self.Properties.Animation.Animation,0,0,1,self.Properties.Animation.bLoop );
		else
			self:ResetAnimation(0);
		end
	end
	self:SetAnimationSpeed( self.Properties.Animation.Speed )
	
	-- Set physics.
	if (self.Properties.Physics.bRigidBody == 1 and self.Properties.Physics.bRigidBodyActive == 0) then
		-- Not physicalize.
	else
		self:SetPhysicsProperties( bPhysicalize );
	end

	--self:EnablePhysics(1);

	
	self:SetSoundProperties();
end

------------------------------------------------------------------------------------------------------
function BasicEntity:SetSoundProperties()
	-- load sounds
	local SndTbl;
	SndTbl=self.Properties.ImpactSound;

	if (SndTbl.sndFilename~="") then
		self.ImpactSound=Sound:Load3DSound(SndTbl.sndFilename, 0);
		if (self.ImpactSound) then
			Sound:SetSoundPosition(self.ImpactSound, self:GetPos());
			Sound:SetSoundLoop(self.ImpactSound, 0);
			Sound:SetSoundVolume(self.ImpactSound, SndTbl.nVolume);
			Sound:SetMinMaxDistance(self.ImpactSound, SndTbl.InnerRadius, SndTbl.OuterRadius);
			--Sound:SetSoundPitching(self.ImpactSound,100);
			self.LastSpeed=0.0;
			self.LastFrequency=100.0;
			self.LastImpact=0;
		end
	end
end

------------------------------------------------------------------------------------------------------
-- Set Physics parameters.
------------------------------------------------------------------------------------------------------
function BasicEntity:SetPhysicsProperties( bPhysicalize )
	if (self.Properties.Physics.bRigidBody == 1) then
		-- Make Rigid body.
		if (bPhysicalize==1) then
			self:CreateRigidBody( self.Properties.Physics.Density,self.Properties.Physics.Mass,-1 );
			if (self.bCharacter == 1) then
				self:PhysicalizeCharacter( self.Properties.Physics.Mass,0,0,0);
			end
		end

		if (self.Properties.Physics.bResting == 0) then
			self:AwakePhysics(1);
		else
			self:AwakePhysics(0);
		end
		
		local SimParams = {
			max_time_step = self.Properties.Physics.max_time_step,
			sleep_speed = self.Properties.Physics.sleep_speed,
			damping = self.Properties.Physics.damping,
			water_damping = self.Properties.Physics.water_damping,
			water_resistance = self.Properties.Physics.water_resistance,
			mass = self.Properties.Physics.Mass,
			density = self.Properties.Physics.Density
		};
		self:SetPhysicParams(PHYSICPARAM_SIMULATION, SimParams );
		self:SetPhysicParams(PHYSICPARAM_BUOYANCY, self.Properties.Physics );
		
	else
		-- Not rigid body, not character.
		-- Make simple static physics.
		if (bPhysicalize == 1) then
			self:CreateStaticEntity( self.Properties.Physics.Mass,-1 );
			if (self.bCharacter == 1) then
				self:PhysicalizeCharacter( self.Properties.Physics.Mass,0,0,0);
			end
		end
	end
end

------------------------------------------------------------------------------------------------------
function BasicEntity:OnReset()
	if (self.Properties.Physics.bRigidBody == 1) then
		if (self.Properties.Physics.bResting == 0) then
			self:AwakePhysics(1);
		else
			self:AwakePhysics(0);
		end
	end
end

------------------------------------------------------------------------------------------------------
function BasicEntity:OnInit()
	self:NetPresent(nil);
	self:SetFromProperties();	
	-- game fix (MelkiyProd): objects with bound children (green light sticks with their DynamicLight) must be
	-- updated, otherwise a resting object never passes its position to the children and the bound light
	-- stays at its local coordinates near the map origin (lights only on loads where physics woke the object).
	self:EnableUpdate(1);
	self:SetUpdateIfPotentiallyVisible(1);
end

------------------------------------------------------------------------------------------------------
function BasicEntity:OnPropertyChange()
	self:SetFromProperties();
end

------------------------------------------------------------------------------------------------------
function BasicEntity:OnEvent( id, params)
	
end

------------------------------------------------------------------------------------------------------
function BasicEntity:OnCollide(hit)
	if (self.ImpactSound and not Sound:IsPlaying(self.ImpactSound)) then
		if (hit.fSpeed>(self.LastSpeed*4)) then
			-- reset / new hit cycle
			self.LastFrequency=900.0;
			self.LastImpact=0;
		end

		-- do not trigger too many times / avoid false triggering, sliding
		if (self.LastImpact<2) then
			self.LastSpeed=hit.fSpeed;
			-- drop frequency
			self.LastFrequency=self.LastFrequency*((100.0-20.0)/100.0);

			Sound:SetSoundPosition(self.ImpactSound, hit.vPos);		
			Sound:SetSoundFrequency(self.ImpactSound,self.LastFrequency);
			Sound:PlaySound(self.ImpactSound,hit.fSpeed/64.0);				

			self.LastImpact=self.LastImpact+1;
		end

		--System:LogToConsole("speed="..hit.fSpeed..",volume mult="..hit.fSpeed/32.0..",self.LastImpact="..self.LastImpact);
	end	
end

------------------------------------------------------------------------------------------------------
function BasicEntity:OnShutDown()
end

------------------------------------------------------------------------------------------------------
function BasicEntity:OnDamage( hit )
	--System.LogToConsole( "On Damage" );

	if( hit.ipart ) then
		self:AddImpulse( hit.ipart, hit.pos, hit.dir, hit.impact_force_mul );
	elseif (self.Properties.Physics.bActivateOnDamage) then
		if (self.Properties.Physics.bRigidBody == 1) then
			if(hit.explosion)then
				--System:LogToConsole( "On Damage (by explosion)" );
				self:AwakePhysics(1);
			end
		end
	end
end

------------------------------------------------------------------------------------------------------
-- Input events
------------------------------------------------------------------------------------------------------
function BasicEntity:Event_AddImpulse(sender)
	self.temp_vec.x=self.Properties.Physics.vector_Impulse.x;
	self.temp_vec.y=self.Properties.Physics.vector_Impulse.y;
	self.temp_vec.z=self.Properties.Physics.vector_Impulse.z;
	self:AddImpulse(0,nil,self.temp_vec,1);
end

------------------------------------------------------------------------------------------------------
function BasicEntity:Event_Activate(sender)	

	--create rigid body 
	if (self.Properties.Physics.bRigidBody == 1) then
		self:SetPhysicsProperties( 1 );
		self:AwakePhysics(1);
	end
end

------------------------------------------------------------------------------------------------------
function BasicEntity:Event_StartAnimation(sender)
	self:StartAnimation(0,self.Properties.Animation.Animation);
	self:SetAnimationSpeed( self.Properties.Animation.Speed )
end

------------------------------------------------------------------------------------------------------
function BasicEntity:Event_StopAnimtion(sender)
	self:ResetAnimation(0);
end
------------------------------------------------------------------------------------------------------
function BasicEntity:OnEvent( id, params)
	if (id == ScriptEvent_PhysicalizeOnDemand) then
		self:SetPhysicsProperties(0);
	end
end
