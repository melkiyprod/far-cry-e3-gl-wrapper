-----------------------------------------------------------------------------------------------
--
--	EAX entity - to be attached to area 
--	will set specified EAX settings when entering area
--

EAXPresetArea = {
	type = "EAXPresetArea",

	Editor = {
		Model="Objects/Editor/S.cgf",
	},

	Properties = {
		eaxpresetEAXPreset="",
		--nEAXEnvironment=0, 
		--a value bigger than 0 will use the pre-defined presets. 
		--if the value -1 is specified, the above pre-defined table will be used.
		--if the value 0 is specified, EAX default environment will be used
	},
	bInside=0,
}

function EAXPresetArea:OnSave(stm)
	-- fix 17: Properties are already saved and restored by the engine (record header). Writing them here
	-- again broke checkpoints: the game sometimes did not call OnSave (m3seagullsPST, checkpoints in the ship),
	-- OnLoad still read, took the next entity's data and loading stopped ("CSTREAM:Read (string too long...over 256)").
	--WriteToStream(stm, self.Properties);
end

function EAXPresetArea:OnLoad(stm)
	-- fix 17 (see OnSave)
	--self.Properties=ReadFromStream(stm);
end

function EAXPresetArea:EnableEAX()
	local Preset=EAXPresetDB[self.Properties.eaxpresetEAXPreset];
	if (Preset) then
		Sound:SetEaxEnvironment(Preset);
	else
		System:Log("WARNING: EAX-Preset "..self.Properties.eaxpresetEAXPreset.." not defined ! Using default params...");
		Sound:SetEaxEnvironment(0);
	end
end

function EAXPresetArea:OnPropertyChange()
	if (self.bInside~=0) then
		self:EnableEAX();
	end
end

function EAXPresetArea:CliSrv_OnInit()
	if (self.Initialized) then
		return
	end	
	self:RegisterState("Inactive");
	self:RegisterState("Active");
	self:GotoState("Inactive");
	self.Initialized=1;
end

function EAXPresetArea:OnShutDown()
end

function EAXPresetArea:Client_Inactive_OnEnterArea( player,areaId )
	System:Log("Entering EAX-Area "..areaId);
	--System:Log("Set EAX Environment "..self.Properties.nEAXEnvironment);
--	if (self.Properties.nEAXEnvironment>0) then
--		Sound:SetEaxEnvironment(self.Properties.nEAXEnvironment);
--	else	
	self:EnableEAX();
--	end
	self:GotoState("Active");
	self.bInside=1;
end

function EAXPresetArea:Client_Active_OnLeaveArea( player,areaId )
	System:Log("Leaving EAX-Area "..areaId);
	-- disable eax, choosing OFF preset	
	--System:Log("Set EAX Environment 0");
	--if( self.Properties.EaxReverbProperties~=0 ) then
	--	Sound:SetEaxEnvironment(0);
	--end		
	Sound:SetEaxEnvironment(0);
	self:GotoState("Inactive");
	self.bInside=0;
end

--function EAXPresetArea:Client_Active_OnProceedFadeArea( player,areaId,fadeCoeff )
--end

	----------------------------------------------------------------------------------------
function EAXPresetArea:OnMove()
--	local newInsidePos = self:UpdateInSector(self.nBuilding,	self.nSector );
--	self.nBuilding = newInsidePos.x;
--	self.nSector = newInsidePos.y;
end


EAXPresetArea.Server={
	OnInit=function(self)
		self:CliSrv_OnInit()
	end,
	OnShutDown=function(self)
	end,
	Inactive={
	},
	Active={
	},
}

EAXPresetArea.Client={
	OnInit=function(self)
		self:CliSrv_OnInit()
		self:OnMove();
	end,
	OnShutDown=function(self)
	end,
	Inactive={
		OnBeginState=function(self)
--System:Log("Entering INACTIVE");		
		end,
	
		OnEnterArea=EAXPresetArea.Client_Inactive_OnEnterArea,
		OnMove=EAXPresetArea.OnMove,
--		OnMove=EAXPresetArea.Client.OnMove,		
	},
	Active={
		OnBeginState=function(self)
--System:Log("Entering ACTIVE");		
		--	System:Log("SetTimer");
--			self:SetTimer(200);
		end,
		OnMove=EAXPresetArea.OnMove,
--		OnProceedFadeArea=EAXPresetArea.Client_Active_OnProceedFadeArea,
		OnLeaveArea=EAXPresetArea.Client_Active_OnLeaveArea,
		OnEndState=function(self)
--			System:Log("KillTimer");
--			self:KillTimer();
		end,
	},
}
