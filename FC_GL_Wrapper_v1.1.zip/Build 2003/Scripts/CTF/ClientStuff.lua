Script:LoadScript("scripts/default/hud/viewlayersmgr.lua")
ClientStuff={
	
}
--------------------------------------------
function ClientStuff:OnInit()
	--LAYERS--------------------------------------------------------
	self.vlayers=ViewLayersMgr:new(),
	Script:LoadScript("scripts/default/hud/zoomview.lua");
	Script:LoadScript("scripts/default/hud/nightvision.lua");
	Script:LoadScript("scripts/default/hud/binoculars.lua");
	Script:LoadScript("scripts/default/hud/heatvision.lua");
	Script:LoadScript("scripts/default/hud/weaponscope.lua");
	Script:LoadScript("scripts/default/hud/motracklayer.lua");
	Binoculars:OnInit();
	NightVision:OnInit();
	MoTrackLayer:OnInit();
	self.vlayers:AddLayer("HeatVision",HeatVision);
	self.vlayers:AddLayer("NightVision",NightVision);
	self.vlayers:AddLayer("MoTrack",MoTrackLayer);
	self.vlayers:AddLayer("Binoculars",Binoculars);
	self.vlayers:AddLayer("WeaponScope",WeaponScope);
	s_deformable_terrain=0;
end
--------------------------------------------
function ClientStuff:OnUpdate()
	self.vlayers:Update();
	if(ZoomView and ZoomView.IdleUpdate)then ZoomView:IdleUpdate(); end	-- FOV setting (cl_fov, cl_fov_wide)
end
--------------------------------------------
function ClientStuff:OnSetPlayerScore(player)
	
end

--------------------------------------------
function ClientStuff:OnShutDown()
	
end


