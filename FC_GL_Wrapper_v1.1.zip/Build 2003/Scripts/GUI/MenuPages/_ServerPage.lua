ServerPage={
};

function ServerPage:GetName()
	return "ServerPage"
end

function ServerPage.Callback(Sender, Reason, Data)

	if (Reason == XBN_CLICK) then
		if (Sender == ServerPage.BtnStart) then
			local Page=GUI:GetControlPage("CreateServerPage");
			if (Page) then
				Page:Activate();
			end
		elseif (Sender==ServerPage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage("MultiplayerPage");
			if (Page) then
				Page:Activate();
			end
		elseif (Sender==ServerPage.BtnTeamDmg) then
			if (ServerPage.BtnTeamDmg:GetCheck()) then
				System:LogToConsole("TeamDamage is ON.");
			else
				System:LogToConsole("TeamDamage is OFF.");
			end

		elseif (Sender==ServerPage.BtnDedicatedServer) then
			if (ServerPage.BtnDedicatedServer:GetCheck()) then
				System:LogToConsole("Using DEDICATED-SERVER.");
			else
				System:LogToConsole("Using Local Client.");
			end
		end

	elseif (Reason==XLBN_SELCHANGE) then

		if (Sender==ServerPage.ListGameType) then
			if (ServerPage.ListGameType:GetCurSel()[1]==ServerPage.DM) then
				System:LogToConsole("GameType is DeathMatch.");
			elseif (ServerPage.ListGameType:GetCurSel()[1]==ServerPage.TDM) then
				System:LogToConsole("GameType is TeamDeathMatch.");
			else
				System:LogToConsole("GameType is Instagib.");
			end
		end

	end
end

function ServerPage:SetButtonProps(Button)
--	Button.SetFont("Digital", "default", 32, 32);
--	Button.SetColor(1, 0, 0);
	local Params={Speed=1, DstColor={r=1, g=0, b=0}}
	Button:SetEffect(XCTRLEVENT_MOUSEOVER, XCTRLEFFECT_BLINK, Params);
	Button:SetEffect(XCTRLEVENT_MOUSEOVER, XCTRLEFFECT_SOUND, nil, MainMenu.ButtonEffect, 1);
	Button:SetEffect(XCTRLEVENT_CLICK, XCTRLEFFECT_SOUND, nil, MainMenu.ButtonEffect, 1);
end

function ServerPage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	ServerPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(ServerPage.pMouseCursor);

	ServerPage.BtnTeamDmg=self:CreateButton(300, 150, 200, 20, XBS_3STATE, Language.TeamDamage);
	ServerPage.BtnTeamDmg:SetCheck(1);
	ServerPage.BtnTeamDmg:SetCallback(ServerPage.Callback);
	ServerPage.SetButtonProps(self, ServerPage.BtnTeamDmg);

	ServerPage.BtnDedicatedServer=self:CreateButton(300, 200, 200, 20, XBS_3STATE, Language.DedicatedServer);
	ServerPage.BtnDedicatedServer:SetCallback(ServerPage.Callback);
	ServerPage.SetButtonProps(self, ServerPage.BtnDedicatedServer);

	ServerPage.ListGameType=self:CreateListBox(300, 250, 200, 80, XLBS_DROPDOWNLIST);
	ServerPage.DM=ServerPage.ListGameType:AddItem(Language.DM);
	ServerPage.TDM=ServerPage.ListGameType:AddItem(Language.TDM);
	ServerPage.Instagib=ServerPage.ListGameType:AddItem(Language.Instagib);
	ServerPage.ListGameType:SetCurSel({ServerPage.DM});
	ServerPage.ListGameType:SetCallback(ServerPage.Callback);


	ServerPage.Difficulty = self:CreateListBox(300, 300, 200, 150, XLBS_DROPDOWNLIST);
	ServerPage.Difficulty:SetCallback(ServerPage.Callback);
	ServerPage.Difficulty:AddItem("Weather: Day");
	ServerPage.Difficulty:AddItem("Weather: Night");
	ServerPage.Difficulty:AddItem("Weather: Dusk");
	ServerPage.Difficulty:AddItem("Weather: Dawn");
	ServerPage.Difficulty:AddItem("Weather: Rainy");
	ServerPage.Difficulty:SetCurSel({0});

	ServerPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	ServerPage.BtnMainPage:SetCallback(ServerPage.Callback);
	ServerPage.SetButtonProps(self, ServerPage.BtnMainPage);

	ServerPage.BtnStart=self:CreateButton(640, 570, 150, 20, 0, "Select Map");
	ServerPage.BtnStart:SetCallback(ServerPage.Callback);
	ServerPage.SetButtonProps(self, ServerPage.BtnStart);
	
	ServerPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	ServerPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, ServerPage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function ServerPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function ServerPage:OnDraw()
end

-------------------------------------------------------------------------
function ServerPage:OnShutdown()
	ServerPage=nil;
end