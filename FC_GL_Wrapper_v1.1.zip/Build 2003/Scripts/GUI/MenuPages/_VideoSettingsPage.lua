-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------

VideoSettingsPage={
};

function VideoSettingsPage:GetName()
	return "VideoSettingsPage"
end

function VideoSettingsPage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then

		if (Sender==VideoSettingsPage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage("OptionsPage");
			if (Page) then
				Page:Activate();
			end
		else
			if (VideoSettingsPage.BtnApply) then
				VideoSettingsPage.BtnApply:Enable( 1 );
			end
		end

		if (Sender==VideoSettingsPage.BtnApply) then -- apply-button
			local NeedRelaunch=0;
			if (tostring(r_Width)~=tostring(NewWidth) or tostring(r_Height)~=tostring(NewHeight) or tostring(r_ColorBits)~=tostring(NewColorBits)) then
				NeedRelaunch=1;
				System:LogToConsole("Resolution changed: Relaunching...");
			end
			if (r_Driver~=NewDriver) then
				NeedRelaunch=1;
				System:LogToConsole("Driver changed: Relaunching...");
			end
			local NewVal;
			NewVal="0";
			if (VideoSettingsPage.Fullscreen:GetCheck()) then
				NewVal="1";
			end
			if (NewVal~=r_Fullscreen) then
				NeedRelaunch=1;
				System:LogToConsole("Fullscreen changed: Relaunching...");
			end
			NewVal="0";
			if (VideoSettingsPage.VSync:GetCheck()) then
				NewVal="1";
			end
			if (NewVal~=r_VSync) then
				NeedRelaunch=1;
				System:LogToConsole("VSync changed: Relaunching...");
			end
			NewVal=0;
			if (VideoSettingsPage.TexComp:GetCheck()) then
				NewVal=1;
			end
			if (NewVal~=r_ForceDXTTextures) then
				NeedRelaunch=1;
				System:LogToConsole("TextureCompression changed: Relaunching...");
			end
			r_Width=NewWidth;
			r_Height=NewHeight;
			r_ColorBits=NewColorBits;
			r_Driver=NewDriver;
			if (VideoSettingsPage.Fullscreen:GetCheck()) then
				r_Fullscreen=1;
			else
				r_Fullscreen=0;
			end
			if (VideoSettingsPage.VSync:GetCheck()) then
				r_VSync=1;
			else
				r_VSync=0;
			end
			if (VideoSettingsPage.Water:GetCheck()) then
				e_water=1;
			else
				e_water=0;
			end
			if (VideoSettingsPage.Sun:GetCheck()) then
				e_sun=1;
			else
				e_sun=0;
			end
			if (VideoSettingsPage.Shadow:GetCheck()) then
				e_shadow_maps=1;
			else
				e_shadow_maps=0;
			end
			if (VideoSettingsPage.TexComp:GetCheck()) then
				r_ForceDXTTextures=1;
			else
				r_ForceDXTTextures=0;
			end
			VideoSettingsPage.BtnApply:Enable( nil );
			if (NeedRelaunch~=0) then
				Game:SendMessage("Relaunch");
			end
		end

	end

	if (Reason==XLBN_SELCHANGE) then

		if (VideoSettingsPage.BtnApply) then
			VideoSettingsPage.BtnApply:Enable( 1 );
		end

		if (Sender==VideoSettingsPage.Resolution) then
			local Sel=VideoSettingsPage.Resolution:GetCurSel()[1]
			NewWidth=VideoSettingsPage.DispFmts[Sel+1].width;
			NewHeight=VideoSettingsPage.DispFmts[Sel+1].height;
			NewColorBits=VideoSettingsPage.DispFmts[Sel+1].bpp;
		end

		if (Sender==VideoSettingsPage.Driver) then
			local Sel=VideoSettingsPage.Driver:GetCurSel()[1]
			if (Sel==0) then
				NewDriver="OpenGL";
			elseif (Sel==1) then
				NewDriver="Direct3D9";
			end
		end

	end
end

function VideoSettingsPage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	VideoSettingsPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(VideoSettingsPage.pMouseCursor);

	-- store temporary values in case the user presses the back-button
	NewWidth=r_Width;
	NewHeight=r_Height;
	NewColorBits=r_ColorBits;
	NewDriver=r_Driver;

	self:CreateStatic(275, 84, 100, 20, 0, Language.Resolution);
	VideoSettingsPage.Resolution=self:CreateListBox(400, 84, 165, 118, XLBS_DROPDOWNLIST);
	VideoSettingsPage.Resolution:SetCallback(VideoSettingsPage.Callback);
	VideoSettingsPage.DispFmts=System:EnumDisplayFormats();
	for i, DispFmt in VideoSettingsPage.DispFmts do
		local Item=VideoSettingsPage.Resolution:AddItem(DispFmt.width.."x"..DispFmt.height.."x"..DispFmt.bpp, 1);
		if (tostring(NewWidth)==tostring(DispFmt.width) and tostring(NewHeight)==tostring(DispFmt.height) and tostring(NewColorBits)==tostring(DispFmt.bpp)) then
			VideoSettingsPage.Resolution:SetCurSel({Item});
		end
	end
	if ( Game:IsClient() ) then
		VideoSettingsPage.Resolution:Enable( nil );
	end

	self:CreateStatic(275, 124, 100, 20, 0, Language.Driver);
	VideoSettingsPage.Driver=self:CreateListBox(400, 124, 165, 62, XLBS_DROPDOWNLIST);
	VideoSettingsPage.Driver:AddItem("OpenGL", 1);
	VideoSettingsPage.Driver:AddItem("Direct3D9", 1);
	VideoSettingsPage.Driver:SetCallback(VideoSettingsPage.Callback);
	if (NewDriver=="OpenGL") then
		VideoSettingsPage.Driver:SetCurSel({0});
	elseif (NewDriver=="Direct3D9") then
		VideoSettingsPage.Driver:SetCurSel({1});
	else
		VideoSettingsPage.Driver:SetCurSel({0});
	end
	if ( Game:IsClient() ) then
		VideoSettingsPage.Driver:Enable( nil );
	end

	VideoSettingsPage.Fullscreen=self:CreateButton(300, 164, 200, 20, XBS_3STATE, Language.Fullscreen);
	VideoSettingsPage.Fullscreen:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.Fullscreen);
	if (r_Fullscreen~="0") then
		VideoSettingsPage.Fullscreen:SetCheck(1);
	end
	if ( Game:IsClient() ) then
		VideoSettingsPage.Fullscreen:Enable( nil );
	end

	VideoSettingsPage.VSync=self:CreateButton(300, 204, 200, 20, XBS_3STATE, Language.VSync);
	VideoSettingsPage.VSync:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.VSync);
	if (r_VSync~="0") then
		VideoSettingsPage.VSync:SetCheck(1);
	end
	if ( Game:IsClient() ) then
		VideoSettingsPage.VSync:Enable( nil );
	end

	VideoSettingsPage.Water=self:CreateButton(300, 244, 200, 20, XBS_3STATE, Language.Water);
	VideoSettingsPage.Water:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.Water);
	if (e_water~=0) then
		VideoSettingsPage.Water:SetCheck(1);
	end

	VideoSettingsPage.Sun=self:CreateButton(300, 284, 200, 20, XBS_3STATE, Language.Sun);
	VideoSettingsPage.Sun:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.Sun);
	if (e_sun~=0) then
		VideoSettingsPage.Sun:SetCheck(1);
	end

	VideoSettingsPage.Shadow=self:CreateButton(300, 324, 200, 20, XBS_3STATE, Language.Shadow);
	VideoSettingsPage.Shadow:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.Shadow);
	if (e_shadow_maps~=0) then
		VideoSettingsPage.Shadow:SetCheck(1);
	end

	VideoSettingsPage.TexComp=self:CreateButton(300, 364, 200, 20, XBS_3STATE, Language.TexComp);
	VideoSettingsPage.TexComp:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.TexComp);
	if (r_ForceDXTTextures~=0) then
		VideoSettingsPage.TexComp:SetCheck(1);
	end
	if ( Game:IsClient() ) then
		VideoSettingsPage.TexComp:Enable( nil );
	end

	VideoSettingsPage.Anisotropic=self:CreateButton(300, 404, 200, 20, XBS_3STATE, Language.Anisotropic);
	VideoSettingsPage.Anisotropic:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.Anisotropic);
	VideoSettingsPage.Anisotropic:Enable( nil );

	VideoSettingsPage.FSAA=self:CreateButton(300, 404, 200, 20, XBS_3STATE, Language.FSAA);
	VideoSettingsPage.FSAA:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.FSAA);
	VideoSettingsPage.FSAA:Enable( nil );

	self:CreateStatic(275, 444, 100, 20, 0, Language.MemPool);
	VideoSettingsPage.MemPool=self:CreateListBox(400, 444, 165, 118, XLBS_DROPDOWNLIST);
	VideoSettingsPage.MemPool:SetCallback(VideoSettingsPage.Callback);
	VideoSettingsPage.MemPool:AddItem("System-Memory", 1);
	VideoSettingsPage.MemPool:AddItem("AGP-Memory", 1);
	VideoSettingsPage.MemPool:AddItem("Video-Memory", 1);
	VideoSettingsPage.MemPool:SetCurSel({2});
	VideoSettingsPage.MemPool:Enable( nil );

	self:CreateStatic(275, 484, 100, 20, 0, Language.MaxTexSize);
	VideoSettingsPage.MaxTexSize=self:CreateListBox(400, 484, 165, 118, XLBS_DROPDOWNLIST);
	VideoSettingsPage.MaxTexSize:SetCallback(VideoSettingsPage.Callback);
	VideoSettingsPage.MaxTexSize:AddItem("128", 1);
	VideoSettingsPage.MaxTexSize:AddItem("256", 1);
	VideoSettingsPage.MaxTexSize:AddItem("512", 1);
	VideoSettingsPage.MaxTexSize:AddItem("1024", 1);
	VideoSettingsPage.MaxTexSize:AddItem("2048", 1);
	VideoSettingsPage.MaxTexSize:SetCurSel({4});
	VideoSettingsPage.MaxTexSize:Enable( nil );

	VideoSettingsPage.BtnApply=self:CreateButton(690, 570, 100, 20, 0, Language.Apply);
	VideoSettingsPage.BtnApply:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.BtnApply);
	VideoSettingsPage.BtnApply:Enable( nil );

	VideoSettingsPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	VideoSettingsPage.BtnMainPage:SetCallback(VideoSettingsPage.Callback);
	MainPage.SetButtonProps(self, VideoSettingsPage.BtnMainPage);
	
	VideoSettingsPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	VideoSettingsPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, VideoSettingsPage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function VideoSettingsPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function VideoSettingsPage:OnDraw()
end

-------------------------------------------------------------------------
function VideoSettingsPage:OnShutdown()
end