SelectLevelPage={
};

function SelectLevelPage:GetName()
	return "SelectLevelPage"
end

function SelectLevelPage.Callback(Sender, Reason, Data)

	local iCurIdx = SelectLevelPage.ListSavedGames:GetCurSel();
	local itmCur = SelectLevelPage.ListSavedGames:GetItem(iCurIdx[1]);
	local strSaveName = nil;
	if (itmCur) then
		strSaveName = itmCur.label[1];
	end

	if (Reason == XBN_CLICK) then
		if (Sender == SelectLevelPage.BtnLoad) then
			--Game:Load(strSaveName);
			if strSaveName then
			    Game:SendMessage("LoadGame "..strSaveName);
			end
		elseif (Sender == SelectLevelPage.BtnCancel) then
			local Page=GUI:GetControlPage(BackPage);
			if (Page) then
				Page:Activate();
			end
		end
	end

	if (Reason == XLBN_ITEMDBLCLICK) then
		if (Sender == SelectLevelPage.ListSavedGames) then
			if strSaveName then
    			--Game:Load(strSaveName);
			    Game:SendMessage("LoadGame "..strSaveName);
			end
		end
	end
end

function SelectLevelPage:SetButtonProps(Button)
	local Params={Speed=1, DstColor={r=1, g=0, b=0}}
	Button:SetEffect(XCTRLEVENT_MOUSEOVER, XCTRLEFFECT_BLINK, Params);
--	Button:SetEffect(XCTRLEVENT_MOUSEOVER, XCTRLEFFECT_SOUND, nil, MainMenu.ButtonEffect, 1);
--	Button:SetEffect(XCTRLEVENT_CLICK, XCTRLEFFECT_SOUND, nil, MainMenu.ButtonEffect, 1);
end

function SelectLevelPage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	SelectLevelPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(SelectLevelPage.pMouseCursor);

	SelectLevelPage.ListSavedGames = self:CreateListBox(10, 40, 780, 520, XLBS_LISTVIEW);
	SelectLevelPage.ListSavedGames:AddColumn("Name", 505);
	SelectLevelPage.ListSavedGames:AddColumn("Date", 130);
	SelectLevelPage.ListSavedGames:SetCallback(SelectLevelPage.Callback);

	SelectLevelPage.BtnLoad=self:CreateButton(690, 570, 100, 20, 0, Language.Load);
	SelectLevelPage.BtnLoad:SetCallback(SelectLevelPage.Callback);
	--SelectLevelPage.SetButtonProps(self, SelectLevelPage.BtnLoad);

	SelectLevelPage.BtnCancel=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	SelectLevelPage.BtnCancel:SetCallback(SelectLevelPage.Callback);
	--SelectLevelPage.SetButtonProps(self, SelectLevelPage.BtnCancel);

	self:CreateStatic(11, 1, 100, 50, 0, Language.LoadGame);

	local SaveGames = Game:GetSaveGameList();
	for i, CurSave in SaveGames do
		SelectLevelPage.ListSavedGames:AddItem(CurSave);
	end
	SelectLevelPage.ListSavedGames:SetCurSel({0});

	SelectLevelPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	SelectLevelPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, SelectLevelPage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function SelectLevelPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function SelectLevelPage:OnDraw()
end

-------------------------------------------------------------------------
function SelectLevelPage:OnShutdown()
	SelectLevelPage=nil;
end