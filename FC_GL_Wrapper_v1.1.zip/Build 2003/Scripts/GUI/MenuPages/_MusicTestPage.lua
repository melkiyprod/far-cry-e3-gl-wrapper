-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------^
--#Sound:LoadMusic("scripts/music/dynamicmusic.lua")

MusicTestPage={
	Item={},
	CurrTheme="",
	CurrMood="",
};

function MusicTestPage:GetName()
	return "MusicTestPage"
end

function MusicTestPage:RefreshList()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	MusicTestPage.ListTheme:Clear();
	local Themes=Sound:GetMusicThemes();
	for i,Theme in Themes do
		MusicTestPage.Item[i]=MusicTestPage.ListTheme:AddItem({Theme});
	end
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

function MusicTestPage:RefreshMoods()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	MusicTestPage.ListMood:Clear();
	local Moods=Sound:GetMusicMoods(MusicTestPage.CurrTheme);
	local Sel;
	for i,Mood in Moods do
		if (Mood==MusicTestPage.CurrMood) then
			MusicTestPage.ListMood:SetCurSel({MusicTestPage.ListMood:AddItem({Mood})});
		else
			MusicTestPage.ListMood:AddItem({Mood});
		end
	end
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

function MusicTestPage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then
		if (Sender==MusicTestPage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage(BackPage);
			if (Page) then
				Page:Activate();
			end
		elseif (Sender==MusicTestPage.BtnStop) then -- stop
			Sound:SetMusicTheme("");
			MusicTestPage.CurrTheme="";
			local OldVerbosity=log_Verbosity;	-- fix 11
			if (OldVerbosity) then log_Verbosity=0; end
			MusicTestPage.ListTheme:SetCurSel({});
			if (OldVerbosity) then log_Verbosity=OldVerbosity; end
			MusicTestPage.ListMood:Clear();
		elseif (Sender==MusicTestPage.BtnRefresh) then -- refresh
			MusicTestPage:RefreshList();
		end
	end
	if (Reason==XLBN_ITEMCLICK) then
		if (Sender==MusicTestPage.ListTheme) then
			MusicTestPage.CurrTheme=MusicTestPage.ListTheme:GetItem(MusicTestPage.ListTheme:GetCurSel()[1]).label[1];
			Sound:SetMusicTheme(MusicTestPage.CurrTheme);
			MusicTestPage:RefreshMoods();
		elseif (Sender==MusicTestPage.ListMood) then
			MusicTestPage.CurrMood=MusicTestPage.ListMood:GetItem(MusicTestPage.ListMood:GetCurSel()[1]).label[1];
			Sound:SetMusicMood(MusicTestPage.CurrMood);
		end
	end
end

function MusicTestPage:OnInit()
	Sound:LoadMusic("scripts/music/dynamicmusic.lua")
	MusicTestPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(MusicTestPage.pMouseCursor);

	MusicTestPage.ListTheme=self:CreateListBox(10, 10, 380, 550, XLBS_LISTVIEW);
	MusicTestPage.ListTheme:AddColumn("Themes", 100);
	MusicTestPage.ListTheme:SetCallback(MusicTestPage.Callback);
	
	MusicTestPage.ListMood=self:CreateListBox(410, 10, 380, 550, XLBS_LISTVIEW);
	MusicTestPage.ListMood:AddColumn("Moods", 100);
	MusicTestPage.ListMood:SetCallback(MusicTestPage.Callback);
	
	MusicTestPage:RefreshList();
	
	MusicTestPage.BtnRefresh=self:CreateButton(690, 570, 100, 20, 0, "Refresh");
	MusicTestPage.BtnRefresh:SetCallback(MusicTestPage.Callback);
	MainPage.SetButtonProps(self, MusicTestPage.BtnRefresh);
	
	MusicTestPage.BtnStop=self:CreateButton(350, 570, 100, 20, 0, "Stop");
	MusicTestPage.BtnStop:SetCallback(MusicTestPage.Callback);
	MainPage.SetButtonProps(self, MusicTestPage.BtnStop);

	MusicTestPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	MusicTestPage.BtnMainPage:SetCallback(MusicTestPage.Callback);
	MainPage.SetButtonProps(self, MusicTestPage.BtnMainPage);
	
	MusicTestPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	MusicTestPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, MusicTestPage.BackgndTex);
end

-------------------------------------------------------------------------
function MusicTestPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function MusicTestPage:OnDraw()
end

-------------------------------------------------------------------------
function MusicTestPage:OnShutdown()
end

