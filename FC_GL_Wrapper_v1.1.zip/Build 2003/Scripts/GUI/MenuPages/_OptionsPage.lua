-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------

OptionsPage={
};

function OptionsPage:GetName()
	return "OptionsPage"
end

function OptionsPage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then

		if (Sender==OptionsPage.BtnPlayerSettings) then
			local Page=GUI:GetControlPage("PlayerSettingsPage");
			if (Page) then
				Page:Activate();
			end
		elseif (Sender==OptionsPage.BtnControlSettings) then
			local Page=GUI:GetControlPage("ControlSettingsPage");
			if (Page) then
				Page:Activate();
			end
		elseif (Sender==OptionsPage.BtnVideoSettings) then
			local Page=GUI:GetControlPage("VideoSettingsPage");
			if (Page) then
				Page:Activate();
			end
		elseif (Sender==OptionsPage.BtnSoundSettings) then
			local Page=GUI:GetControlPage("SoundSettingsPage");
			if (Page) then
				Page:Activate();
			end
		elseif (Sender==OptionsPage.BtnAccuracyUp) then -- diff-up-button
			game_Accuracy=game_Accuracy+0.1;
			if (tonumber(game_Accuracy)>2.0) then
				game_Accuracy=2.0;
			end
			OptionsPage.EditAccuracy:SetText(format("%3.1f", tonumber(game_Accuracy)), 1);
		elseif (Sender==OptionsPage.BtnAccuracyDn) then -- diff-down-button
			game_Accuracy=game_Accuracy-0.1;
			if (tonumber(game_Accuracy)<0.2) then
				game_Accuracy=0.2;
			end
			OptionsPage.EditAccuracy:SetText(format("%3.1f", tonumber(game_Accuracy)), 1);
			
		elseif (Sender==OptionsPage.BtnAggressionUp) then -- diff-up-button
			game_Aggression=game_Aggression+0.1;
			if (tonumber(game_Aggression)>2.0) then
				game_Aggression=2.0;
			end
			OptionsPage.EditAggression:SetText(format("%3.1f", tonumber(game_Aggression)), 1);
		elseif (Sender==OptionsPage.BtnAggressionDn) then -- diff-down-button
			game_Aggression=game_Aggression-0.1;
			if (tonumber(game_Aggression)<0.2) then
				game_Aggression=0.2;
			end
			OptionsPage.EditAggression:SetText(format("%3.1f", tonumber(game_Aggression)), 1);
			
		elseif (Sender==OptionsPage.BtnHealthUp) then -- diff-up-button
			game_Health=game_Health+0.1;
			if (tonumber(game_Health)>2.0) then
				game_Health=2.0;
			end
			OptionsPage.EditHealth:SetText(format("%3.1f", tonumber(game_Health)), 1);
		elseif (Sender==OptionsPage.BtnHealthDn) then -- diff-down-button
			game_Health=game_Health-0.1;
			if (tonumber(game_Health)<0.2) then
				game_Health=0.2;
			end
			OptionsPage.EditHealth:SetText(format("%3.1f", tonumber(game_Health)), 1);
		end

--		elseif (Sender==MultiPlayerPage.BtnCreateServer) then
--			local Page=GUI.GetControlPage("CreateServerPage");
--			if (Page) then
--				Page.Activate();
--			end

		if (Sender==OptionsPage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage("MainPage");
			if (Page) then
				Page:Activate();
			end
		end

	end
end

function OptionsPage:OnInit()
	OptionsPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(OptionsPage.pMouseCursor);
	
	OptionsPage.BtnPlayerSettings=self:CreateButton(300, 184, 200, 20, 0, Language.PlayerSettings);
	OptionsPage.BtnPlayerSettings:SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnPlayerSettings);
	
	OptionsPage.BtnControlSettings=self:CreateButton(300, 224, 200, 20, 0, Language.ControlSettings);
	OptionsPage.BtnControlSettings:SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnControlSettings);
--	OptionsPage.BtnControlSettings:Enable( nil );	-- fix 10: Control Settings enabled
	
	OptionsPage.BtnVideoSettings=self:CreateButton(300, 264, 200, 20, 0, Language.VideoSettings);
	OptionsPage.BtnVideoSettings:SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnVideoSettings);
	
	OptionsPage.BtnSoundSettings=self:CreateButton(300, 304, 200, 20, 0, Language.SoundSettings);
	OptionsPage.BtnSoundSettings:SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnSoundSettings);
	
	OptionsPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	OptionsPage.BtnMainPage:SetCallback(OptionsPage.Callback);
	MainPage.SetButtonProps(self, OptionsPage.BtnMainPage);
	
	self:CreateStatic(300, 470, 100, 20, 0, Language.Accuracy);
	OptionsPage.EditAccuracy=self:CreateEditBox(400, 470, 80, 20, XEBS_READONLY);
	OptionsPage.EditAccuracy:SetText(format("%3.1f", tonumber(game_Accuracy)), 1);
	OptionsPage.EditAccuracy:SetCallback(OptionsPage.Callback);
	OptionsPage.BtnAccuracyUp=self:CreateButton(482, 470, 18, 9, 0, "/\\");
	OptionsPage.BtnAccuracyUp:SetCallback(OptionsPage.Callback);
--	OptionsPage.SetButtonProps(self, OptionsPage.BtnAccuracyUp);
	OptionsPage.BtnAccuracyDn=self:CreateButton(482, 481, 18, 9, 0, "\\/");
	OptionsPage.BtnAccuracyDn:SetCallback(OptionsPage.Callback);
--	OptionsPage.SetButtonProps(self, OptionsPage.BtnAccuracyDn);
	
	self:CreateStatic(300, 500, 100, 20, 0, Language.Aggression);
	OptionsPage.EditAggression=self:CreateEditBox(400, 500, 80, 20, XEBS_READONLY);
	OptionsPage.EditAggression:SetText(format("%3.1f", tonumber(game_Aggression)), 1);
	OptionsPage.EditAggression:SetCallback(OptionsPage.Callback);
	OptionsPage.BtnAggressionUp=self:CreateButton(482, 500, 18, 9, 0, "/\\");
	OptionsPage.BtnAggressionUp:SetCallback(OptionsPage.Callback);
--	OptionsPage.SetButtonProps(self, OptionsPage.BtnAggressionUp);
	OptionsPage.BtnAggressionDn=self:CreateButton(482, 511, 18, 9, 0, "\\/");
	OptionsPage.BtnAggressionDn:SetCallback(OptionsPage.Callback);
--	OptionsPage.SetButtonProps(self, OptionsPage.BtnAggressionDn);
	
	self:CreateStatic(300, 530, 100, 20, 0, Language.Health);
	OptionsPage.EditHealth=self:CreateEditBox(400, 530, 80, 20, XEBS_READONLY);
	OptionsPage.EditHealth:SetText(format("%3.1f", tonumber(game_Health)), 1);
	OptionsPage.EditHealth:SetCallback(OptionsPage.Callback);
	OptionsPage.BtnHealthUp=self:CreateButton(482, 530, 18, 9, 0, "/\\");
	OptionsPage.BtnHealthUp:SetCallback(OptionsPage.Callback);
--	OptionsPage.SetButtonProps(self, OptionsPage.BtnHealthUp);
	OptionsPage.BtnHealthDn=self:CreateButton(482, 541, 18, 9, 0, "\\/");
	OptionsPage.BtnHealthDn:SetCallback(OptionsPage.Callback);
--	OptionsPage.SetButtonProps(self, OptionsPage.BtnHealthDn);

	OptionsPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	OptionsPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, OptionsPage.BackgndTex);

end

-------------------------------------------------------------------------
function OptionsPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function OptionsPage:OnDraw()
end

-------------------------------------------------------------------------
function OptionsPage:OnShutdown()
end

