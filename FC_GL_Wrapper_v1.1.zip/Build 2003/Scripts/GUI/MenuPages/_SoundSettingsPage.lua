-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------

SoundSettingsPage={
};

function SoundSettingsPage:GetName()
	return "SoundSettingsPage"
end

function SoundSettingsPage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then

		if (Sender==SoundSettingsPage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage("OptionsPage");
			if (Page) then
				Page:Activate();
			end
		end

		if (Sender==SoundSettingsPage.BtnDoppler) then -- doppler on/off
			if (SoundSettingsPage.BtnDoppler:GetCheck()) then
				s_DopplerEnable="1";
				System:LogToConsole("Doppler enabled");
			else
				s_DopplerEnable="0";
				System:LogToConsole("Doppler disabled");
			end
		end

	end

	if (Reason==XLBN_SELCHANGE) then

		if (Sender==SoundSettingsPage.SoundVolume) then
			s_SFXVolume=SoundSettingsPage.SoundVolume:GetCurSel()[1]/10;
			g_GlobalSFXVolume=s_SFXVolume;	-- this variable is used in the concentration feature
		end

		if (Sender==SoundSettingsPage.MusicVolume) then
			s_MusicVolume=SoundSettingsPage.MusicVolume:GetCurSel()[1]/10;
		end

		if (Sender==SoundSettingsPage.MixRate) then
			local Sel=SoundSettingsPage.MixRate:GetCurSel()[1];
			if (Sel==0) then
				s_SampleRate="11025";
			elseif (Sel==1) then
				s_SampleRate="22050";
			elseif (Sel==2) then
				s_SampleRate="44100";
			elseif (Sel==3) then
				s_SampleRate="48000";
			elseif (Sel==4) then
				s_SampleRate="96000";
			end
		end

		if (Sender==SoundSettingsPage.SpeakerConfig) then
			local Sel=SoundSettingsPage.SpeakerConfig:GetCurSel()[1];
			if (Sel==0) then
				s_SpeakerConfig="3";
			elseif (Sel==1) then
				s_SpeakerConfig="5";
			elseif (Sel==2) then
				s_SpeakerConfig="2";
			elseif (Sel==3) then
				s_SpeakerConfig="4";
			elseif (Sel==4) then
				s_SpeakerConfig="6";
			elseif (Sel==5) then
				s_SpeakerConfig="1";
			end
		end

	end
end

function SoundSettingsPage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	SoundSettingsPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(SoundSettingsPage.pMouseCursor);

	self:CreateStatic(275, 184, 100, 20, 0, Language.SoundVolume);
	SoundSettingsPage.SoundVolume=self:CreateListBox(425, 184, 50, 229, XLBS_DROPDOWNLIST);
	SoundSettingsPage.SoundVolume:AddItem("Off");
	for i=1,10,1 do
		SoundSettingsPage.SoundVolume:AddItem(format("%02d", i), 1);
	end
	SoundSettingsPage.SoundVolume:SetCurSel({s_SFXVolume*10});
	SoundSettingsPage.SoundVolume:SetCallback(SoundSettingsPage.Callback);

	self:CreateStatic(275, 224, 100, 20, 0, Language.MusicVolume);
	SoundSettingsPage.MusicVolume=self:CreateListBox(425, 224, 50, 229, XLBS_DROPDOWNLIST);
	SoundSettingsPage.MusicVolume:AddItem("Off");
	for i=1,10,1 do
		SoundSettingsPage.MusicVolume:AddItem(format("%02d", i), 1);
	end
	SoundSettingsPage.MusicVolume:SetCurSel({s_MusicVolume*10});
	SoundSettingsPage.MusicVolume:SetCallback(SoundSettingsPage.Callback);

	self:CreateStatic(275, 264, 100, 20, 0, Language.MixRate);
	SoundSettingsPage.MixRate=self:CreateListBox(425, 264, 140, 118, XLBS_DROPDOWNLIST);
	SoundSettingsPage.MixRate:AddItem("11025 Hz", 1);
	SoundSettingsPage.MixRate:AddItem("22050 Hz", 1);
	SoundSettingsPage.MixRate:AddItem("44100 Hz", 1);
	SoundSettingsPage.MixRate:AddItem("48000 Hz", 1);
	SoundSettingsPage.MixRate:AddItem("96000 Hz", 1);
	if (s_SampleRate=="11025") then
		SoundSettingsPage.MixRate:SetCurSel({0});
	elseif (s_SampleRate=="22050") then
		SoundSettingsPage.MixRate:SetCurSel({1});
	elseif (s_SampleRate=="44100") then
		SoundSettingsPage.MixRate:SetCurSel({2});
	elseif (s_SampleRate=="48000") then
		SoundSettingsPage.MixRate:SetCurSel({3});
	elseif (s_SampleRate=="96000") then
		SoundSettingsPage.MixRate:SetCurSel({4});
	end
	SoundSettingsPage.MixRate:SetCallback(SoundSettingsPage.Callback);

	self:CreateStatic(275, 304, 100, 20, 0, Language.SpeakerConfig);
	SoundSettingsPage.SpeakerConfig=self:CreateListBox(425, 304, 140, 136, XLBS_DROPDOWNLIST);
	SoundSettingsPage.SpeakerConfig:AddItem(Language.Mono);
	SoundSettingsPage.SpeakerConfig:AddItem(Language.Stereo);
	SoundSettingsPage.SpeakerConfig:AddItem(Language.Headphones);
	SoundSettingsPage.SpeakerConfig:AddItem(Language.Quad);
	SoundSettingsPage.SpeakerConfig:AddItem(Language.Surround);
	SoundSettingsPage.SpeakerConfig:AddItem(Language._5Dot1);
	if (s_SpeakerConfig=="1") then
		SoundSettingsPage.SpeakerConfig:SetCurSel({5});
	elseif (s_SpeakerConfig=="2") then
		SoundSettingsPage.SpeakerConfig:SetCurSel({2});
	elseif (s_SpeakerConfig=="3") then
		SoundSettingsPage.SpeakerConfig:SetCurSel({0});
	elseif (s_SpeakerConfig=="4") then
		SoundSettingsPage.SpeakerConfig:SetCurSel({3});
	elseif (s_SpeakerConfig=="5") then
		SoundSettingsPage.SpeakerConfig:SetCurSel({1});
	elseif (s_SpeakerConfig=="6") then
		SoundSettingsPage.SpeakerConfig:SetCurSel({4});
	end
	SoundSettingsPage.SpeakerConfig:SetCallback(SoundSettingsPage.Callback);

	SoundSettingsPage.BtnDoppler=self:CreateButton(300, 344, 200, 20, XBS_3STATE, Language.Doppler);
	SoundSettingsPage.BtnDoppler:SetCallback(SoundSettingsPage.Callback);
	if (s_DopplerEnable=="1") then
		SoundSettingsPage.BtnDoppler:SetCheck(1);
	end
	MainPage.SetButtonProps(self, SoundSettingsPage.BtnDoppler);

	SoundSettingsPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	SoundSettingsPage.BtnMainPage:SetCallback(SoundSettingsPage.Callback);
	MainPage.SetButtonProps(self, SoundSettingsPage.BtnMainPage);
	
	SoundSettingsPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	SoundSettingsPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, SoundSettingsPage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function SoundSettingsPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function SoundSettingsPage:OnDraw()
end

-------------------------------------------------------------------------
function SoundSettingsPage:OnShutdown()
end

