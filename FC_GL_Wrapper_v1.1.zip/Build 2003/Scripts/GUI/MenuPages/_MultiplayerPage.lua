MultiplayerPage={
	ServerTable={},
	Servers={},
	Item={},
};

function MultiplayerPage:GetName()
	return "MultiplayerPage"
end

function MultiplayerPage.ItemSelect(Sender, Reason, Data)
end

function MultiplayerPage.Join(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then
		for i,server in MultiplayerPage.ServerTable do
			if (MultiplayerPage.ListServer:GetCurSel()[1]==MultiplayerPage.Item[i]) then
				Game:Connect(MultiplayerPage.Servers[i]);
				break;
			end
		end
	end
end

function MultiplayerPage.Refresh(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then
        Game:RefreshServerList();
	end
end

function MultiplayerPage.Back(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then
		local Page=GUI:GetControlPage("MainPage");
		if (Page) then
			Page:Activate();
		end
	end
end

function MultiplayerPage.Create(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then
		local Page=GUI:GetControlPage("ServerPage");
		if (Page) then
			Page:Activate();
		end
	end
end

function compare(left, right)
    return left[4]<right[4];
end

function MultiplayerPage:RefreshList()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	local Servers=Game:GetServerList();
	sort(Servers, compare);
	if (count(Servers)~=MultiplayerPage.ListServer:GetItemCount()) then    -- check this in a more robust way?
		MultiplayerPage.ListServer:Clear();
		MultiplayerPage.ServerTable=Servers;
		for i,server in MultiplayerPage.ServerTable do
			MultiplayerPage.Servers[i]=server[5];
			MultiplayerPage.Item[i]=MultiplayerPage.ListServer:AddItem(server);
		end
	--	MultiplayerPage.ListServer.SetCurSel({0});
	end
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

function MultiplayerPage:SetButtonProps(Button)
--	Button.SetFont("Digital", "default", 32, 32);
--	Button.SetColor(1, 0, 0);
	local Params={Speed=1, DstColor={r=1, g=0, b=0}}
	Button:SetEffect(XCTRLEVENT_MOUSEOVER, XCTRLEFFECT_BLINK, Params);
	Button:SetEffect(XCTRLEVENT_MOUSEOVER, XCTRLEFFECT_SOUND, nil, MainMenu.ButtonEffect, 1);
	Button:SetEffect(XCTRLEVENT_CLICK, XCTRLEFFECT_SOUND, nil, MainMenu.ButtonEffect, 1);
end

function MultiplayerPage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	MultiplayerPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(MultiplayerPage.pMouseCursor);

	Game:RefreshServerList();

	MultiplayerPage.ListServer=self:CreateListBox(10, 40, 780, 500, XLBS_LISTVIEW);
	MultiplayerPage.ListServer:AddColumn("Name", 170);
	MultiplayerPage.ListServer:AddColumn("Map", 110);
	MultiplayerPage.ListServer:AddColumn("Players", 80);
	MultiplayerPage.ListServer:AddColumn("Mod", 160);
	MultiplayerPage.ListServer:AddColumn("Ping", 50);
	MultiplayerPage.ListServer:AddColumn("IP", 140);
	MultiplayerPage.ListServer:SetCallback(MultiplayerPage.ItemSelect);

	MultiplayerPage.BtnStartGame=self:CreateButton(690, 570, 100, 20, 0, Language.Join);
	MultiplayerPage.BtnStartGame:SetCallback(MultiplayerPage.Join);
	MainPage.SetButtonProps(self, MultiplayerPage.BtnStartGame);

	MultiplayerPage.BtnRefresh=self:CreateButton(500, 570, 100, 20, 0, Language.Refresh);
	MultiplayerPage.BtnRefresh:SetCallback(MultiplayerPage.Refresh);
	MainPage.SetButtonProps(self, MultiplayerPage.BtnRefresh);

	MultiplayerPage.ServerType = self:CreateListBox(640, 10, 150, 150, XLBS_DROPDOWNLIST);
	MultiplayerPage.ServerType:SetCallback(MultiplayerPage.Callback);
	MultiplayerPage.ServerType:AddItem("LAN");
	MultiplayerPage.ServerType:AddItem("Internet");
	MultiplayerPage.ServerType:SetCurSel({0});

	MultiplayerPage:RefreshList(MultiplayerPage);

	MultiplayerPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	MultiplayerPage.BtnMainPage:SetCallback(MultiplayerPage.Back);
	MultiplayerPage.SetButtonProps(self, MultiplayerPage.BtnMainPage);

	MultiplayerPage.BtnCreate=self:CreateButton(250, 570, 150, 20, 0, "Create Server");
	MultiplayerPage.BtnCreate:SetCallback(MultiplayerPage.Create);
	MultiplayerPage.SetButtonProps(self, MultiplayerPage.BtnCreate);
	
	MultiplayerPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	MultiplayerPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, MultiplayerPage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function MultiplayerPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
	MultiplayerPage:RefreshList();
end

-------------------------------------------------------------------------
function MultiplayerPage:OnDraw()
end

-------------------------------------------------------------------------
function MultiplayerPage:OnShutdown()
end

