-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------

NewGamePage={
	StartCommand={},
	Item={},
};

function NewGamePage:GetName()
	return "NewGamePage"
end

function NewGamePage.StartGame()
	for i,leveldesc in DEFIANT do
		if (NewGamePage.ListLevel:GetCurSel()[1]==NewGamePage.Item[i]) then
			Game:SendMessage(NewGamePage.StartCommand[i]);
			break;
		end
	end
end

function NewGamePage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then
		-- check if a start-level-button was pressed...
		if (Sender==NewGamePage.BtnStartGame) then
			NewGamePage:StartGame();
		elseif (Sender==NewGamePage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage(BackPage);
			if (Page) then
				Page:Activate();
			end
		end
	end
	if (Reason==XLBN_ITEMDBLCLICK) then
		if (Sender==NewGamePage.ListLevel) then
			NewGamePage:StartGame();
		end
	end
end

function NewGamePage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	NewGamePage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(NewGamePage.pMouseCursor);

	NewGamePage.ListLevel=self:CreateListBox(10, 10, 780, 550, XLBS_LISTVIEW);
	NewGamePage.ListLevel:AddColumn("Name Of Map", 390);
	NewGamePage.ListLevel:AddColumn("Name Of Mission", 390);
	NewGamePage.ListLevel:SetCallback(NewGamePage.Callback);

	NewGamePage.BtnStartGame=self:CreateButton(690, 570, 100, 20, 0, Language.Start);
	NewGamePage.BtnStartGame:SetCallback(NewGamePage.Callback);
	MainPage.SetButtonProps(self, NewGamePage.BtnStartGame);

	for i,leveldesc in DEFIANT do
		NewGamePage.StartCommand[i]="StartLevel "..leveldesc[2].." "..leveldesc[1];
		NewGamePage.Item[i]=NewGamePage.ListLevel:AddItem({leveldesc[2], leveldesc[1]});
	end
	NewGamePage.ListLevel:SetCurSel({0});

	NewGamePage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	NewGamePage.BtnMainPage:SetCallback(NewGamePage.Callback);
	MainPage.SetButtonProps(self, NewGamePage.BtnMainPage);
	
	NewGamePage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	NewGamePage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, NewGamePage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function NewGamePage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function NewGamePage:OnDraw()
end

-------------------------------------------------------------------------
function NewGamePage:OnShutdown()
end

