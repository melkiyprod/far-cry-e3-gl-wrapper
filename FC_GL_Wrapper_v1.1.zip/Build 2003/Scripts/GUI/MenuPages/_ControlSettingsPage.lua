-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------

ControlSettingsPage={
};

function ControlSettingsPage:GetName()
	return "ControlSettingsPage"
end

function ControlSettingsPage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then

		if (Sender==ControlSettingsPage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage("OptionsPage");
			if (Page) then
				Page:Activate();
			end
		end

	end

	if (Reason==XLBN_SELCHANGE) then

		if (Sender==ControlSettingsPage.MouseSensitivity) then
			Input:SetMouseSensitivity((ControlSettingsPage.MouseSensitivity:GetCurSel()[1]+0.5)*6);
		end

		if (Sender==ControlSettingsPage.InvertMouse) then
			if (ControlSettingsPage.InvertMouse:GetCurSel()[1]==0) then
				Input:SetInvertedMouse(1);
			else
				Input:SetInvertedMouse(nil);
			end
		end

	end

	if (Reason==XLBN_ITEMDBLCLICK) then
		if (Sender==ControlSettingsPage.ListKeyBind) then -- back-button
			if (ControlSettingsPage.ListKeyBind:GetCurSel()[1]) then -- something selected ???
				local Action=ControlSettingsPage.Actions[ControlSettingsPage.ListKeyBind:GetCurSel()[1]];
				if (Action.configurable) then
					local Page=GUI:GetControlPage("WaitForKeyPage");
					if (Page) then
						Page:SetLabel(Action);
						Page:Activate(1);
					end
				end
			end
		end

	end
end

--function ControlSettingsPage.FixBindings()
--	for i, Action in ControlSettingsPage.Actions do
--		if ( Action.name == "MOVE_FORWARD" ) then
--			local Binding=Input.GetBinding("default", Action.id);
--			if (Binding[1]) then
--				Input.BindAction("RUN", Binding[1].key);
--				System.LogToConsole(Binding[1].key);
--			end
--			if (Binding[2]) then
--				Input.BindAction("RUN", Binding[2].key);
--				System.LogToConsole(Binding[2].key);
--			end
--			System.LogToConsole("rebound RUN");
--		end
--	end
-- replicate all needed actions to other actionmaps
--	local ActionMaps=Input.GetActionMaps();
--	for i, ActionMap in ActionMaps do
--		if (ActionMap~="default") then
--			for j, Action in ControlSettingsPage.Actions do
--				if (ControlSettingsPage.SyncKeysForAction[Action.name]) then
--					Input.ResetBinding(ActionMap, Action.name);
--					System.Log("Reseting binding for action "..ActionMap.." - "..Action.name);
--					local Binding=Input.GetBinding("default", Action.id);
--					if (Binding[1]) then
--						Input.BindAction(Action.name, Binding[1].key, ActionMap);
--						System.Log("Add binding for action "..ActionMap.." - "..Action.name.." = "..Binding[1].key);
--					end
--					if (Binding[2]) then
--						Input.BindAction(Action.name, Binding[2].key, ActionMap);
--						System.Log("Add binding for action "..ActionMap.." - "..Action.name.." = "..Binding[2].key);
--					end
--				end
--			end
--		end
--	end
--end

function ControlSettingsPage.AddBind(Action)
	System:Log("add bind");
	if (not Action.configurable) then
		return nil
	end
	if (not Action.actionmaps[1]) then
		return nil
	end
	local Binding=Input:GetBinding(Action.actionmaps[1], Action.id);
	local b1="";
	local b2="";
	if (Binding[1]) then
		if (Binding[1].mod) then
			b1=Binding[1].mod.." + "..Binding[1].key;
		else
			b1=Binding[1].key;
		end
	end
	if (Binding[2]) then
		if (Binding[2].mod) then
			b2=Binding[2].mod.." + "..Binding[2].key;
		else
			b2=Binding[2].key;
		end
	end
	local Maps="";
	for i, Map in Action.actionmaps do
		Maps=Maps..Map..", ";
	end
	Maps=strsub(Maps, 1, -3);
	ControlSettingsPage.ListKeyBind:AddItem({Action.desc.." $6("..Maps..")", b1, b2});
	if ((not Binding[1]) and (not Binding[2])) then
		return 2;
	end
	return 1;
end

function ControlSettingsPage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11 (see FillBindList): SetCurSel / AddItem debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	ControlSettingsPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(ControlSettingsPage.pMouseCursor);

	self:CreateStatic(75, 10, 150, 20, 0, Language.MouseSensitivity);
	ControlSettingsPage.MouseSensitivity=self:CreateListBox(275, 10, 50, 211, XLBS_DROPDOWNLIST);
	for i=1,10,1 do
		ControlSettingsPage.MouseSensitivity:AddItem(format("%02d", i), 1);
	end
	ControlSettingsPage.MouseSensitivity:SetCurSel({Input:GetMouseSensitivity()/6-0.5});
	ControlSettingsPage.MouseSensitivity:SetCallback(ControlSettingsPage.Callback);

	self:CreateStatic(475, 10, 150, 20, 0, Language.InvertMouse);
	ControlSettingsPage.InvertMouse=self:CreateListBox(675, 10, 50, 62, XLBS_DROPDOWNLIST);
	ControlSettingsPage.InvertMouse:AddItem("Yes");
	ControlSettingsPage.InvertMouse:AddItem("No");
	if (Input:GetInvertedMouse()) then
		ControlSettingsPage.InvertMouse:SetCurSel({0});
	else
		ControlSettingsPage.InvertMouse:SetCurSel({1});
	end
	ControlSettingsPage.InvertMouse:SetCallback(ControlSettingsPage.Callback);

	ControlSettingsPage.ListKeyBind=self:CreateListBox(10, 40, 780, 520, XLBS_LISTVIEW);
	ControlSettingsPage.ListKeyBind:AddColumn("Action", 490);
	ControlSettingsPage.ListKeyBind:AddColumn("Binding 1", 145);
	ControlSettingsPage.ListKeyBind:AddColumn("Binding 2", 145);
	ControlSettingsPage.ListKeyBind:SetCallback(ControlSettingsPage.Callback);

	ControlSettingsPage.WarningText=self:CreateStatic(150, 570, 650, 20, 0, "");

	ControlSettingsPage:FillBindList(ControlSettingsPage);

	ControlSettingsPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	ControlSettingsPage.BtnMainPage:SetCallback(ControlSettingsPage.Callback);
	MainPage.SetButtonProps(self, ControlSettingsPage.BtnMainPage);
	
	ControlSettingsPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	ControlSettingsPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, ControlSettingsPage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function ControlSettingsPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function ControlSettingsPage:OnDraw()
end

-------------------------------------------------------------------------
function ControlSettingsPage:OnShutdown()
	
end

-------------------------------------------------------------------------
function ControlSettingsPage:FillBindList()
	-- fix 11: CXListBox::AddItem (CryGame.dll) logs a level-1 debug line for every row added as a table
	-- ("MOVE NEXT HAPPENED IN CXLISTBOX::ADDITEM"); the log is muted only while the list is filled
	local OldVerbosity=log_Verbosity;
	if (OldVerbosity) then log_Verbosity=0; end
	ControlSettingsPage.ListKeyBind:Clear();
	ControlSettingsPage.Actions={};
	local Actions=Game:GetActions();
	local n=0;
	local NoBind=nil;
	for i, Action in Actions do
		local Ret=ControlSettingsPage.AddBind(Action);
		if (Ret) then
			ControlSettingsPage.Actions[n]=Action;
			n=n+1;
			if (Ret==2) then
				NoBind=1;
			end
		end
	end
	if (NoBind) then
		ControlSettingsPage.WarningText:SetText(Language.NoBindWarning);
	else
		ControlSettingsPage.WarningText:SetText("");
	end
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end