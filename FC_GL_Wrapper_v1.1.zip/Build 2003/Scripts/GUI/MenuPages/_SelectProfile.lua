SelectProfilePage={
};

function SelectProfilePage:GetName()
	return "SelectProfilePage"
end

function SelectProfilePage.Callback(Sender, Reason, Data)

	if (Reason == XBN_CLICK) then
		if (Sender == SelectProfilePage.BtnSelect) then
        	local sel = SelectProfilePage.ListProfiles:GetCurSel()[1];
	        sel = SelectProfilePage.ListProfiles:GetItem(sel);
	        if sel then
        	    Game:SetCurrentProfile(sel.label[1]);
	        end
			local Page=GUI:GetControlPage("MainPage");
			if (Page) then
				Page:Activate();
			end
		end

		if (Sender == SelectProfilePage.BtnBack) then
			local Page=GUI:GetControlPage("MainPage");
			if (Page) then
				Page:Activate();
			end
		end

		if (Sender == SelectProfilePage.BtnNew) then
            -- stuff
		end

	end

	if (Reason == XLBN_ITEMDBLCLICK) then
	end
end

function SelectProfilePage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end

	SelectProfilePage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(SelectProfilePage.pMouseCursor);

	SelectProfilePage.ListProfiles = self:CreateListBox(10, 40, 780, 520, XLBS_LISTVIEW);
	SelectProfilePage.ListProfiles:AddColumn("Name", 635);
	SelectProfilePage.ListProfiles:SetCallback(SelectProfilePage.Callback);

	SelectProfilePage.BtnSelect=self:CreateButton(690, 570, 100, 20, 0, "Select");
	SelectProfilePage.BtnSelect:SetCallback(SelectProfilePage.Callback);

	SelectProfilePage.BtnBack=self:CreateButton(10, 570, 100, 20, 0, Language.Cancel);
	SelectProfilePage.BtnBack:SetCallback(SelectProfilePage.Callback);

	SelectProfilePage.BtnNew=self:CreateButton(350, 570, 100, 20, 0, "New..");
	SelectProfilePage.BtnNew:SetCallback(SelectProfilePage.Callback);

	self:CreateStatic(21, 1, 100, 50, 0, "Select Profile");

	local profiles = Game:GetProfilesList();

	for i, prof in profiles do
		SelectProfilePage.ListProfiles:AddItem(prof);
		--System:Log("PROFILE: "..prof.." "..i.." "..Game:GetCurrentProfile().." "..sel);
		if prof==Game:GetCurrentProfile() then
		    SelectProfilePage.ListProfiles:SetCurSel({i});
		end
	end

	SelectProfilePage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	SelectProfilePage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, SelectProfilePage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function SelectProfilePage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function SelectProfilePage:OnDraw()
end

-------------------------------------------------------------------------
function SelectProfilePage:OnShutdown()
	SelectProfilePage=nil;
end