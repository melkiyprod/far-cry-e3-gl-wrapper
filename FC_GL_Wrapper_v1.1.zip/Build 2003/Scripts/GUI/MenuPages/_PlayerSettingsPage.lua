-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------

PlayerSettingsPage={
};

function PlayerSettingsPage:GetName()
	return "PlayerSettingsPage"
end

function PlayerSettingsPage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then

		if (Sender==PlayerSettingsPage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage("OptionsPage");
			if (Page) then
				Page:Activate();
			end
		end

	end

	if (Reason==XLBN_SELCHANGE) then

		if (Sender==PlayerSettingsPage.Model) then
			local idx=PlayerSettingsPage.Model:GetCurSel()[1];
			if (idx) then
--				local model=PlayerSettingsPage.ModelTable[idx];
--				PlayerSettingsPage.ModelView.SetModelViewParams(2.5, 0.1, {x=0, y=0, z=-0.9}, "swalkfwd_loop", "OBJECTS/characters/pmodels/"..model.."/"..model..".cgf");
				p_model=PlayerSettingsPage.ModelTable[idx];
				PlayerSettingsPage.ModelView:SetModelViewParams(2.5, 0.1, {x=0, y=0, z=-0.9}, "swalkfwd_loop", "OBJECTS/characters/pmodels/"..p_model.."/"..p_model..".cgf");
			end
		end

	elseif (Reason==XEBN_TEXTCHANGE) then

		if (Sender==PlayerSettingsPage.EditPlayerName) then
			p_name=PlayerSettingsPage.EditPlayerName:GetText();
		end

	end
end

function PlayerSettingsPage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	PlayerSettingsPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(PlayerSettingsPage.pMouseCursor);

	PlayerSettingsPage.ModelView=self:CreateStatic(450, 0, 350, 600, XSS_MODELVIEW, "");

	self:CreateStatic(125, 184, 100, 20, 0, Language.PlayerModel);
	PlayerSettingsPage.Model=self:CreateListBox(275, 184, 170, 229, XLBS_DROPDOWNLIST);
	PlayerSettingsPage.ModelTable=System:ScanDirectory("OBJECTS/characters/pmodels");
	PlayerSettingsPage.Model:SetCallback(PlayerSettingsPage.Callback);
	local ModelSelected=0;
	for i,foldername in PlayerSettingsPage.ModelTable do
		local id=PlayerSettingsPage.Model:AddItem(foldername, 1);
		if ( foldername==p_model ) then
			PlayerSettingsPage.Model:SetCurSel({id});
			ModelSelected=1;
		end
	end
	if ( ModelSelected==0 ) then
		PlayerSettingsPage.Model:SetCurSel({0});
	end

	if ( Game.IsClient() ) then
		PlayerSettingsPage.Model:Enable( nil );
	end


	self.CreateStatic(125, 224, 100, 20, 0, Language.PlayerName);
	PlayerSettingsPage.EditPlayerName=self:CreateEditBox(275, 224, 170, 20);
	PlayerSettingsPage.EditPlayerName:SetText(p_name);
	PlayerSettingsPage.EditPlayerName:SetCallback(PlayerSettingsPage.Callback);

	PlayerSettingsPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	PlayerSettingsPage.BtnMainPage:SetCallback(PlayerSettingsPage.Callback);
	MainPage.SetButtonProps(self, PlayerSettingsPage.BtnMainPage);
	
	PlayerSettingsPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	PlayerSettingsPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, PlayerSettingsPage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function PlayerSettingsPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function PlayerSettingsPage:OnDraw()
end

-------------------------------------------------------------------------
function PlayerSettingsPage:OnShutdown()
end

