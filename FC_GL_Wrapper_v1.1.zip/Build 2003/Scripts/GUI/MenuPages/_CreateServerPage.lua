-------------------------------------------------------------------------
--	MenuPage Script Code
--
--	Created by Lennert Schneider
--
--  Copyright (C) 2002 Crytek Studios Inc.
-------------------------------------------------------------------------

CreateServerPage={
	LevelTable={},
	StartCommand={},
	Item={},
};

function CreateServerPage:GetName()
	return "CreateServerPage"
end

function CreateServerPage.StartGame()
	for i,foldername in CreateServerPage.LevelTable do
		if (CreateServerPage.ListLevel:GetCurSel()[1]==CreateServerPage.Item[i]) then
			Game:SendMessage(CreateServerPage.StartCommand[i]);
			--Game:LoadLevelListen(CreateServerPage.StartCommand[i]);
			break;
		end
	end
end

function CreateServerPage.Callback(Sender, Reason, Data)
	if (Reason==XBN_CLICK) then
		-- check if the start-level-button was pressed...
		if (Sender==CreateServerPage.BtnStartGame) then
			CreateServerPage:StartGame();
		elseif (Sender==CreateServerPage.BtnMainPage) then -- back-button
			local Page=GUI:GetControlPage("ServerPage");
			if (Page) then
				Page:Activate();
			end
		end
	end
	if (Reason==XLBN_ITEMDBLCLICK) then
		if (Sender==CreateServerPage.ListLevel) then
			CreateServerPage:StartGame();
		end
	end
end

function CreateServerPage:OnInit()
	local OldVerbosity=log_Verbosity;	-- fix 11: CXListBox::SetCurSel / AddItem (CryGame.dll) debug lines muted
	if (OldVerbosity) then log_Verbosity=0; end
	CreateServerPage.pMouseCursor=System:LoadImage("textures/GUI/mousecursor.tga");
	self:SetCursor(CreateServerPage.pMouseCursor);

	CreateServerPage.ListLevel=self:CreateListBox(10, 10, 780, 550, XLBS_LISTVIEW);
	CreateServerPage.ListLevel:AddColumn("Name Of Map", 200);
	CreateServerPage.ListLevel:SetCallback(CreateServerPage.Callback);

	CreateServerPage.BtnStartGame=self:CreateButton(690, 570, 100, 20, 0, Language.Start);
	CreateServerPage.BtnStartGame:SetCallback(CreateServerPage.Callback);
	MainPage.SetButtonProps(self, CreateServerPage.BtnStartGame);

	CreateServerPage.LevelTable=System:ScanDirectory("Levels");
	for i,foldername in CreateServerPage.LevelTable do
		CreateServerPage.StartCommand[i]="StartLevel "..foldername.." listen";
		CreateServerPage.Item[i]=CreateServerPage.ListLevel:AddItem({foldername});
	end
	CreateServerPage.ListLevel:SetCurSel({0});

	CreateServerPage.BtnMainPage=self:CreateButton(10, 570, 100, 20, 0, Language.Back);
	CreateServerPage.BtnMainPage:SetCallback(CreateServerPage.Callback);
	MainPage.SetButtonProps(self, CreateServerPage.BtnMainPage);
	
	CreateServerPage.BackgndTex=System:LoadImage("Textures/gui/menuback");
	CreateServerPage.Backgnd=self:CreateStatic(0, 0, 800, 600, XSS_IMAGE, CreateServerPage.BackgndTex);
	if (OldVerbosity) then log_Verbosity=OldVerbosity; end
end

-------------------------------------------------------------------------
function CreateServerPage:OnUpdate(nMouseX, nMouseY, nMouseState, pData)
end

-------------------------------------------------------------------------
function CreateServerPage:OnDraw()
end

-------------------------------------------------------------------------
function CreateServerPage:OnShutdown()
end

