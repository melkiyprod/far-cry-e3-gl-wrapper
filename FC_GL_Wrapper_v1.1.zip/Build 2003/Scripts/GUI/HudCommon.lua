Hud={
	
	color={r=1.66,g=0.8,b=0.8},
	color_red={1, 0.3, 0.3,1},
	color_blue={0.1 ,0.6,0.75,1},
	color_yellow={1,1,0,1},
	color_white={1,1,1,1},
	
	dmgindicator=0,
	dmgfront=0,
	dmgback=0,
	dmgleft=0,
	dmgright=0,
	sound_scale=1,
	hit=0,
	
	messages={},
	grenade_blink=0,
	deafness_fadeout_time=5, -- lennert
	breathlevel=-1,			 -- marco

	blindingFade = 1,		 -- kirill
}

-----------------------------------------------------------------------------
function Hud:AddMessage(text,_lifetime)
	if(not _lifetime)then _lifetime=5; end
	if(count(self.messages)>=4)then
		for i,val in self.messages do
			self.messages[i]=self.messages[i+1];
			self.messages[i+1]=nil
		end
	end
	self.messages[getn(self.messages)+1]={time=_time,text=text,lifetime=_lifetime}
end
-----------------------------------------------------------------------------
function Hud:AddCenterMessage(text,time)
	self.centermessage=text;
	if(time)then
		self.centermessagetime=time;
	else
		self.centermessagetime=1;
	end
end

function Hud:InitTexTable(tt)
	local tw,th=511,255;
	for i,val in tt do
		val.size={}
		val.size.w=val[3];
		val.size.h=val[4];
		val[1]=val[1]/tw;
		val[2]=val[2]/th;
		val[3]=val[1]+(val[3]/tw);
		val[4]=val[2]+(val[4]/th);
	end
end

function merge_no_copy(dest,source)
	for i,val in source do
		if(type(dest[i])==type(val))then
			if(type(dest[i])~="table")then
				dest[i]=val;
			else
				merge_no_copy(dest[i],val);
			end
		end
	end
end
-----------------------------------------------------------------------------
function Hud:CommonInit()
	Game:CreateVariable("hud_damageindicator",1);
	
	--IMAGES--------------------------------------------------------
	self.damageindicator={
		front=System:LoadImage("Textures/Hud/new/damage/MiddleUp"),
		back=System:LoadImage("Textures/Hud/new/damage/MiddleDown"),
		left=System:LoadImage("Textures/Hud/new/damage/MiddleLeft"),
		right=System:LoadImage("Textures/Hud/new/damage/MiddleRight"),
	}

	self.meleedamageindicator={
		System:LoadImage("Textures/decal/player_blood1.dds"),
		System:LoadImage("Textures/decal/player_blood2.dds"),
		System:LoadImage("Textures/decal/player_blood3.dds"),
	}

	self.soundwave=System:LoadImage("Textures/Hud/new/AimSoundwaves.tga");
	
	self.damage_icon_lr=System:LoadImage("Textures/hud/new/DamageIndicatorHorz.tga");
	self.damage_icon_ud=System:LoadImage("Textures/hud/new/DamageIndicatorVert.tga");
	
	self.missioncheckbox=System:LoadImage("Textures/Hud/new/MissionBoxCheckbox.tga");
	self.missioncheckboxcomp=System:LoadImage("Textures/Hud/new/MissionCheckboxComp.tga");
	self.missionboxframe=System:LoadImage("Textures/Hud/new/MissionBoxFrame.tga");
	self.radimessageicon=System:LoadImage("Textures/Hud/new/RadiomessageIcon.tga");
	self.white_dot=System:LoadImage("Textures/hud/white_dot.tga");
	self.black_dot=System:LoadImage("Textures/hud/black_dot.tga");
	self.blue=System:LoadImage("Textures/hud/blue.dds");

--	self.flashlight_blinding=System:LoadImage("Textures/flight");
	self.flashlight_blinding=System:LoadImage("Textures/fl");	

	self.KeyItem=System:LoadImage("Textures/hud/keyItem.dds");
	self.ExploItem=System:LoadImage("Textures/hud/ExpItem.dds");

	--self.breathOmeter=System:LoadImage("Textures/hud/BreathOMeter.dds");
	self.underbreathvalue=1;
	
	self.SneakBar=System:LoadImage("Textures/hud/SneakBar.tga");
	self.RadarMask=System:LoadImage("Textures/hud/RadarMask.tga");
	self.RadarPlayerIcon=System:LoadImage("Textures/hud/RadarPlayerIcon.tga");
	self.RadarSoundIcon=System:LoadImage("Textures/hud/RadarSoundIcon.tga");
	
	------------------------------------------------------------------------------------
	------------------------------------------------------------------------------------
	--NEW HUD
	------------------------------------------------------------------------------------
	------------------------------------------------------------------------------------
	local path="Textures/hud/";
	
	self.rend=Game:CreateRenderer();
	
	self.tx_hud=System:LoadImage(path.."hud.tga");
	
	self.txi={
		shape_bar={266,0,82,36},
		shape_grenade={444,32,48,47},
		white_dot={400,20,4,4},
		health_bar={302,201,209,53},
		health_inside={367,13,135,18},
		radar={276,70,136,116},
		oxygen_frame={484,83,18,86},
		SOMFrame={304, 208, 134, 16}
	}
	
	
	self.tnum={
		[0]={7,242,12,12},
		[1]={25,242,12,12},
		[2]={43,242,12,12},
		[3]={65,242,12,12},
		[4]={87,242,12,12},
		[5]={109,242,12,12},
		[6]={131,242,12,12},
		[7]={153,242,12,12},
		[8]={174,242,12,12},
		[9]={196,242,12,12},
	}
	
	self.tweapons={
		Machete={2,42,67,34},
		AW50={3,82,67,34},
		M4={3,122,67,34},
		DE={3,161,67,34},
		--RL={75,82,67,34},
		MP5={74,122,67,34},
		Shocker={3,2,67,34},
		AG36={3,202,67,34},
		Pancor={185,160,67,34},
		P90={185,120,67,34},
		OICW={184,81,67,34},
		RL={185,42,67,34},
		M249={185,1,67,34},
	}
	
	self.tgrenades={
		Rock={131,196,22,35}, --<<FIXME>>
		HandGrenade={185,195,22,35},
		SmokeGrenade={161,195,22,35},
		FlareGrenade={0,0,1,1}, --<<FIXME>>
		FlashbangGrenade={0,0,1,1}, --<<FIXME>>
		GlowStick={0,0,1,1}, --<<FIXME>>
	}
	
	self.weapons_firmodes={
		Machete={"melee"},
		AW50={"single"},
		M4={"auto","single"},
		DE={"single"},
		RL={"rocket"},
		MP5={"auto","single"},
		Shocker={"melee"},
		AG36={"single","grenade"},
		
	}
	
	self.wicons={
		melee={157,73,20,14},
		auto={161,37,13,21},
		single={161,12,13,7},
		grenade={161,104,12,17},
		rocket={162,131,9,26},
	}
	
	self.scoreboard={
		background={312,96,8,8},
		corner ={436,81,33,33},
	}
	
	self.tempUV={};
	
	self.bars={
	}
	
	self:InitTexTable(self.txi);
	self:InitTexTable(self.tnum);
	self:InitTexTable(self.tweapons);
	self:InitTexTable(self.wicons);
	self:InitTexTable(self.tgrenades);
	self:InitTexTable(self.scoreboard);
	
	self.temp_txinfo=new(self.txi.health_inside);
	self.weapons_alpha=1;
	------------------------------------------------------------------------------------
	------------------------------------------------------------------------------------
	--<<END>> NEW HUD
	------------------------------------------------------------------------------------
	------------------------------------------------------------------------------------
	
	self.blindnessvalue=-1;	-- to make the player blind when a lightning strikes
	self.meleedamagefade=-1;	-- draw a blood smear fading on the screen
	self.bloodsmearimage=nil;

	self.blinding = 0;
	
	System:Log("self.damage_icon_lr="..type(self.damage_icon_lr));
	Game:CreateVariable("hud_panoramic",0);
	Game:CreateVariable("hud_panoramic_height",100);
	Game:CreateVariable("hud_crosshair",1);
	
	self.EarRinging=Sound:LoadSound("Sounds/Player/deafnessLP.wav");
	Sound:SetSoundLoop(self.EarRinging, 1);
	Sound:RemoveFromScaleGroup(self.EarRinging, SOUNDSCALE_DEAFNESS);

	local sx=5;
	local sy=395;
	local sw=108;
	local sh=108/2;
	local s={
		{x=sx+1,y=sy,u=0,v=0},
		{x=sx+1,y=sy+sh,u=0,v=1},
		{x=sx+sw/2,y=sy,u=0.5,v=0},
		{x=sx+sw/2,y=sy+sh,u=0.5,v=1},
		{x=sx+sw-1,y=sy,u=1,v=0},
		{x=sx+sw-1,y=sy+sh,u=1,v=1},
	}
	local h={
		{x=11+1,y=525,u=0,v=0},
		{x=10+1,y=557,u=0,v=0.5},
		{x=42,y=525,u=0.5,v=0},
		{x=42,y=557,u=0.5,v=0.5},
		{x=74-1,y=525,u=1,v=0},
		{x=74-1,y=557,u=1,v=0.5},
	}
	local a={
		{x=10+1,y=557,u=0,v=0.5},
		{x=10+1,y=589,u=0,v=1},
		{x=42,y=557,u=0.5,v=0.5},
		{x=42,y=589,u=0.5,v=1},
		{x=74-1,y=557,u=1,v=0.5},
		{x=74-1,y=589,u=1,v=1},
	}
	
	ScoreBoardManager.SetVisible(0);
end

function Hud:DrawElement(x,y,element,r,g,b,a)
	self.rend:PushQuad(x,y,element.size.w,element.size.h,element,r,g,b,a);
end
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
--[marco]--------------------------------------------------------------------
function Hud:DrawItems(player)

	local x=254;
	local y=566-40;
	for i,val in player.keycards do			
		if (val==1) then
			%System:DrawImageColor(self.greyrectsmall, x, y, 72, 30, 4,1,1,1,0.4);
			%System:DrawImageColor(self.KeyItem, x+15,y+5, 47, 21, 4,1,1,1,1);		

			--number
			--%System:DrawImageColor(self.weaponnr[i],x+3,y+3,12,12,4,1,1,1,0.4);

			x=x+(72+4);
		end
	end

	for i,val in player.explosives do			
		if (val==1) then
			%System:DrawImageColor(self.greyrectsmall, x, y, 72, 30, 4,1,1,1,0.4);		
			%System:DrawImageColor(self.ExploItem, x+15,y+5, 47, 21, 4,1,1,1,1);		
			x=x+(72+4);
		end
	end
end

function Hud:DrawLabel()
	if(self.label)then
		%Game:WriteHudStringFixed(111,427,self.label,self.color.r, self.color.g, self.color.b, 1, 20,20,0.33 );
	end
	self.label=nil;
end
-----------------------------------------------------------------------------
function Hud:DrawAmmo(player)
	%System:DrawImage(self.greyrectsmall, 700, 566, 98, 30, 4);
	local ammo=999;
	if(player.cnt.ammo<999)then ammo=player.cnt.ammo end
	
	if(player.cnt.ammo_in_clip>0 and ammo<=0)then
		%Game:WriteHudStringFixed(700,562, format("%03i/%03i",player.cnt.ammo_in_clip,ammo), 1, 0, 0, 0.7, 35,37,0.33);
	elseif(player.cnt.ammo_in_clip>0 and ammo>0)then
		%Game:WriteHudStringFixed(700,562, format("%03i/%03i",player.cnt.ammo_in_clip,ammo), self.color.r, self.color.g, self.color.b, 0.7, 35,37,0.33);
	else
		%Game:WriteHudStringFixed(700,562, "---/---", self.color.r, self.color.g, self.color.b, 0.7, 35,37,0.33);
	end
end

function Hud:DrawNumber(ndigits,x,y,number,r,g,b,a)
	if(number>999)then number=999; end
	local t=mod(number,100);
	local unit=mod(number,10);
	local hun=(number-t)/100;
	local dec=(t-unit)/10;
	if(ndigits>=3)then
		self:DrawElement(x, y,self.tnum[hun],r,g,b,a);
		x=x+12;
	end
	if(ndigits>=2)then
		self:DrawElement(x, y,self.tnum[dec],r,g,b,a);
		x=x+12;
	end
	self:DrawElement(x, y,self.tnum[unit],r,g,b,a);
	
end


function Hud:DrawAmmo(player)
	
	--health gauge
	
	local health=(player.cnt.health/GameRules.InitialPlayerStats.health)*100;
	local armor=(player.cnt.armor/player.cnt.max_armor)*100;
	self:DrawGauge(592, 549,health,self.txi.health_inside,0.2,0.9,0.3,0.5)
	
	self:DrawGauge(592,568,armor,self.txi.health_inside,0.7,0.9,1,0.5,1)
	local w=player.cnt.weapon;
	local critical_ammo_count=0;
	if(player.fireparams and player.fireparams.bullets_per_clip)then
		critical_ammo_count=(player.fireparams.bullets_per_clip*0.3)
	end
	
	
	self:DrawElement(588, 542,self.txi.health_bar);
		local ammo=999;
	
	if(player.fireparams and player.fireparams.AmmoType~="Unlimited")then	
		if(player.cnt.ammo<999)then ammo=player.cnt.ammo end
		--System:Log("critical_ammo_count="..critical_ammo_count)
		if(player.cnt.ammo_in_clip<=critical_ammo_count)then
			--%Game:WriteHudStringFixed(700,562, format("%03i/%03i",player.cnt.ammo_in_clip,ammo), 1, 0, 0, 0.7, 35,37,0.33);
			
			self:DrawNumber(3,735,553,player.cnt.ammo_in_clip,1,0,0,1);
			self:DrawNumber(3,735,573,player.cnt.ammo);
		elseif(player.cnt.ammo_in_clip>0 and ammo>0)then
			self:DrawNumber(3,735,553,player.cnt.ammo_in_clip);
			self:DrawNumber(3,735,573,player.cnt.ammo);
			--%Game:WriteHudStringFixed(700,562, format("%03i/%03i",player.cnt.ammo_in_clip,ammo), self.color.r, self.color.g, self.color.b, 0.7, 35,37,0.33);
		else
			self:DrawNumber(3,735,553,player.cnt.ammo_in_clip);
			self:DrawNumber(3,735,573,ammo);
		end
	end
end
-----------------------------------------------------------------------------
function Hud:SetRadarRange(Range)
	self.DestinationRadarRange=Range;
end
-----------------------------------------------------------------------------^
function Hud:DrawRadar(x,y,w,h)
	--local RadarSize={x=10, y=400, w=100, h=100};
	if (_localplayer==nil) then
		return
	end
	-- indoor/outdoor ?
	if (System:IsPointIndoors(_localplayer:GetPos())) then
		Hud:SetRadarRange(tonumber(g_RadarRangeIndoor));
	else
		Hud:SetRadarRange(tonumber(g_RadarRangeOutdoor));
	end
	-- adjust range
	if (self.DestinationRadarRange and (tonumber(self.DestinationRadarRange)~=tonumber(g_RadarRange)) and (_frametime<1) and (tonumber(g_RadarRangeChangeSpeed)>0)) then
		g_RadarRange=tonumber(g_RadarRange)+(tonumber(self.DestinationRadarRange)-tonumber(g_RadarRange))*_frametime*tonumber(g_RadarRangeChangeSpeed);
		g_SuspenseRange=g_RadarRange;
	end
	-- draw stuff
	local SuspenseRange2=tonumber(g_SuspenseRange)*tonumber(g_SuspenseRange);
	local NearSuspenseRange2=SuspenseRange2*tonumber(g_NearSuspenseRangeFactor)*tonumber(g_NearSuspenseRangeFactor);
	local EnemyInSuspense=0;
	local EnemyInNearSuspense=0;
	local tblPlayers=Game:GetPlayerEntitiesInRadius(_localplayer:GetPos(), tonumber(g_RadarRange));
	if (tblPlayers) then
		for i, Player in tblPlayers do
			if (Player.pEntity and Player.pEntity.cnt and Player.pEntity.cnt.health and Player.pEntity.cnt.health>0) then
				if (Player.pEntity==_localplayer) then
					Player.Color={r=0.0, g=0.9, b=0.8, a=1.0};
				else
					if (Player.fDistance2<SuspenseRange2) then
						EnemyInSuspense=1;
					end
					if (Player.fDistance2<NearSuspenseRange2) then
						EnemyInNearSuspense=1;
					end
					local Target=AI:GetAttentionTargetOf(Player.pEntity.id);
					local TargetType=type(Target);
					if ((TargetType=="table") and (Target==_localplayer)) then
						Player.Color={r=0.8, g=0.4, b=0.4, a=1.0};	-- combat
						Player.pEntity.bShowOnRadar=1;
					elseif (TargetType=="number") and (Target==AIOBJECT_DUMMY) then
						Player.Color={r=0.8, g=0.7, b=0.1, a=1.0};	-- threatened
						Player.pEntity.bShowOnRadar=1;
					elseif (Player.pEntity.bShowOnRadar) then
						Player.Color={r=0.0, g=1.0, b=0.0, a=1.0};	-- idle
					else
						tblPlayers[i]=nil;
					end
				end
			else
				tblPlayers[i]=nil;
			end
		end
		Game:DrawRadar(x, y, w, h, tonumber(g_RadarRange), self.RadarMask, self.RadarPlayerIcon, self.RadarSoundIcon, tblPlayers);
		if (EnemyInNearSuspense~=0) then	-- if the AI is very near we send a NEAR-mood event
			Sound:AddMusicMoodEvent("NearSuspense", MM_NEARSUSPENSE_TIMEOUT);
		elseif (EnemyInSuspense~=0) then	-- if the AI is near we send a SUSPENSE-mood event
			Sound:AddMusicMoodEvent("Suspense", MM_SUSPENSE_TIMEOUT);
		end
	end
	
--	Game:DrawHalfCircleGauge(5, 395, 108, 108/2, 0, 0, 1, 1, self.SneakBar, Sneak);
--	Sneak=Sneak/100;
--	%System:DrawImageCoords(self.SneakBar, 10, 380, 100*Sneak, 20, 4, 0, 1, Sneak, 0);
	-- temporary (should be moved in c++ i guess...)
end
-----------------------------------------------------------------------------

function Hud:DrawRadarLayout(x,y)
	
	local color=self.color_blue;
	-- sneak-o-meter
	local Sneak=AI:GetPerception();
	if (Sneak<5) then
		Sneak=Sneak*10;
	elseif (Sneak<10) then
		Sneak=((Sneak-5)/5)*25+50;
		color=self.color_yellow;
	elseif (Sneak>110) then
		Sneak=100;
		color=self.color_red;
	else
		Sneak=75;
		color=self.color_red;
	end
	
	self:DrawVBar(x+120,y+17,12,88,Sneak,self.txi.white_dot,color[1],color[2],color[3],0.7);
	self:DrawElement(x, y, self.txi.radar);
	--self:DrawGauge(x+2, y-20,100-Sneak,self.txi.health_inside,color[1],color[2],color[3],0.7);
	--self:DrawElement(x, y-20, self.txi.SOMFrame);
end

-----------------------------------------------------------------------------
function Hud:DrawGauge(x,y,val,texi,r,g,b,a,flipv)
	local t=self.temp_txinfo;
	merge_no_copy(t,texi);
	texi=t;
	local scale=(val/100);
	-- fix 12: the original limited the share (0..1) to 100, so health / armor over 100 % drew the gauge up to many
	-- times wider, moved left and with its texture repeated - "doubled" health and armor bars along the bottom
	if(scale>1)then scale=1; end
	if(scale<0)then scale=0; end
	local diff=1-scale;
	if(diff~=0)then
		local uoffs=abs(texi[3]-texi[1])*diff;
		texi[1]=texi[1]+uoffs;
		local worig=texi.size.w;
		texi.size.w=(worig*scale);
		x=x+(worig*diff);
	end
	if(flipv)then
		texi[2],texi[4]=texi[4],texi[2];
	end
	self:DrawElement(x,y,texi,r,g,b,a);
end

function Hud:DrawVBar(x,y,w,h,val,texi,r,g,b,a)
	local realh=h*(val/100);
	local realy=y+(h-realh);
	self.rend:PushQuad(x,realy,w,realh,texi,r,g,b,a);	
end

-----------------------------------------------------------------------------
function Hud:DrawCrosshair(player)
	if(tonumber(hud_damageindicator)~=0)then
		if(self.dmgindicator)then
			if ( band( self.dmgindicator, 4 ) > 0 ) then
				self.dmgfront=0.5;
			end
			if ( band( self.dmgindicator, 8 ) > 0 ) then
				self.dmgback=0.5;
			end
			if ( band( self.dmgindicator, 1 ) > 0 ) then
				self.dmgleft=0.5;
			end
			if ( band( self.dmgindicator, 2 ) > 0 ) then
				self.dmgright=0.5;
			end
		end
		
		if(self.dmgfront>0)then
			%System:DrawImageColorCoords(self.damage_icon_ud,350,100,100,12,4,0.8,0,0,0.8,1,1,0,0);
			self.dmgfront=self.dmgfront-_frametime;
			if(self.dmgfront<0) then self.dmgfront=0 end
		end
	
		if(self.dmgback>0)then
			%System:DrawImageColorCoords(self.damage_icon_ud,350,420,100,12,4,0.8,0,0,0.8,0,0,1,1);
			self.dmgback=self.dmgback-_frametime;
			if(self.dmgback<0) then self.dmgback=0 end
		end
			
		if(self.dmgleft>0)then
			%System:DrawImageColorCoords(self.damage_icon_lr,100,250,12,100,4,0.8,0,0,0.8,1,0,0,1);	
			self.dmgleft=self.dmgleft-_frametime;
			if(self.dmgleft<0) then self.dmgleft=0 end
		end
		
		if(self.dmgright>0)then
			%System:DrawImageColorCoords(self.damage_icon_lr,688,250,12,100,4,0.8,0,0,0.8,0,0,1,1);	
			self.dmgright=self.dmgright-_frametime;
			if(self.dmgright<0) then self.dmgright=0 end
		end
		
		self.dmgindicator=0;
		local w=player.cnt.weapon;
		if(w)then
			w.Client.OnEnhanceHUD(w,Hud.hit);
			Hud.hit=Hud.hit-1;
		end
		
		local soundEvents=Client:GetSoundsEventsPos();
		if(soundEvents.front>0 and self.dmgfront<=0)then
			%System:DrawImageColorCoords(self.damage_icon_ud,350,100,100,12,4,0.8,0.8,0,0.8,1,1,0,0);
		end
		if(soundEvents.back>0 and self.dmgback<=0)then
			%System:DrawImageColorCoords(self.damage_icon_ud,350,420,100,12,4,0.8,0.8,0,0.8,0,0,1,1);
		end
		if(soundEvents.left>0 and self.dmgleft<=0)then
			%System:DrawImageColorCoords(self.damage_icon_lr,100,250,12,100,4,0.8,0.8,0,0.8,1,0,0,1);
		end
		if(soundEvents.right>0 and self.dmgright<=0)then
			%System:DrawImageColorCoords(self.damage_icon_lr,688,250,12,100,4,0.8,0.8,0,0.8,0,0,1,1);
		end
	end
end

-----------------------------------------------------------------------------
function dotproduct3d(a,b)
   return (a.x * b.x) + (a.y * b.y) + (a.z * b.z);
end

function LogVec(name,v)
	return format("%s = (%f %f %f)",name,v.x,v.y,v.z);
end
-----------------------------------------------------------------------------
function Hud:DrawCompass(player)
	do return end
	local waypoint = System:GetEntityByName("Checkpoint0");
	
	local height=10;
	%System:DrawImage(self.compassrect, 249, 9, 302, height, 4);
	local u=(-player:GetAngles().z+217)/360+0.27;
	%System:DrawImageCoords( self.compassletters, 249, 9, 302, height, 4,  u-0.25, 1, u+0.25, 0 );
	if(waypoint)then
		local wpos=new(waypoint:GetPos());
		wpos.z=0;
		local ppos=new(player:GetPos());
		ppos.z=0;
		local pang=new(player:GetAngles());
		pang.z=pang.z+90;
		pang.x=0;
		pang.y=0;
		local diff=DifferenceVectors(wpos,ppos);
		
		local dot,arcos,x;
		ConvertToRadAngles(pang,pang);
		NormalizeVector(diff);
		NormalizeVector(pang);
		dot=dotproduct3d(diff,pang);
		
		
		if(dot>0.5)then
			dot=0.5;
		elseif(dot<-0.5)then
			dot=-0.5;
		end
		x=(249+151)-(dot*302);
		
		%System:DrawImage(self.compasstarget, x, 9, 3, height, 4);
		--System:LogToConsole("AFTER dot="..dot.." x="..x);
	end
end
a=0;
-----------------------------------------------------------------------------
-- this function can be drastically optimized
function Hud:DrawHealthBar(health,armor)
	local size=64;
	local hsize=size/2;
	%System:DrawImage(self.healthgraycircle, 10, 525, size, size, 4);
	local pt,mult;

	-- [marco] limit to 100 when we draw the strip
	if (health>100) then
		health=100;
	end

	if(health) then
		if(health>50)then
			Game:DrawHalfCircleGauge(10, 525, 64, 32, 0, 0, 1, 0.5, self.healthbar, health, 0.4, 0.83, 0, 1);
		elseif (health>25)then
			Game:DrawHalfCircleGauge(10, 525, 64, 32, 0, 0, 1, 0.5, self.healthbar, health, 1, 1, 0, 1);
		elseif (health>0)then
			Game:DrawHalfCircleGauge(10, 525, 64, 32, 0, 0, 1, 0.5, self.healthbar, health, 0.7, 0, 0, 1);
		end
	end
	if(armor)then
		Game:DrawHalfCircleGauge(10, 557+32, 64, -32, 0, 1, 1, -0.5, self.healthbar, armor, 0, 0, 1, 1);
	end
	
end
-----------------------------------------------------------------------------
function Hud:DrawHealthBar(health,armor)
	--<<TODO>>
end
-----------------------------------------------------------------------------
function Hud:DrawVehicleBar(health)
--	%System:Log("DrawVehicleBar("..health..")");
	%System:DrawImage(self.vehiclerect, 125, 419, 20, 60, 4);
	%System:DrawImageCoords(self.vehiclebar, 125, 419+(60*(1-health)), 20, 60*health, 4,0,1-health,1,1);
end
-----------------------------------------------------------------------------
function Hud:MissionBox()
	-- TAB screen: list of mission objectives (Hud.objectives, filled by Hud:PushObjective)
	-- Frame/background are batched quads. ScoreBoardManager:Render() runs AFTER Hud:FlushCommon()
	-- in Hud:OnUpdate(), so we must flush here ourselves or the frame would never be drawn.
	self:DrawFrameBox(150, 100, 500, 200);
	self:FlushCommon();
	local y=135;
	local i;
	-- numeric loop on purpose: "for i,val in t" gives no ordering guarantee in Lua 4
	for i=1,getn(self.objectives) do
		local val=self.objectives[i];
		if(val)then
			if(not val.completed)then
				%System:DrawImageColor(self.missioncheckbox, 158, y, 16, 16, 4,1,1,1,1);
				%Game:WriteHudStringFixed(178, y-3, val.text, self.color.r, self.color.g, self.color.b,1, 25,25,0.33);
			else
				%System:DrawImageColor(self.missioncheckboxcomp, 158, y, 16, 16, 4,0.5,0.5,0.5,1);
				%Game:WriteHudStringFixed(178, y-3, val.text, self.color.r, self.color.g, self.color.b,0.5, 25,25,0.33);
			end
			y=y+35;
		end
	end
end

function Hud:DrawFrameBox(x,y,w,h)
	local uv=self.tempUV;
	local bkx,bky,bkw,bkh=x, y, w, h;
	local ouv=self.scoreboard.corner;
	local cw,ch=self.scoreboard.corner.size.w,self.scoreboard.corner.size.h;
	local ctickness=5;
	self.rend:PushQuad(bkx,bky,bkw,bkh ,self.scoreboard.background);
	--copy right/up
	uv[1],uv[2],uv[3],uv[4]=ouv[1],ouv[2],ouv[3],ouv[4];
	self.rend:PushQuad(((bkx+bkw)-cw)+ctickness,bky-ctickness,cw,ch,uv);
	--flip right/down
	uv[2],uv[4]=ouv[4],ouv[2];
	self.rend:PushQuad(((bkx+bkw)-cw)+ctickness,((bky+bkh)-ch)+ctickness,cw,ch,uv);
	--flip left/down
	uv[1],uv[2],uv[3],uv[4]=ouv[3],ouv[4],ouv[1],ouv[2];
	self.rend:PushQuad(bkx-ctickness,((bky+bkh)-ch)+ctickness,cw,ch,uv);
	--flip left/up
	uv[1],uv[3]=ouv[3],ouv[1];
	uv[2],uv[4]=ouv[2],ouv[4];
	self.rend:PushQuad(bkx-ctickness,bky-ctickness,cw,ch,uv);

end
-----------------------------------------------------------------------------
function Hud:MessagesBox(spacing)
	if(not spacing)then
		spacing=0.33
	end
	local n=count(self.messages);
	if(n>0)then
		self:DrawFrameBox(121+30, 440, 514, 15+(20*n));
		--%System:DrawImage(self.compassrect, 111, 447, 514, 10+(20*n), 4);
		local y=455;
		for i,msg in self.messages do
			%Game:WriteHudStringFixed(157+30, (y-2)-7, msg.text, self.color.r, self.color.g, self.color.b,1, 20,20,spacing);
			%System:DrawImage(self.radimessageicon,127+30,y-7,26,14,4);
			y=y+20;
			if(_time-msg.time>msg.lifetime)then
				self.messages[i]=nil;
			end
		end
	end
end
px=250
-----------------------------------------------------------------------------
function Hud:DrawWeaponSlots(player)
--THIS IS THE NEW ONE
local weapons=player.cnt:GetWeaponsSlots();
	local currweapon=player.cnt.weapon;
	local x,y=px,552;
	local alpha_scale=Hud.weapons_alpha;
	if(self.weapons_alpha>0)then
		self.weapons_alpha=self.weapons_alpha-(_frametime*0.5);
	end
	for i,val in weapons do
		if(val~=currweapon)then
			if(alpha_scale>0)then
				self:DrawWeapon(x,y,val,0.4*alpha_scale);
			end
			x=x+(82+2)
		else
			if(alpha_scale>0)then
				self:DrawWeapon(x,y,val,1*alpha_scale);
			end
			--self:DrawActiveWeapon(i,x,545,player);
			--x=x+(124+4)
			x=x+(82+2)
			--firemode
			if(player.fireparams and player.fireparams.hud_icon)then
				--%System:DrawImage(player.fireparams.icon,788,566+2,8,26,4);
				self:DrawElement(773,555,self.wicons[player.fireparams.hud_icon]);
			end
	
		end
	end
	
	
	local ngrenades;
	if(player.cnt.grenadetype~=1)then
			ngrenades=player.cnt.numofgrenades;
	end
	local class=GrenadesClasses[player.cnt.grenadetype]
	--GRENADE
	
	self:DrawGrenadeSlot(player,150,545,ngrenades,class);
	
end

gx=20
gy=552
function Hud:FlushCommon()
	self.rend:Draw(self.tx_hud);
end

-----------------------------------------------------------------------------
function Hud:DrawGrenadeSlot(player,x,y,num,grenade)
	self:DrawElement(x, y,self.txi.shape_grenade);
	if(grenade and self.tgrenades[grenade])then
		color=self.color_white;
		
		if(player.cnt.holding_grenade)then
			self.grenade_blink=self.grenade_blink+_frametime;
			if(self.grenade_blink>0.5)then
				if(self.grenade_blink>1)then self.grenade_blink=0; end
				color=self.color_red;
			else
				color=self.color_white;
			end
		else
			color=self.color_white;
		end
		
		
		self:DrawElement(x+11, y+5,self.tgrenades[grenade],color[1],color[2],color[3],color[4]);
		if(num)then
			if(num>9)then num=9 end
			self:DrawNumber(1,x+32,y+19,num);
		end
	end
end
-----------------------------------------------------------------------------
function Hud:DrawWeapon(x,y,w,alpha)
	self:DrawElement(x, y,self.txi.shape_bar,1,1,1,alpha);
	if(w and (w~=0) and w.name and self.tweapons[w.name] )then
		self:DrawElement(x+7, y+5,self.tweapons[w.name],1,1,1,alpha);
	end
end
-----------------------------------------------------------------------------
function Hud:DrawStance(player,wscope)
	do return end;
	local stance=self.stances.standing;
	if(player.cnt.crouching)then
		--%System:DrawImage(self.stances.crouching,92,529,38,61,4);
		self:DrawElement(97,536,self.txi.stance_crouch);
	elseif(player.cnt.proning)then
		self:DrawElement(97,536,self.txi.stance_prone);
		--%System:DrawImage(self.stances.proning,92,568,72,23,4);
	else
		self:DrawElement(97,536,self.txi.stance_standing);
		--%System:DrawImage(self.stances.standing,92,529,38,61,4);
	end
	if(wscope)then
		%System:DrawImage(self.aimmode,130,536,18,18,4);
	end
end

-----------------------------------------------------------------------------
function Hud:DrawGrenade(player)

	do return end

	local string=""
	if(player.cnt.grenadetype~=1)then
		string=format("%02i",player.cnt.numofgrenades);
	end
	local class=globals()[GrenadesClasses[player.cnt.grenadetype]]
	
	%System:DrawImage(self.greyrectsmall, 748, 527, 50, 30, 4);	
	
	
	if(class.hud_icon)then
		if(player.cnt.holding_grenade)then
			self.grenade_blink=self.grenade_blink+_frametime;
			if(self.grenade_blink>0.5)then
				if(self.grenade_blink>1)then self.grenade_blink=0; end
				%System:DrawImageColor(class.hud_icon, 748+28, 527+2, 18, 26, 4,1,0,0,1);
			else
				%System:DrawImage(class.hud_icon, 748+28, 527+2, 18, 26, 4);
			end
		else
			%System:DrawImage(class.hud_icon, 748+28, 527+2, 18, 26, 4);
		end
	end
	%Game:WriteHudStringFixed(748,525, string, self.color.r, self.color.g, self.color.b, 1, 35,37,0.33);
end

-- [marco] 
-----------------------------------------------------------------------------
function Hud:OnLightning()
	if (ClientStuff.vlayers:IsActive("NightVision")) then
		NightVision:OnLightning();
	end
end

-- [marco] ------------------------------------------------------------------
function Hud:OnMeleeDamage()
	self.meleedamagefade=1;
	self.bloodsmearimage=self.meleedamageindicator[random(1,3)];
end

-- [marco] When the player is underwater, a Breath Meter appears on the HUD. 
-- This meter displays the amount of air the player has before he will begin to take damage.
-- The meter gradually depletes the longer the player is underwater. Maximum time on the meter 
-- and the rate it which it decreases are variables we can set in the script (good starting point 10 seconds).
-- When the meter has expired, player begins to take damage. The player takes X damage each Y seconds - 
-- While taking damage, the breath-o-meter flashes to show the player why he is taking damage.
-- Surfacing immediately resets the meter. When the player submerges again at this point, he begins with 
-- a new meter.
-- Breath meter disappears as soon as the player surfaces.
-----------------------------------------------------------------------------

function Hud:DrawBreathOMeter(x1,y1)
	
	local txi=self.txi.oxygen_frame;
	local w,h=txi.size.w-2,txi.size.h-2;
	if (self.breathlevel>=0) then
		--System:LogToConsole("breathlevel="..self.breathlevel);		
		local size=100*self.breathlevel;
		--%System:DrawImage(self.blue,x1,y1+(yLen2-size),xLen2,size,0);
		self:DrawVBar(x1+1,y1-1,w-2,h-2,size,self.txi.white_dot,0,0,1,0.5);
		if (self.breathlevel<=0) then
			self.underbreathvalue=self.underbreathvalue-_frametime;
			if (self.underbreathvalue<0) then
				self.underbreathvalue=1;
			end
			
			self:DrawVBar(x1+1,y1+2,w-3,h-4,100,self.txi.white_dot,1,1,1,self.underbreathvalue);
			--System:DrawImageColor(self.white_dot, x1, y1, xLen2, yLen2, 4, 1,1,1,self.underbreathvalue);	
		end
		self:DrawElement(x1,y1,txi);
		--%System:DrawImage(self.breathOmeter,x1,y1,xLen2,yLen2,4);		

	end
end