Mission = {

	Briefing = 0,
	Objective1  = 0,
	Objective2  = 0,
};


function Mission:OnInit()
	-- you may want to load a string-table etc. here...

	
--	Movie:PlaySequence('intro_speech');


	
		
	--System:SetConsoleImage("levels/M03_OPT/loading_screen.jpg",0);
	--System:SetConsoleImage("levels/M03_OPT/loading_screen.tga",0);
	
	
end



function Mission:OnUpdate()
	local i;
	local bFinished=1;
	for i,objective in Mission do
		if (type(objective)~="function") then
			if (objective==0) then 
				bFinished=0;				
			else
			end
		end	
	end
	if (bFinished==1) then	
		self.Finish();
	end
end

--------------------------------------------------------------------------------------------------------

function Mission:Finish()
   
end

--------------------------------------------------------------------------------------------------------
-- Intro Cutsequences


function Mission:Event_Doyle_doyle_help_1()
	
		Movie:PlaySequence('intro_speech');
--	Hud:AddMessage('Jack? Wake up Jack! Don�t say anything � just listen - we don�t have much time.',7);

end


function Mission:Event_Doyle_doyle_help_5()
	Hud:AddMessage('You will find your ropes aren�t tied that tight - you should be able to get free if you try.',7);

end


function Mission:Event_Doyle_doyle_help_6()
	Hud:AddMessage('When you get yourself free, the first thing you need to do is',7);
	Hud:AddMessage('get the hell out of that old wreck. If you stay where you are',7);
 	Hud:AddMessage('you can count your life in hours; really unpleasant hours. ',7);
end



----------------------------------------------------------------------------------------------------
-- Ingame Cutsequences



function Mission:Event_intro()
	
	-- e_water_ocean=0;
	-- e_shadow_maps=0;
	-- Hud:AddMessage('Press F6 to skip cutsequence',10);
	r_DisplayInfo=0;
	
	-- e_terrain_caustics=0;
	-- fov=120;
	-- hud_panoramic=1;
	-- p_speed_run=5.6;
	-- god=1;
	
	-- Movie:PlaySequence('intro');

end

function Mission:Event_start_flyby()
	
	Movie:PlaySequence('intro');
		
end

function Mission:Event_init_mission()
	
	-- r_checkSunVis=2;
	-- r_Contrast=0.6;
	-- fov=90;
	-- e_terrain_caustics=0;
	-- hud_panoramic=0;
	-- e_water_ocean=1;
	e_shadow_maps=0;
	-- r_Contrast=0.65;
end


function Mission:Event_heli_fly_by()
	Movie:PlaySequence('heli_fly_by');
end

function Mission:moveplayercam(cameraname)
--	System:LogToConsole("Event_moveplayer");
	local camera=System:GetEntityByName(cameraname);
	if((camera)and(_localplayer))then
		local camerapos=camera:GetPos();
		camerapos.z=camerapos.z-1.7;
		_localplayer:SetPos(camerapos);
		_localplayer:SetAngles(camera:GetAngles());
	end
end

function Mission:Event_moveplayer()
	Mission:moveplayercam("Camera4")
end

function Mission:Event_moveplayer2()
	Mission:moveplayercam("Camera5")

	if (_localplayer) then
		local dir = new(_localplayer:GetDirectionVector());
		_localplayer:AddImpulseObj( dir, 300 );
	end
end


function Mission:Event_fireball()
	Movie:PlaySequence('fireball');
end


function Mission:Event_2heli_assault()
	Movie:PlaySequence('2heli_assault');
end


function Mission:Event_long_range_guys_walking_on_wreck()
	Movie:PlaySequence('long_range_guys_walking_on_wreck')	
end


function Mission:Event_spawn_long_range_guys()
	Movie:PlaySequence('spawn_long_range_guys')	
end


function Mission:Event_MissionFinished()
	-- last objective done
	if (Hud and Hud.CompleteObjective) then
		Hud:CompleteObjective("Enter the boat and drive to the next island")
	end

   	Game:SendMessage('EndDemo');
--	Game:SendMessage('StartLevel M03_OPT');
--   	Hud:AddMessage('Mission finished, restarting level...',7);
end


function Mission:Event_matrix_camera_around_explosion_reset()
	p_fixed_timestep=0;
	
end


function Mission:Event_matrix_camera_around_explosion()
	-- p_fixed_timestep=0.01;
	Movie:PlaySequence('matrix_camera_around_explosion');
	-- p_fixed_timestep=0;
end

function Mission:Event_hideall()
	Movie:PlaySequence('HIDE ALL');
end


function Mission:Event_boats_attack_wreck()
	Movie:PlaySequence('boats_attack_wreck');	
end


function Mission:Event_boat_land_on_beach()
	Movie:PlaySequence('boat_land_on_beach');	
end


function Mission:Event_BoatJump0()
	Movie:PlaySequence('BoatJump0');	
end


function Mission:Event_start_carrier_patrol()
	
	Movie:PlaySequence('carrier_patrol');
		
end

--------------------------------------------------------------------------------------------------------
-- Ingame Messages (Mission Objectives)
-- Sequential: each trigger completes the previous objective and pushes the next.
-- PushObjective ignores duplicate text; CompleteObjective marks checkbox done.


function Mission:Event_1stmessage()
	-- Start (ship / after intro): first objective only
	Hud:AddMessage('Get out of the ship',7); 
	Hud:PushObjective({},"Get out of the ship")
end




function Mission:Event_2ndmessage()
	-- Left ship / beach camp: complete #1, show #2
	Hud:AddMessage('Go to the fort ruin on the top of the mountain',7);
	Hud:CompleteObjective("Get out of the ship")
	Hud:PushObjective({},"Go to the fort ruin on the top of the mountain") 
end


function Mission:Event_3ndmessage()
	-- Path / approach to fort (help6 zone): complete #2, show #3
	Hud:AddMessage('The mercs use the fort ruin as an outpost, plant a bomb in the main room',7);
	Hud:CompleteObjective("Go to the fort ruin on the top of the mountain")
	Hud:PushObjective({},"Plant a bomb in the main room of the fort ruin")
end


function Mission:Event_4ndmessage()
	-- Placing explosive in fort: complete #2/#3 if skipped, show #4
	Hud:AddMessage('Escape from the explosion and jump down the cliff',9);
	-- safety if player skipped fort approach triggers
	Hud:CompleteObjective("Go to the fort ruin on the top of the mountain")
	Hud:PushObjective({},"Plant a bomb in the main room of the fort ruin")
	Hud:CompleteObjective("Plant a bomb in the main room of the fort ruin")
	Hud:PushObjective({},"Escape from the explosion and jump down the cliff")
end


function Mission:Event_5ndmessage()
	-- After explosion / tunnel: complete #4, show #5
	Hud:AddMessage('Enter the boat and drive to the next island',7);
	Hud:CompleteObjective("Escape from the explosion and jump down the cliff")
	Hud:PushObjective({},"Enter the boat and drive to the next island")
end


--------------------------------------------------------------------------------------------------------
-- Ingame Messages (Hints, Mercs conversations...)



function Mission:Event_Prison_Cell()
	Hud:AddMessage('You are imprisoned, try to go out of the wreck alive',5);
	 
end

function Mission:Event_armory_explosion_warning()
	Hud:AddMessage('Get out its gonna blow',5);
end

function Mission:Event_Mercs_Beach_Reinforcements()
	Hud:AddMessage('Mercs: The Intruder has escaped in the jungle, send a patrol to chase him',15);
	
	
		
end



function Mission:Event_Mercs_Camp_Alarm()
	Hud:AddMessage('Mercs: Alert, a intruder is in the camp',5);
		
end


function Mission:Event_Mercs_Hilltop_Reinforcements()
	Hud:AddMessage('Mercs: The intruder is on the path to the fort, sent a helicopter to stop him',5);
		
end



function Mission:Event_Mercs_Boat_Reinforcements()
	Hud:AddMessage('Mercs: Something happend at the ship wreck lets check out whats going on',5);
		
end
		

function Mission:Event_Mercs_fort_message()
	Hud:AddMessage('Mercs: The intruder is at the fort send in reinforcments to stop him',5);
	 
end


function Mission:Event_Radiotower()
	Hud:AddMessage('',5);
	
		
end
