cl_display_hud = 1
cl_drunken_cam = 0
ThirdPersonView = 0

--- non standard key bindings ---
-- Please NEWER use F9,F10 keys (reserved for debug purposes) (Vlad)

--Input:BindCommandToKey("#BoatReload()","=",1);
Input:BindCommandToKey('#Movie:StopAllCutScenes()',"F6",1);
Input:BindCommandToKey("#SwitchCameraMode()","f1",1);
--Input:BindCommandToKey("#ToggleDayNight()","f2",1);
--Input:BindCommandToKey("#ToggleSuperDesignerMode()","f3",1);
--Input:BindCommandToKey("#ToggleDesignerMode()","f4",1);
Input:BindCommandToKey("#ToggleNewDesignerMode(40,120,1)","f3",1);
Input:BindCommandToKey("#ToggleNewDesignerMode(10,15,0)","f4",1);
Input:BindCommandToKey("#DefaultSpeed()","f5",1);
Input:BindCommandToKey("#Game.Save()","f8",1);
Input:BindCommandToKey("#ToggleGod()","backspace",1);
--Input:BindCommandToKey("#Game.Load()","f9",1);
Input:BindCommandToKey("#r_GetScreenShot=1","f12",1);
--Input:BindCommandToKey("#e_hires_screenshoot=4","f10",1);
--Input:BindCommandToKey("#Cheat()", "c", 1);
--Input:BindCommandToKey("#SetPlayerPos()","j",1);
Input:BindCommandToKey("#DecreseSpeed()","-",1);
Input:BindCommandToKey("#IncreseSpeed()","=",1);
Input:BindCommandToKey("#p_single_step_mode=1-p_single_step_mode","[",1);
Input:BindCommandToKey("#p_do_step=1","]",1);

Input:BindCommandToKey("#ToggleScreenshotMode()","f11",1);

Input:BindCommandToKey("#GotoNextSpawnpoint()","f2",1);

Input:BindCommandToKey("#ToggleCheatMode()",".",1);



-- Developer Cheat keys ---
Input:BindCommandToKey("#MoreAmmo()","o",1);
Input:BindCommandToKey("#AllWeapons()","p",1);
Input:BindCommandToKey("#AllGrenades()","i",1);	-- fix 19: all grenades (cheat mode)



--- temp variables for functions below ---
prev_speed_walk=p_speed_walk;
prev_speed_run=p_speed_run;

prev_speed_walk2=p_speed_walk;
prev_speed_run2=p_speed_run;

default_speed_walk=p_speed_walk;
default_speed_run=p_speed_run;

screenshotmode=0;
cheatmode=0;

function ToggleCheatMode()
	if (cheatmode==0) then
		cheatmode=1;
	else
		cheatmode=1-cheatmode;
	end
	if (cheatmode==1) then
		System:LogToConsole("CHEAT-Mode ON");
	else
		System:LogToConsole("CHEAT-Mode OFF");
	end
end

--- functions---
function ToggleGod()

	if (cheatmode==0) then
		do return end
	end

	if (not god) then
		god=1;
	else
		god=1-god;
	end
	if (god==1) then
		System:LogToConsole("God-Mode ON");
	else
		System:LogToConsole("God-Mode OFF");
	end
end

function GotoNextSpawnpoint()

	if (cheatmode==0) then
		do return end
	end

	Hud:AddMessage("[NEXT]: next spawn point");
--	System:LogToConsole("\002 next spawn point");
	local pt;
	pt=Server:GetNextRespawnPoint();

	Game:ForceEntitiesToSleep();

	if(pt)then 
		_localplayer:SetPos(pt);
		_localplayer:SetAngles({ x = pt.xA, y = pt.yA, z = pt.zA });

--		local pos = {x = rp.x, y = rp.y, z = rp.z};
--		local ang = {x = rp.xA, y = rp.yA, z = rp.zA};
--		
--		_localplayer.SetPos( pos );
--		_localplayer.SetAngle( an );
	end
end

function SwitchCameraMode()
	p=_localplayer;
	if(p.cnt.first_person~=nil)then
			System:LogToConsole("Switching to third person");
			Game:SetThirdPerson(1);
			--p.cnt.first_person=nil;
	else
			System:LogToConsole("Switching to first person");
			Game:SetThirdPerson(0);
			--p.cnt.first_person=1;
	end
end

--function Cheat()
--	local Entites = System:GetEntities();
--	for iCurEty, Ety in Entites do
--		if (Ety.Ammo ~= nil) then
--			local PlayerAmmo = Ety.Ammo;
--
--			for i, AmmoType in PlayerAmmo do
--				--System.LogToConsole("Ammo Received ! "..i);
--				PlayerAmmo[i] = 999;
--			end
--		end
--	end
--end

function SetPlayerPos()
	local p=_localplayer
	p:SetPos({x=100,y=100,z=300});
end


-- dangerous implementation - because it affects all living entities
--
--function ToggleSuperDesignerMode()
--	if(p_fly_mode~=0) then
--		System:LogToConsole("SUPER DESIGNER MODE OFF-->SWITCH TO LAMERMODE");
--		p_fly_mode=0;
--		p_speed_walk = prev_speed_walk;
--		p_speed_run = prev_speed_run;
--	else
--		System:LogToConsole("SUPER DESIGNER MODE ON");
--		p_fly_mode=1;
--		prev_speed_walk=p_speed_walk;
--		prev_speed_run=p_speed_run;
--		p_speed_walk = 40;
--		p_speed_run = 120;
--	end
--end


-- dangerous implementation - because it affects all living entities
--
--function ToggleDesignerMode()
--	if(p_fly_mode~=0) then
--		System:LogToConsole("DESIGNER MODE OFF-->SWITCH TO LAMERMODE");
--		p_fly_mode=0;
--		p_collision_mode=0;
--		p_speed_walk = prev_speed_walk2;
--		p_speed_run = prev_speed_run2;
--	else
--		System:LogToConsole("DESIGNER MODE ON");
--		p_fly_mode=1;
--		p_collision_mode=1;
--		prev_speed_walk2=p_speed_walk;
--		prev_speed_run2=p_speed_run;
--		p_speed_walk = 10;
--		p_speed_run = 15;
--	end
--end


-- replacement for ToggleSuperDesignerMode() and ToggleDesignerMode()
--
-- USAGE:
--  deactivate designer mode: (nil,nil,0)
--  old super designer mode (with collision): (40,120,1)
--  old designer mode (without collision): (10,15,0)
--  change values: call with (nil,nil,0) then with the new values (0.., 0.., 0/1)
--
function ToggleNewDesignerMode( speedwalk, speedrun, withcollide )

	if (cheatmode==0) then
		do return end
	end

	if(SuperDesignerMode_Save1~=nil or speedwalk==nil) then
		Hud:AddMessage("[CHEAT]: Designer fly mode OFF");

 		p_speed_walk = SuperDesignerMode_Save1;
		p_speed_run = SuperDesignerMode_Save2;
		_localplayer.DynProp.gravity = SuperDesignerMode_Save3;
		_localplayer.DynProp.inertia = SuperDesignerMode_Save4;
		_localplayer.DynProp.swimming_gravity = SuperDesignerMode_Save5;
		_localplayer.DynProp.swimming_inertia = SuperDesignerMode_Save6;
		_localplayer.DynProp.air_control = SuperDesignerMode_Save7;
		_localplayer.cnt:SetDynamicsProperties( _localplayer.DynProp );
		SuperDesignerMode_Save1=nil;

		-- activate collision, parameter is 0 or 1
		_localplayer:ActivatePhysics(1);

	else
		Hud:AddMessage("[CHEAT]: Designer fly mode ON");

 		SuperDesignerMode_Save1 = p_speed_walk;
		SuperDesignerMode_Save2 = p_speed_run;
		SuperDesignerMode_Save3 = _localplayer.DynProp.gravity;
		SuperDesignerMode_Save4 = _localplayer.DynProp.inertia;
		SuperDesignerMode_Save5 = _localplayer.DynProp.swimming_gravity;
		SuperDesignerMode_Save6 = _localplayer.DynProp.swimming_inertia;
		SuperDesignerMode_Save7 = _localplayer.DynProp.air_control;

		p_speed_walk = speedwalk;
		p_speed_run = speedrun;
		_localplayer.DynProp.gravity=0.0;
		_localplayer.DynProp.inertia=0.0;
		_localplayer.DynProp.swimming_gravity=0.0;
		_localplayer.DynProp.swimming_inertia=0.0;
		_localplayer.DynProp.air_control=1.0;
		_localplayer.cnt:SetDynamicsProperties( _localplayer.DynProp );

		-- deactivate collision, parameter is 0 or 1
		_localplayer:ActivatePhysics(withcollide);
	end
end



function ToggleScreenshotMode()
	if(screenshotmode~=0) then
		System:LogToConsole("SCREENSHOTMODE OFF-->SWITCH TO NORMAL");
		screenshotmode=0;
		hud_crosshair = "1"
		cl_display_hud = "1"
		r_NoDrawNear = "0"
		ai_ignoreplayer = "0"
		ai_soundperception = "1"
		r_DisplayInfo = "1"
	else
		System:LogToConsole("SCREENSHOTMODE ON");
		screenshotmode=1;
		hud_crosshair = "0"
		cl_display_hud = "0"
		r_NoDrawNear = "1"
		ai_ignoreplayer = "1"
		ai_soundperception = "0"
		r_DisplayInfo = "0"
	end
end



function DecreseSpeed()

	if (cheatmode==0) then
		do return end
	end

	if tonumber(p_speed_walk)>5 then
		p_speed_walk=p_speed_walk-5;
		p_speed_run=p_speed_run-5;
		System:LogToConsole("Decresed player speed by 5");
	else
		System:LogToConsole("You can not go any slower!");
	end 
end

function IncreseSpeed()

	if (cheatmode==0) then
		do return end
	end

	if tonumber(p_speed_walk)<500 then
		p_speed_walk=p_speed_walk+5;
		p_speed_run=p_speed_run+5;
		System:LogToConsole("Incresed player speed by 5");
	else
		System:LogToConsole("You can not go any faster!");
	end 
end

function DefaultSpeed()
	p_speed_walk=default_speed_walk;
	p_speed_run=default_speed_run;
	System:LogToConsole("Player speed reset");
end

function TeleportToSpawn(n)
	local player = _localplayer;
	local pos = Server:GetRespawnPoint("Respawn"..n);
	if pos then
		player:SetPos(pos);
		player:SetAngles({ x = pos.xA, y = pos.yA, z = pos.zA });
	end
end


-- Give the player the passed weapon, load it if neccesary
function AddWeapon(Name)

	if (cheatmode==0) then
		do return end
	end

	Game:AddWeapon(Name)
	for i, CurWeapon in WeaponClasses do
		if (CurWeapon[1] == Name) then
			_localplayer.cnt:MakeWeaponAvailable(CurWeapon[2]);
		end
	end	
end


function MoreAmmo()

	if (cheatmode==0) then
		do return end
	end

	_localplayer.cnt.ammo=999;
	Hud:AddMessage("[CHEAT]: Give 999 ammo");
	System:LogToConsole("\001CHEAT: Give 999 ammo");
end

function AllWeapons()

	if (cheatmode==0) then
		do return end
	end

	AddWeapon("AG36");
	AddWeapon("DE");
	AddWeapon("AW50");
	AddWeapon("MP5");
	AddWeapon("RL");
	AddWeapon("Pancor");
	AddWeapon("G11");
	AddWeapon("OICW");
	AddWeapon("Shocker");
	AddWeapon("P90");
	AddWeapon("Mortar");
	AddWeapon("M4");
	Hud:AddMessage("[CHEAT]: Give all weapons");
	System:LogToConsole("\001CHEAT: Give All weapons");
end

-- fix 19: every grenade type of GrenadesClasses except the rock (unlimited anyway) filled up to MaxAmmo:
-- hand grenades, smoke grenades, flares, flashbang grenades and glow sticks (cheat mode, key I)
function AllGrenades()

	if (cheatmode==0) then
		do return end
	end

	local p=_localplayer;
	if (not p) or (not p.Ammo) then
		do return end
	end
	for i,g in GrenadesClasses do
		if (g~="Rock" and MaxAmmo[g]) then
			p.Ammo[g]=MaxAmmo[g];
		end
	end
	local cur=GrenadesClasses[p.cnt.grenadetype];
	if (cur=="Rock") then
		BasicPlayer.SelectGrenade(p,"HandGrenade");
	elseif (cur) then
		p.cnt.numofgrenades=p.Ammo[cur];
	end
	Hud:AddMessage("[CHEAT]: Give all grenades");
	System:LogToConsole("\001CHEAT: Give all grenades");
end

